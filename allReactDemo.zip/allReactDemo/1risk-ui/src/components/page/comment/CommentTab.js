import React from "react";
import {Col, Row} from "react-bootstrap";
import CommentsSection from "../../core/CommentsSection";

const CommentTab = ({objectName,objectId,...restProps}) => {

    return(<Row>
        <Col xl={8}>
            <CommentsSection objectName={objectName} objectId={objectId}/>
        </Col>
        <Col xl={4}>
            {/*<Card>*/}
            {/*    <Card.Header>PlaceHolder</Card.Header>*/}
            {/*    <Card.Body>*/}
            {/*        <Card.Text>Placeholder Area</Card.Text>*/}
            {/*    </Card.Body>*/}
            {/*</Card>*/}
        </Col>
    </Row>)

}

export default (CommentTab);