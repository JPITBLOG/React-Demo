import React, { Component } from 'react';
import UUIDUtil from "../../../util/UUIDUtil";
import { SEARCH_ON_TYPE_RESET } from "../../core/SearchOnType";
import FilterChip from "../../core/FilterChip";
import ClearIcon from "@material-ui/icons/Clear";
import { Button, Col, Row } from "react-bootstrap";
import withEventBus from "../../core/withEventBus";
import { connect } from "react-redux";
import MultiSelectorDropDown from "../../core/MultiSelectorDropDown";
import SearchOnTypeV2 from "../../core/SearchOnTypeV2";

class AttachmentSearchTab extends Component {

    static defaultProps = {
        showObligationFilter: true,
        onAddClick: () => null
    }

    state = {
        searchOnTypeName: UUIDUtil.v4(),
        selectedOwners: [],
        dropdownHeight: 400,
        searchOnTypeValue: null,
    }

    constructor(props) {
        super(props);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onClickResetHandler = this.onClickResetHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.removeFromSelectedList = this.removeFromSelectedList.bind(this);
        this.onCloseFilterHandler = this.onCloseFilterHandler.bind(this);
        this.sendFilterChange = this.sendFilterChange.bind(this);
        this.onChangeSelectValue = this.onChangeSelectValue.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
    }

    onClickResetHandler(event) {
        this.setState({ selectedOwners: [], searchOnTypeValue: null });
        this.props.onResetFilters();
        this.props.eventBus.dispatch(SEARCH_ON_TYPE_RESET, this.state.searchOnTypeName);
        event.preventDefault();
    }

    onChangeSelectValue(entity, value) {
        switch (entity) {
            case "owner":
                this.setState({ selectedOwners: value });
                break;
            default:
                break;
        }
    }

    onCloseFilterHandler(event) {
        this.sendFilterChange(event);
    }

    sendFilterChange(event) {

        const { selectedOwners } = this.state;

        const response = {
            "name": event,
            "value": ""
        }

        switch (event) {
            case "owner": {
                response.value = JSON.stringify(selectedOwners.map((type) => type.value));
                break;
            }
            default:
                break;
        }
        this.props.onFilterChange(response);
    }


    renderChips() {
        let chipList = [];
        this.state.selectedOwners.forEach(value => {
            chipList.push(this.renderChip('owner', value));
        });


        return chipList;
    }

    renderChip(type, data, labelKey = "label", valueKey = "value") {
        const chipId = `chip-${type}-${data[valueKey]}`;
        return (<FilterChip key={chipId} id={chipId}
            label={data[labelKey]}
            onDelete={this.onDeleteHandler} color="default"
            deleteIcon={<ClearIcon />}
        />);
    }

    onDeleteHandler(event) {
        const itemId = event.currentTarget.parentNode.id.split("-");
        switch (itemId[1]) {
            case "owner":
                this.removeFromSelectedList(itemId[1], "selectedOwners", itemId[2], "value")
                break;
            default:
                break;
        }
    }

    removeFromSelectedList(event, listName, idToDelete, valueKey) {
        const state = this.state;
        state[listName] = state[listName].filter(function (item) {
            return String(item[valueKey]) !== String(idToDelete);
        });
        this.setState(state);
        this.sendFilterChange(event);
    }

    onSearchTypeHandler(event) {
        this.props.onSearchType(event);
        this.setState({ searchOnTypeValue: event.value });
    }

    onAddClickHandler(event) {
        this.props.onAddClick(event);
    }

    render() {
        const {
            selectedOwners,
            searchOnTypeValue
        } = this.state;
        return (<div className="obligation-section-search"><div className="filter-form">
            <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler} />
            <Row>
                <Col lg={2} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedOwners}
                        options={this.props.usersFilterData}
                        onChange={(e) => this.onChangeSelectValue("owner", e)}
                        onClose={() => this.onCloseFilterHandler("owner")}
                        singularSelectedPlaceholder="%s Owner selected"
                        manySelectedPlaceholder="%s Owners selected"
                        placeholder="Filter by Owners"
                    />
                </Col>
                <Col lg={1} className="form-group filter-selection-col">
                    <Button variant="link" onClick={this.onClickResetHandler}>Clear all</Button>
                </Col>
            </Row>
            <div className="filters-option">
                {this.renderChips()}
            </div>
        </div></div>)
    }
}

const mapStateToProps = (state) => {
    return ({
        usersFilterData: state.searchFilter.usersFilterData
    });
}

export default withEventBus(connect(mapStateToProps, null)(AttachmentSearchTab));