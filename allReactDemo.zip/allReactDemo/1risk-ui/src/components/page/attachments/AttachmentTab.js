import React, {Component} from 'react';
import * as actions from "../../../actions"
import {connect} from "react-redux";
import BrowserUtil from "../../../util/BrowserUtil";
import withEventBus from "../../core/withEventBus";
import UUIDUtil from '../../../util/UUIDUtil';
import PaginationUtil from "../../../util/PaginationUtil";
import DownloadIcon from "../../core/icon/DownloadIcon";
import ProtectedDownload from "../../core/ProtectedDownload";
import ObjectUtil from "../../../util/ObjectUtil";
import TopActionMenu from "../../core/TopActionMenu";
import {confirmAlert} from "react-confirm-alert";
import ConfirmWindow from "../../core/ConfirmWindow";
import ExportUtil from "../../../util/ExportUtil";
import ReactToPrint from "react-to-print";
import ReportWrapper from "../../core/reportWrapper";
import SearchOnTypeV2 from "../../core/SearchOnTypeV2";
import DataTable from "../../core/DataTable";
import FileUtil from "../../../util/FileUtil";
import DateUtil from "../../../util/DateUtil";
import DataTableUtil from "../../../util/DataTableUtil";

class AttachmentTab extends Component {

    static defaultProps = {
        objectName: "",
        objectId: 0
    }

    state = {
        tableViewName: UUIDUtil.v4(),
        selectedItems: [],
        prevSelectedItems: [],
        pagination: PaginationUtil.generatePaginationRequest(0, 50,"id","DESC"),
        lastPagination: "",
        filters: [],
        lastFilters: [],
        editMode: false,
        searchOnTypeValue: "",
        searchLoading: false,
        isPrinting: false,
        detailObjectId: 0,
        objectHash: ""
    }

    constructor(props) {
        super(props);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.updateFilter = this.updateFilter.bind(this);
        this.onSelectedHandler = this.onSelectedHandler.bind(this);
        this.onClearSelected = this.onClearSelected.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
        this.loadAttachments = this.loadAttachments.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onExportHandler = this.onExportHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
    }

    componentDidMount() {
        this.loadTopMenuItems();
        const {objectName,objectId} = this.props;
        if(objectName && objectId){
            const state = this.state;
            state.objectHash = ObjectUtil.hash(objectName,objectId);
            this.setState(state);
            this.props.getAttachmentTableFilters(state.objectHash);
        }else{
            this.props.getAttachmentTableFilters();
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        const { prevSelectedItems, selectedItems } = this.state;

        if (prevSelectedItems.length !== selectedItems.length) {
            this.loadTopMenuItems();
            this.setState({ prevSelectedItems: ObjectUtil.clone(selectedItems) });
        }

        if(prevProps.objectName !== this.props.objectName || prevProps.objectId !== this.props.objectId){
            const state = this.state;
            state.objectHash = ObjectUtil.hash(this.props.objectName,this.props.objectId);
            this.setState(state);
        }

        const self = this;
        PaginationUtil.searchWithFilter(this.state,state=>{
            self.setState(state);
            self.executeSearch()
        });

    }

    loadTopMenuItems() {

        const { selectedItems } = this.state;
        const isSectionEnabled = selectedItems.length < 1;
        const deleteLabel = isSectionEnabled ? "Delete" : `Delete (${selectedItems.length} selected)`;

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Add New" icon="plus" onClick={this.onAddClickHandler} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label={deleteLabel} icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload" icon="upload" onClick={(e) => console.log(e)} />
        ], false);

    }

    onDeleteHandler() {

        const { deleteAttachments } = this.props;
        const { selectedItems } = this.state;
        const self = this;

        const deleteRecord = () => {
            const idsToDelete = self.state.selectedItems.map((item) => item.referenceId);
            deleteAttachments(idsToDelete, (data, err) => {
                if (!err) {
                    self.onClearSelected();
                    self.executeSearch();
                }
            })
        }

        const confirmInfo = `You want to delete the ${selectedItems.length} selected records?`

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow infoText={confirmInfo} onClose={onClose} onAction={deleteRecord} />
        });

    }

    onExportHandler() {
        const { items } = this.props.attachmentData;
        const { selectedItems } = this.state;
        ExportUtil.generateCsv(this.getColumns(), (selectedItems.length > 0 ? selectedItems : items), "attachment");
    }

    loadAttachments() {
        console.log("Loading attachments")
        const { objectName, objectId } = this.props;
        if (objectName !== "" && objectId !== 0) {
            const state = this.state;
            state.objectHash = ObjectUtil.hash(objectName, objectId);
            this.props.getAttachmentData([{ name: "objectHash", value: state.objectHash }]);
            this.setState(state);
        } else {
            this.props.getAttachmentData();
        }
    }

    onPageChangeHandler(selectedPage) {
        this.props.getAttachmentData(selectedPage);
        BrowserUtil.scrollToTopSmooth();
    }

    onControlTagClickHandler(e) {
        this.props.setCheckboxItem(this.state.tagFilterName, e);
    }

    getColumns() {
        return [
            {
                label: "HiddenRefId",
                name: "referenceId",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "ID",
                name: "internalId",
                options: {
                    filter: false,
                    sort: true,
                    display: true,
                }
            },
            {
                label: "Filename",
                name: "name",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                    customBodyRender: (value, tableMeta) => <ProtectedDownload label={value} tableMeta={tableMeta} />
                }
            },
            {
                label: "Size",
                name: "size",
                options: {
                    sort: false,
                    display: true,
                    filter: false,
                    customBodyRender: (value) => FileUtil.formatBytes(value)
                }
            },
            {
                label: "Owner",
                name: "ownerName",
                options: {
                    sort: true,
                    display: true,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.owners)
                }
            },
            {
                label: "Created Date",
                name: "createdAt",
                options: {
                    filter: true,
                    sort: true,
                    display: true,
                    customBodyRender: (value) => DateUtil.format(value),
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdDates)
                }
            },
            {
                label: "Download",
                name: "referenceId",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                    customBodyRender: (value) => <DownloadIcon referenceId={value} />
                }
            },
        ]
    }


    onSearchTypeHandler(event) {
        this.updateFilter(event);
    }

    executeSearch() {
        const { pagination,filters } = this.state;
        this.setState({ searchLoading: true });

        PaginationUtil.prepareFilters(filters, "objectHash", ObjectUtil.hash(this.props.objectName,this.props.objectId));
        const activeFilters = PaginationUtil.getActiveFilters(filters);

        this.props.getAttachmentData(activeFilters, pagination, () => this.setState({ searchLoading: false }));

    }

    updateFilter(selectedFilter) {
        const state = this.state;
        let filterUpdated = false;
        state.filters.forEach((filter, index) => {
            if (filter.name === selectedFilter.name) {
                state.filters[index].value = selectedFilter.value;
                filterUpdated = true;
            }
        });
        if (!filterUpdated) {
            state.filters.push(selectedFilter);
        }
        this.setState(state);
    }

    onFilterChangeHandler(event) {
        if (PaginationUtil.isFilterChanged(event, this.state)) {
            this.updateFilter(event);
            this.executeSearch();
        }
    }

    onResetFiltersHandler(event) {
        const { pagination } = this.state;
        this.setState({ filters: [] });
        this.props.getNotesData(null, pagination);
    }

    onSelectedHandler(item) {
        this.setState({ selectedItems: item });
    }

    onClearSelected() {
        this.setState({ selectedItems: [] });
    }

    onAddClickHandler(event) {
        this.props.history.push(`/grc-library/attachments/new/` + this.state.objectHash);
    }

    render() {

        const { searchOnTypeValue, searchLoading, isPrinting } = this.state;

        return (
            <div className="controls-tab" ref={this.myRef}>
                <div id="Controls" className="single-content active">

                    <div className="filter-form">
                        <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler} />
                    </div>

                    <ReactToPrint
                        trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                        content={() => this.tableRef}
                        onBeforeGetContent={() => this.setState({ isPrinting: true })}
                        onAfterPrint={() => this.setState({ isPrinting: false })}
                    />

                    <ReportWrapper entityName="Attachment" ref={el => (this.tableRef = el)} className="tab-container">
                        <DataTable
                            page={this.props.attachmentData}
                            loading={searchLoading}
                            columns={this.getColumns()}
                            isPrinting={isPrinting}
                            onPaginationChange={(e) => this.setState({ pagination: e })}
                            onFilterChange={(e) => this.setState({ filters: e })}
                            onSelected={this.onSelectedHandler}
                            title="Attachments" />
                    </ReportWrapper>
                </div>
            </div>);
    }
}

function mapStateToProps(state) {
    return {
        obligationDetail: state.grcLibrary.obligationDetail,
        attachmentData: state.grcLibrary.attachmentData,
        tableFilters: state.grcLibrary.attachmentTableFilters
    }
}

export default withEventBus(connect(mapStateToProps, actions)(AttachmentTab));