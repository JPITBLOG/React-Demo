import React, {Component} from 'react';
import {Button, Card, Col, Row} from "react-bootstrap";
import ActionOverlay from "../../../core/ActionOverlay";
import IconButton from "../../../core/button/IconButton";
import FileUploadDropzone from "../../../core/FileUploadDropzone";
import * as actions from "../../../../actions"
import pageWrapper,{PAGE_TYPE_ADD} from "../../../core/pageWrapper";
import {connect} from "react-redux";
import PageUtil from "../../../../util/PageUtil";
import AttachedFileList from "../../../core/AttachedFileList";
import '../Attachment.css';

class AttachmentSavePage extends Component {

    state = {
        attachmentsToSave: [],
        uploadInProgress: false,
        attachmentData: {},
        uploadAttachmentsData:[]
    }

    constructor(props) {
        super(props);

        this.onFileLoadHandler = this.onFileLoadHandler.bind(this)
        this.onFileClearHandler = this.onFileClearHandler.bind(this)
        this.onClickSaveHandler = this.onClickSaveHandler.bind(this)
        this.onCancelHandler = this.onCancelHandler.bind(this)
    }


    componentDidMount() {
        this.pageUtil = new PageUtil(this.props);

        if (this.pageUtil.exists("objectHash")) {
            const state = this.state;
            state.objectHash = this.pageUtil.get("objectHash");
            state.attachmentData = {
                id: 0,
                objectHash: state.objectHash
            };
            this.setState(state);
        }
        const breadcrumb = { "title": "Grc Library", "label": "Add New", "init": false };
        const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_ADD, "Attachments")
        const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
        this.props.onPageLoad(event);
    }

    onClickSaveHandler() {
        this.props.uploadAttachments(this.state.uploadAttachmentsData, (response, err) => {
            if (!err) {
                this.props.history.goBack();
            }
        });
    }

    onCancelHandler() {
        this.props.history.goBack();
        // this.props.history.push('/grc-library/obligations');
    }

    onFileClearHandler(event) {
        const state = this.state;
        const {item} = event;       
        state.attachmentsToSave = state.attachmentsToSave.filter((attachment)=> {
            return attachment.name!== item.name && attachment.size !== item.size;
        });

        this.setState(state);
    }

    onFileLoadHandler(event) {
        event.path = "/attachments";
        const { attachmentsToSave, attachmentData,uploadAttachmentsData } = this.state;
        attachmentsToSave.push({ name: event.name, size: event.size });
        event.objectHash = attachmentData.objectHash;
        uploadAttachmentsData.push(event)
        this.setState({ attachmentsToSave: attachmentsToSave, attachmentData: { ...attachmentData,event } });
    }

    render() {
        const { attachmentsToSave, uploadInProgress } = this.state
        return (

            <div className="detail-page-container">
                <Row>
                    <Col lg={12} className="left-col">
                        <Card className="card-section">
                            <Card.Header className="attchment-file pb-0">Attachment</Card.Header>
                            <Card.Body>
                                <FileUploadDropzone
                                    isMultiple={true}
                                    loading={uploadInProgress}
                                    onLoad={this.onFileLoadHandler}
                                    onClear={this.onFileLoadHandler}
                                />
                                {attachmentsToSave.length > 0 &&
                                    <section>
                                        <Card.Title>Files</Card.Title>
                                        <AttachedFileList attachments={attachmentsToSave} onDelete={this.onFileClearHandler} />
                                    </section>}
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
                <ActionOverlay visible={true}>
                    <ActionOverlay.Actions>
                        <IconButton onClick={this.onClickSaveHandler} icon="check">Save</IconButton>
                        <Button onClick={this.onCancelHandler} variant="secondary">Cancel</Button>
                    </ActionOverlay.Actions>
                </ActionOverlay>

            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return ({
        attachmentData: state.attachment.attachmentData
    })
}

export default pageWrapper(connect(mapStateToProps, actions)(AttachmentSavePage))