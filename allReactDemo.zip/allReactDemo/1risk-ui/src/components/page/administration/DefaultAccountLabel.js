import React from 'react';
import Label from "../../core/Label";
import styled from "styled-components";

const DefaultLabelSpan = styled((props) => <span {...props}>{props.children}</span>)`
    margin-left:10px;
    color: #228B22;
`;

const DefaultAccountLabel = ({ value, tableMeta, columnIdx = 3 }) => {
    const { rowData } = tableMeta;
    return (
        <div>
            <Label>{value}</Label>
            {rowData[columnIdx] && <DefaultLabelSpan> Default</DefaultLabelSpan>}
        </div>
    )
}

export default (DefaultAccountLabel);