import React from "react";
import { Card, Col, Row } from "react-bootstrap";
import DateUtil from "../../../../../util/DateUtil";
import { Button } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { activateSubscription, setSystemMessage } from '../../../../../actions/';
import StatusLabel from "../../../../core/StatusLabel";

const UserDetailTab = (props) => {

    const headerText = "User Detail";
    const userDetail = props.userdata;
    const dispatch = useDispatch();

    const onActivateClick = () => {

        if (props.defaultAccount) {
            dispatch(setSystemMessage("danger", "Default account cannot be deactivated."))
        }
        else {
            dispatch(activateSubscription(props.referenceId, (data, err) => {
                if (data) {
                    console.log("");
                }
            }));
        }
    }

    return (
        <div className="content-widget">
            <Card>
                <Card.Header>
                    <Row>
                        <Col lg={10}>{headerText}</Col>
                        <Col className="account-right-header" lg={2}>
                            {userDetail?.status === 'Active' ? <Button variant="outline-secondary" onClick={onActivateClick}>Deactivate</Button> : <Button variant="primary" onClick={onActivateClick}>Activate</Button>}
                        </Col>
                    </Row>
                </Card.Header>
                <Card.Body>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Full Name
                            </Card.Title>
                            <Card.Text>
                                {userDetail.fullName}
                            </Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>ID</Card.Title>
                            <Card.Text>{userDetail.internalId}</Card.Text>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Title
                            </Card.Title>
                            <Card.Text>{userDetail.title}</Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                Status
                            </Card.Title>
                            <StatusLabel status={userDetail.status}>{userDetail.status}</StatusLabel>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Email
                            </Card.Title>
                            <Card.Text>{userDetail.email}</Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                Created Date
                            </Card.Title>
                            <Card.Text>{DateUtil.format(userDetail.createdAt)}</Card.Text>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Mobile Phone
                            </Card.Title>
                            <Card.Text>{userDetail.mobilePhone}</Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                Last Modified Date
                            </Card.Title>
                            <Card.Text>{DateUtil.format(userDetail.updatedAt)}</Card.Text>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Two-Factor Authentication
                            </Card.Title>
                            <Card.Text>SMS Text</Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                Last login
                            </Card.Title>
                            <Card.Text>{userDetail.lastLogin}</Card.Text>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Manager
                            </Card.Title>
                            <Card.Text>{userDetail.manager}</Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                Last Modified Date
                            </Card.Title>
                            <Card.Text>{DateUtil.format(userDetail.updatedAt)}</Card.Text>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Last Login Browser
                            </Card.Title>
                            <Card.Text>{userDetail.lastLoginBrowser}</Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                Last Login IP Address
                            </Card.Title>
                            <Card.Text>{userDetail.lastLoginIpAddress}</Card.Text>
                        </section>
                    </div>
                </Card.Body>
            </Card>
        </div>);
}

export default (UserDetailTab);