import React, {Component} from 'react';
import {connect} from "react-redux";
import * as actions from "../../../../actions";
import withEventBus from "../../../core/withEventBus";
import UUIDUtil from "../../../../util/UUIDUtil";

import PaginationUtil from "../../../../util/PaginationUtil";
import TopActionMenu from "../../../core/TopActionMenu";
import ObjectUtil from "../../../../util/ObjectUtil";
import ExportUtil from "../../../../util/ExportUtil";
import DataTableIDLink from "../../../core/DataTable/DataTableIDLink";
import DataTable from "../../../core/DataTable";
import DataTableDateField from "../../../core/DataTable/DataTableDateField";
import ConfirmWindow from "../../../core/ConfirmWindow";
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css

import DataTableUtil from "../../../../util/DataTableUtil";
import ReportWrapper from "../../../core/reportWrapper";
import ReactToPrint from "react-to-print";
import SearchOnTypeV2 from "../../../core/SearchOnTypeV2";

class UsersTab extends Component {

    static defaultProps = {
        onLoad: () => null
    };

    state = {
        tableViewName: UUIDUtil.v4(),
        selectedItems: [],
        prevSelectedItems: [],
        pagination: PaginationUtil.generatePaginationRequest(0, 50),
        lastPagination: "",
        filters: [],
        lastFilters: [],
        editMode: false,
        searchOnTypeValue: "",
        searchLoading: false,
        isPrinting: false,
    }

    constructor(props) {
        super(props);
        this.onTableViewChangeHandler = this.onTableViewChangeHandler.bind(this);
        this.onSelectedHandler = this.onSelectedHandler.bind(this);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
        this.updateFilter = this.updateFilter.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onExportHandler = this.onExportHandler.bind(this);
        this.onClearSelected = this.onClearSelected.bind(this);
        this.tableRef = null;
    }

    componentDidMount() {
        this.props.getUserTableFilters();
        this.loadTopMenuItems();
    }

    loadTopMenuItems() {

        const { selectedItems } = this.state;
        const isSectionEnabled = selectedItems.length < 1;
        const deleteLabel = isSectionEnabled ? "Delete" : `Delete (${selectedItems.length} selected)`;
        const deactivateLabel = isSectionEnabled ? "Deactivate" : `Deactivate (${selectedItems.length} selected)`;

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Add New" icon="plus" onClick={this.onAddClickHandler} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label={deleteLabel} icon="trash" onClick={(e) => console.log(e)} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label={deactivateLabel} icon="ban" onClick={() => this.onBulkChangeHandler('status')} />,
            <TopActionMenu.ButtonMenuItem label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print" icon="print" onClick={() => this.printRef.click()} />
        ], false);

    }

    onBulkChangeHandler(type) {
        const { bulkUpdateRecords } = this.props;
        const { selectedItems } = this.state;
        const self = this;


        const onBulkDeactivate = () => {
            const formData = {
                entityName: "User",
                fieldName: 'status',
                entityIds: selectedItems.map((item) => item.id),
                entityValues: ['inactive'],
                type: type,
                replace: true,
            }

            const internalIds = selectedItems.map((selectedItem) => selectedItem.internalId);

            bulkUpdateRecords(formData, (data, err) => {
                if (!err) {
                    self.onClearSelected();
                    self.executeSearch();
                    this.props.getUserTableFilters();
                    this.props.setSystemMessage("success", `Record ${internalIds.join(",")}, change User Status saved`)
                }
            })
        }

        const infoText = `Do you want to deactivate the ${selectedItems.length} selected records?`

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow headerText="Deactivate Record" infoText={infoText} onClose={onClose} onAction={onBulkDeactivate} />
        });
    }

    onClearSelected() {
        this.setState({ selectedItems: [] });
    }

    onExportHandler() {
        const { items } = this.props.users;
        const { selectedItems } = this.state;
        ExportUtil.generateCsv(this.getColumns(), (selectedItems.length > 0 ? selectedItems : items), "users");
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        const { prevSelectedItems, selectedItems } = this.state;

        if (prevSelectedItems.length !== selectedItems.length) {
            this.loadTopMenuItems();
            this.setState({ prevSelectedItems: ObjectUtil.clone(selectedItems) });
        }

        const self = this;
        PaginationUtil.searchWithFilter(this.state, state => {
            self.setState(state);
            self.executeSearch()
        });
    }

    onTableViewChangeHandler(event) {
        const state = this.state;
        state.pagination = event;
        this.setState(state);
        this.executeSearch()
    }

    onSearchTypeHandler(event) {
        this.updateFilter(event);
    }

    executeSearch() {

        this.setState({ searchLoading: true });
        const { pagination, filters } = this.state;

        const activeFilters = PaginationUtil.getActiveFilters(filters);
        this.props.getUserData(activeFilters, pagination, () => this.setState({ searchLoading: false }));
    }

    updateFilter(selectedFilter) {
        const state = this.state;
        let filterUpdated = false;
        state.filters.forEach((filter, index) => {
            if (filter.name === selectedFilter.name) {
                state.filters[index].value = selectedFilter.value;
                filterUpdated = true;
            }
        });
        if (!filterUpdated) {
            state.filters.push(selectedFilter);
        }
        this.setState(state);
    }

    onSelectedHandler(item) {
        this.setState({ selectedItems: item });
    }

    onAddClickHandler() {
        this.props.history.push('/admin/users/new');
    }

    getColumns() {

        const isOpenTab = (this.props.objectId !== 0 && this.props.objectId !== undefined);

        return [
            {
                label: "HiddenRefId",
                name: "referenceId",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "ID",
                name: "internalId",
                options: {
                    filter: false,
                    sort: true,
                    display: true,
                    customBodyRender: (value, tableMeta) =>
                        <DataTableIDLink newTab={isOpenTab}
                            value={value}
                            tableMeta={tableMeta}
                            uri="/admin/users"
                        />
                }
            },
            {
                label: "First Name",
                name: "firstName",
                options: {
                    sort: true,
                    display: false,
                    filter: false
                }
            },
            {
                label: "Last Name",
                name: "lastName",
                options: {
                    sort: true,
                    display: false,
                    filter: false
                }
            },
            {
                label: "Full Name",
                name: "fullName",
                options: {
                    sort: true,
                    display: true,
                    filter: false
                }
            },
            {
                label: "Title",
                name: "title",
                options: {
                    sort: true,
                    display: true,
                    filter: false
                }
            },
            {
                label: "Email",
                name: "email",
                options: {
                    sort: true,
                    display: true,
                    filter: false
                }
            },
            {
                label: "Mobile Phone",
                name: "mobilePhone",
                options: {
                    sort: true,
                    display: false,
                    filter: false,
                }
            },
            {
                label: "Manager",
                name: "managerName",
                options: {
                    sort: true,
                    display: true,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.managerNames)
                }
            },
            {
                label: "Role",
                name: "role",
                options: {
                    sort: true,
                    display: true,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.roles)
                }
            },
            {
                label: "Account Name",
                name: "accountName",
                options: {
                    filter: true,
                    sort: true,
                    display: false,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.accountNames)
                }
            },
            {
                label: "Last Login",
                name: "lastLoginAt",
                options: {
                    filter: false,
                    sort: true,
                    display: true,
                    customBodyRender: (value) => <DataTableDateField value={value} />,
                }
            },
            {
                label: "Last Login IP Address",
                name: "lastLoginIpAddress",
                options: {
                    filter: false,
                    sort: true,
                    display: false
                }
            },
            {
                label: "Last Login Browser",
                name: "lastLoginBrowser",
                options: {
                    sort: true,
                    display: false,
                    filter: false
                }
            },
            {
                label: "Status",
                name: "status",
                options: {
                    filter: true,
                    sort: true,
                    display: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.statuses)
                }
            },

        ]
    }

    render() {
        const { searchOnTypeValue, searchLoading, isPrinting } = this.state

        return (<div className="account-tab">
            <div className="single-content active">

                <div className="filter-form">
                    <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler} />
                </div>

                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.tableRef}
                    onBeforeGetContent={() => this.setState({ isPrinting: true })}
                    onAfterPrint={() => this.setState({ isPrinting: false })}
                />

                <ReportWrapper entityName="Manage Users" ref={el => (this.tableRef = el)} className="tab-container">
                    <DataTable
                        page={this.props.users}
                        loading={searchLoading}
                        columns={this.getColumns()}
                        isPrinting={isPrinting}
                        onPaginationChange={(e) => this.setState({ pagination: e })}
                        onFilterChange={(e) => this.setState({ filters: e })}
                        onSelected={this.onSelectedHandler}
                        title="Manage Users" />
                </ReportWrapper>
            </div>
        </div>);
    }
}

function mapStateToProps(state) {
    return {
        users: state.admin.users,
        tableFilters: state.admin.userTableFilters
    }
}

export default withEventBus(connect(mapStateToProps, actions)(UsersTab));
