import React from "react";
import { Card } from "react-bootstrap";

const UserPermissionDetail = (props) => {

    const headerText = "Permission";
    const userDetail = props.userdata;


    return (
        <div className="content-widget">
            <Card>
                <Card.Header>{headerText}</Card.Header>
                <Card.Body>
                    <Card.Text>The user role is for <b>CyberOne Security</b> account.
                        <a href="https://c1train.cyberonesec.com/v2-roles" target="_blank">Click here for role documentation</a>
                    </Card.Text>

                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Role
                            </Card.Title>
                            <Card.Text>
                                {userDetail.role}
                            </Card.Text>
                        </section>
                    </div>
                </Card.Body>
            </Card>
        </div>);
}

export default (UserPermissionDetail);