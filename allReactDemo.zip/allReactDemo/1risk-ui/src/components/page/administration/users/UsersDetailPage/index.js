import React, { Component } from "react";
import pageWrapper, { PAGE_TYPE_VIEW } from "../../../../core/pageWrapper";
import * as actions from "../../../../../actions"
import { connect } from "react-redux";
import PageUtil from "../../../../../util/PageUtil";
import BrowserUtil from "../../../../../util/BrowserUtil";
import TopActionMenu from "../../../../core/TopActionMenu";
import ReactToPrint from "react-to-print";
import ReportWrapper from "../../../../core/reportWrapper";
import BreadcrumbUtil from "../../../../../util/BreadcrumbUtil";
import { Card, Col, Row, Tab, Tabs, Image } from "react-bootstrap";
import StringUtil from "../../../../../util/StringUtil";
import '../../AdministrationPage.css'
import UserDetailTab from "./UserDetailTab";
import UserPermissionDetail from "./UserPermissionDetail";
import ImageThumbnailContainer from "../../../../core/ImageThumbnailContainer";

class UserDetailPage extends Component {
    state = {
        userDetail: {},
        activeTab: "details",
        tabs: [
            "details",
            "api-token",
            "settings"
        ]
    }

    constructor(props) {
        super(props);
        this.populatePage = this.populatePage.bind(this);
        this.populateHeader = this.populateHeader.bind(this);
        this.getObjectId = this.getObjectId.bind(this);
        this.onCancelHandler = this.onCancelHandler.bind(this)
        this.onEditClickHandler = this.onEditClickHandler.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onTabSelectHandler = this.onTabSelectHandler.bind(this);
    }

    componentDidMount() {
        this.selectTabByUrl();
        BrowserUtil.scrollToTop();
        this.populatePage();
        this.loadTopMenuItems();
    }

    getObjectId() {
        return this.props.userDetail?.id
    }

    populatePage() {
        this.pageUtil = new PageUtil(this.props);
        if (this.pageUtil.exists("id")) {
            const userId = this.pageUtil.get("id");
            // this.props.getAccountById(accountId, (response, err) => {
            //     if (err) {
            //         this.props.history.push("/admin/accounts")
            //     } else {
            //         this.props.getSubscriptionByAccountId(response.referenceId, (data, err) => {
            //             if (err) {
            //                 console.log(err);
            //             }
            //         })
            //     }
            // });
        }
    }

    loadTopMenuItems() {
        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Edit" icon="edit" onClick={this.onEditClickHandler} />,
            <TopActionMenu.ButtonMenuItem label="Delete" icon="trash" onClick={(e) => console.log(e)} />,
            <TopActionMenu.ButtonMenuItem label="Deactivate" icon="ban" onClick={(e) => console.log(e)} />,
            <TopActionMenu.ButtonMenuItem label="Print Screen" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuItem disabled label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload Template" icon="upload" onClick={(e) => console.log(e)} />
        ], false);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.userDetail !== this.props.userDetail && this.props.userDetail !== this.state.userDetail) {
            this.populateHeader(true);
            this.setState({ userDetail: this.props.userDetail });
        }

        if (this.props.match.params !== prevProps.match.params) {
            this.selectTabByUrl();
        }
    }

    selectTabByUrl() {
        const { tab } = this.props.match.params;
        const { tabs } = this.state;
        const selectedTab = tabs.filter((e) => e === tab);

        if (selectedTab.length > 0) {
            this.setState({ activeTab: tab });
        }

        this.populateHeader(true);

    }

    onTabSelectHandler(tabName) {

        // const { referenceId } = this.props.userDetail;

        const referenceId = "b4cc97c0-a192-4d47-be11-3133e873f250"
        this.setState({ activeTab: tabName });

        const url = `/admin/users/${referenceId}`;

        if (tabName === "details") {
            this.loadTopMenuItems();
            this.props.history.push(url);
        } else {
            this.props.history.push(url + "/" + tabName);
        }

    }

    populateHeader(init = false) {
        this.pageUtil = new PageUtil()
        // const { internalId, referenceId } = this.props.userDetail;
        const internalId = '200212';
        const referenceId = 'ee02cf1d-7b6e-4f31-9476-eed2b30f409f';

        const { activeTab } = this.state;
        if (internalId) {
            let breadcrumb = BreadcrumbUtil.createRequest("Admin", internalId, true);
            if (activeTab !== "details") {
                const prev = breadcrumb;
                prev.uri = `/admin/users/${referenceId}`;
                breadcrumb = BreadcrumbUtil.createRequest("Admin", StringUtil.toTitleCase(activeTab), false, prev);
            }
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_VIEW, "Manage Accounts")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }
    }

    onEditClickHandler = (event) => {
        const userDetail = this.props.userDetail
        this.props.history.push(`/admin/users/edit/${userDetail.referenceId}`);
        event.preventDefault();
    }

    onCancelHandler = (event) => {
        const redirectUrl = "/admin/users";
        this.props.history.push(redirectUrl);
        event.preventDefault();
    }

    render() {
        // const { createdAt, updatedAt, ownerName, internalId, logoUrl, referenceId, defaultAccount } = this.props.userDetail;
        const userdata = {
            internalId: '200212',
            fullName: 'Lily Yeoh',
            title: 'Product Manager',
            email: 'cb1@security.com',
            mobilePhone: '123-123-1234',
            managerName: 'Michael Smith',
            createdAt: '05/26/2020 5:16:41 PM',
            updatedAt: '05/26/2020 5:16:41 PM',
            lastLogin: '05/28/2020',
            status: 'Inactive',
            role: 'Admin',
            lastLoginIpAddress: '42.108.201.203',
            lastLoginBrowser: 'Chrome 81.0.4044'
        }
        return (
            <div>
                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.contentRef}
                />
                <ReportWrapper entityName="User" ref={el => (this.contentRef = el)}>
                    <section id="content-wrap" className="right-content-wrap">
                        <Row className="tab-wrap">
                            <Col lg={12}>
                                <Tabs mountOnEnter={true} unmountOnExit={true} activeKey={this.state.activeTab} onSelect={this.onTabSelectHandler}>
                                    <Tab eventKey="details" title="Details">
                                        <Row>
                                            <Col lg={9} className="left-col">
                                                <UserDetailTab userdata={userdata} />
                                                <UserPermissionDetail userdata={userdata} />
                                            </Col>
                                            <Col lg={3} className="right-col">
                                                <Card>
                                                    <Card.Header>
                                                        Profile Image
                                                    </Card.Header>
                                                    <Card.Body>
                                                        <ImageThumbnailContainer src="https://1risk-files.s3.amazonaws.com/public/dev/account/CyberOneThumbnail.png" alt="Logo" />
                                                    </Card.Body>
                                                </Card>
                                            </Col>
                                        </Row>
                                    </Tab>
                                    <Tab eventKey="api-token" title="API Token">
                                        <div>Api token</div>
                                    </Tab>
                                    <Tab eventKey="settings" title="Settings">
                                        <div>App Settings</div>
                                    </Tab>
                                </Tabs>
                            </Col>
                        </Row>
                    </section>
                </ReportWrapper>
            </div>
        )
    }
}

const mapStateToProps = (state) => {

    return ({
        accountDetail: state.admin.accountDetail,
    })
}

export default pageWrapper(connect(mapStateToProps, actions)(UserDetailPage));