import React, { Component } from 'react';
import { Col, Row, Tab, Tabs } from "react-bootstrap";
import pageWrapper, { PAGE_TYPE_LIST } from "../../core/pageWrapper";
import withEventBus from "../../core/withEventBus";
import PageUtil from "../../../util/PageUtil";

import { OBLIGATION_VIEW_CHANGED } from "../../../events/types";
import AccountsTab from "./accounts/AccountsTab"
import UsersTab from "./users/UsersTab";
import { connect } from "react-redux";
import * as actions from "../../../actions";
import './AdministrationPage.css'

class AdministrationPage extends Component {

    constructor(props) {
        super(props);
        this.state = {
            listViewMode: false,
            activeTab: "accounts",
            tabs: [
                {
                    eventKey: "accounts",
                    title: "Manage Accounts",
                    component: <AccountsTab {...this.props} />
                },
                {
                    eventKey: "users",
                    title: "Manage Users",
                    component: <UsersTab {...this.props} />
                },
                {
                    eventKey: "notifications",
                    title: "Email Notifications",
                    component: <div>Email Notifications container</div>
                },
                {
                    eventKey: "logs",
                    title: "Logs",
                    component: <div>Logs container</div>
                },
            ]
        }
        this.onTabSelectHandler = this.onTabSelectHandler.bind(this);
        this.toggleListViewMode = this.toggleListViewMode.bind(this);
    }

    componentDidMount() {
        this.selectTabByUrl();
        this.props.getAccountsData();
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (this.props.match.params !== prevProps.match.params) {
            this.selectTabByUrl();
        }
    }

    selectTabByUrl() {
        const pageUtil = new PageUtil();
        const { tab } = this.props.match.params;
        const { tabs } = this.state;
        const selectedTab = tabs.filter((e) => e.eventKey === tab);

        if (selectedTab.length > 0) {
            const breadcrumb = { "title": "Administration", "label": selectedTab[0].title, "init": true };
            const pageDescription = pageUtil.generatePageDescriptionRequest(PAGE_TYPE_LIST, selectedTab[0].title)
            const event = pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
            this.setState({ activeTab: tab });
        } else {
            const breadcrumb = { "title": "Administration", "label": "Manage Accounts", "init": true };
            const pageDescription = pageUtil.generatePageDescriptionRequest(PAGE_TYPE_LIST, selectedTab[0].title)
            const event = pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }
    }

    onTabSelectHandler(tabName, event) {
        this.setState({ activeTab: tabName });
        if (tabName === "accounts") {
            this.props.history.push("/admin");
        } else {
            this.props.history.push("/admin/" + tabName);
        }
    }

    toggleListViewMode() {
        this.setState({ listViewMode: !this.state.listViewMode });
        this.props.eventBus.dispatch(OBLIGATION_VIEW_CHANGED, this.state.listViewMode);
    }

    render() {
        const { tabs } = this.state;
        return (<section id="content-wrap" className="right-content-wrap">
            <div className="inner-content">
                <Row className="tab-wrap, grc-content">
                    <Col lg={12}>
                        <Tabs mountOnEnter={true} unmountOnExit={true} activeKey={this.state.activeTab} onSelect={this.onTabSelectHandler}>
                            {tabs.map((tab, index) => {
                                return (<Tab key={`administration-tab-${index}`} eventKey={tab.eventKey} title={tab.title}>
                                    {tab.component}
                                </Tab>)
                            })}
                        </Tabs>
                    </Col>
                </Row>
            </div>
        </section>)
    }
}

export default withEventBus(pageWrapper(connect(null, actions)(AdministrationPage)));