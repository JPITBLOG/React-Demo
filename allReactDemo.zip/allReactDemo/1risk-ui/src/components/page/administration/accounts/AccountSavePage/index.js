import React, {Component} from 'react';
import ActionOverlay from "../../../../core/ActionOverlay";
import {Button, Card, Col, Row} from "react-bootstrap";
import IconButton from "../../../../core/button/IconButton";
import pageWrapper, {PAGE_TYPE_EDIT} from "../../../../core/pageWrapper";
import PageUtil from "../../../../../util/PageUtil";
import {connect} from "react-redux";
import * as actions from '../../../../../actions/';
import ImageDropzone from "../../../../core/ImageDropzone";
import {SAVE_ACCOUNT_FORM, VALIDATE_ACCOUNT_FORM} from "../../../../../events/types";
import ArrayUtil from "../../../../../util/ArrayUtil";
import AccountInfoSavePage from "./AccountInfoSavePage";
import AccountSubscriptionSavePage from "./AccountSubscriptionSavePage";
import AccountLimitSavePage from "./AccountLimitSavePage";
import moment from 'moment';

class AccountSavePage extends Component {

    state = {
        accountDetail: {},
        requiredFields: ["accountName", "customerSupportLevel", "contractTerm", "startDate", "endDate", "autoRenewal"],
        lastLogoUrl: "",
        uploadInProgress: false,
        lastSavedId: "",
        id: 0
    }

    componentDidMount() {

        this.pageUtil = new PageUtil(this.props);
        if (this.pageUtil.exists("id") && this.pageUtil.get("id") !== undefined) {
            const { accountDetail } = this.props;
            if (accountDetail.id === undefined) {
                const accountId = this.pageUtil.get("id");
                this.props.getAccountById(accountId);
            } else {
                this.setState({ accountDetail: this.props.accountDetail });
            }
            const breadcrumb = { "title": "Admin", "label": "Edit", "init": false };
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_EDIT, "Accounts")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }
        window.addEventListener(SAVE_ACCOUNT_FORM, this.onSaveHandler);
    }

    componentWillUnmount() {
        window.removeEventListener(SAVE_ACCOUNT_FORM, this.onSaveHandler);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        if (prevProps.accountDetail !== this.props.accountDetail) {

            const state = this.state;

            const { internalId } = this.props.accountDetail;
            const breadcrumb = { "title": "Admin", "label": `${internalId}`, "init": false };
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb)
            this.props.onPageLoad(event);

            state.accountDetail = this.props.accountDetail;
            this.setState(state);
        }
    }

    constructor(props) {
        super(props);
        this.onCancelHandler = this.onCancelHandler.bind(this);
        this.onImageLoadHandler = this.onImageLoadHandler.bind(this);
        this.onImageClearHandler = this.onImageClearHandler.bind(this);
        this.onMainFormChange = this.onMainFormChange.bind(this);
        this.onClickSaveHandler = this.onClickSaveHandler.bind(this);
        this.onSaveHandler = this.onSaveHandler.bind(this);
        this.onTagsChangeHandler = this.onTagsChangeHandler.bind(this);
    }

    onSaveHandler(event) {
        const { accountDetail, lastLogoUrl } = this.state;
        if (lastLogoUrl !== "") {
            accountDetail.logoUrl = lastLogoUrl;
        }

        const accountsData = {
            "accountName": accountDetail.accountName,
            "id": accountDetail.id,
            "industry": accountDetail.industry,
            "internalId": accountDetail.internalId,
            "logoUrl": accountDetail.logoUrl,
            "numberOfEmployee": accountDetail.numberOfEmployee,
            "referenceId": accountDetail.referenceId,
            "website": accountDetail.website
        }

        const accountSubscription = {
            "accountId": accountDetail.id,
            "autoRenewal": accountDetail.subscription ? accountDetail.subscription.autoRenewal : true,
            "contractTerm": accountDetail.subscription ? accountDetail.subscription.contractTermOrd : 0,
            "customerSupportLevel": accountDetail.subscription ? accountDetail.subscription.customerSupportLevel.toUpperCase() : "BASIC",
            "endDate": accountDetail.subscription ? accountDetail.subscription.endDate : moment(new Date(), "MM/dd/yyyy").add(2, 'week'),
            "id": accountDetail.subscription ? accountDetail.subscription.id : 0,
            "startDate": accountDetail.subscription ? accountDetail.subscription.startDate : new Date(),
            "subscriptionLimit": {
                "admin": accountDetail.subscription ? accountDetail.subscription.subscriptionLimit.adminLimit : 2,
                "control": accountDetail.subscription ? accountDetail.subscription.subscriptionLimit.controlLimit : 10,
                "general": accountDetail.subscription ? accountDetail.subscription.subscriptionLimit.generalLimit : 2,
                "programManager": accountDetail.subscription ? accountDetail.subscription.subscriptionLimit.programManagerLimit : 2,
                "risk": accountDetail.subscription ? accountDetail.subscription.subscriptionLimit.riskLimit : 10,
                "target": accountDetail.subscription ? accountDetail.subscription.subscriptionLimit.targetLimit : 10,
                "readOnly": accountDetail.subscription ? accountDetail.subscription.subscriptionLimit.readOnlyLimit : 2,
                "issue": accountDetail.subscription ? accountDetail.subscription.subscriptionLimit.issueLimit : 10
            }
        };

        this.props.saveAccounts(accountsData, (data, err) => {
            if (data && !err) {
                this.props.saveSubscriptions(accountSubscription, (data, err) => {
                    if (data && !err) {
                        const accountId = this.pageUtil.get("id");
                        this.props.history.push(`/admin/accounts/${accountId}`);
                    }
                });
            }
        });
    }

    onCancelHandler(event) {
        let redirectUrl = "/admin/accounts";
        if (this.pageUtil.exists("id")) {
            redirectUrl += "/" + this.pageUtil.get("id");
        }
        this.props.history.push(redirectUrl);
        event.preventDefault();
    }

    onClickSaveHandler(event) {
        window.dispatchEvent(new CustomEvent(VALIDATE_ACCOUNT_FORM, { detail: this.state.requiredFields }));
    }

    onImageLoadHandler(event) {
        event.bucketPath = "/public/dev/accounts";
        this.setState({ uploadInProgress: true });
        this.props.uploadLogo(event, (location, err) => {
            if (!err) {
                const { accountDetail } = this.state;
                accountDetail.logoUrl = location;
                this.setState({ accountDetail });
                this.setState({ lastLogoUrl: location });
            }
            this.setState({ uploadInProgress: false });
        });
    }

    onImageClearHandler() {
        const { accountDetail } = this.state;
        accountDetail.logoUrl = "";
        this.setState({ accountDetail });
    }

    onMainFormChange(event) {
        const state = this.state;
        state.accountDetail = Object.assign(state.accountDetail, event);
        this.setState(state);
    }

    onTagsChangeHandler(event) {
        if (!event.value) {
            console.log("invalidEvent");
            return;
        }
        const state = this.state;
        const resultList = ArrayUtil.parseToStringCollection(event.value);
        state.accountDetail[event.fieldName] = resultList;
        this.setState(state);
    }

    render() {
        const { accountDetail, uploadInProgress } = this.state;
        return (<div className="save-container">
            <ActionOverlay visible={true}>
                <ActionOverlay.Actions>
                    <IconButton onClick={this.onClickSaveHandler} icon="check">Save</IconButton>
                    <Button onClick={this.onCancelHandler} variant="secondary">Cancel</Button>
                </ActionOverlay.Actions>
            </ActionOverlay>

            <Row>
                <Col lg={9} className="left-container">
                    <AccountInfoSavePage onInvalidate={(e) => this.setState({ invalid: e })} onChange={this.onMainFormChange} data={accountDetail} />
                    <AccountSubscriptionSavePage onInvalidate={(e) => this.setState({ invalid: e })} onChange={this.onMainFormChange} data={accountDetail} />
                    <AccountLimitSavePage onInvalidate={(e) => this.setState({ invalid: e })} onChange={this.onMainFormChange} data={accountDetail} />
                    {/*<GrcLibrarySetting {...this.props} />*/}
                </Col>
                <Col lg={3} className="right-container">
                    <Card>
                        <Card.Header>Logo</Card.Header>
                        <Card.Body>
                            <ImageDropzone infoText="Drop company logo here or" loading={uploadInProgress} onLoad={this.onImageLoadHandler} onClear={this.onImageClearHandler} imageUrl={accountDetail.logoUrl} />
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

        </div>)
    }
}

const mapStateToProps = (state) => {
    return ({
        accountDetail: state.admin.accountDetail,
    })
}

export default pageWrapper(connect(mapStateToProps, actions)(AccountSavePage));