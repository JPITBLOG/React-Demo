import React, { Component, createRef } from "react";
import { Card, Form, Row, Col } from "react-bootstrap";
import { SAVE_ACCOUNT_FORM, VALIDATE_ACCOUNT_FORM } from "../../../../../events/types";
import { connect } from "react-redux";
import * as actions from "../../../../../actions";
import AttachTooltip from "../../../../core/AttachItemTooltip";

class AccountLimitSavePage extends Component {

    static defaultProps = {
        data: {
            id: 0
        },
        onChange: () => null
    }

    constructor(props) {
        super(props);
        this.onFormChangeHandler = this.onFormChangeHandler.bind(this);
        this.onFormControlChange = this.onFormControlChange.bind(this);
        this.onBlurFormControlHandler = this.onBlurFormControlHandler.bind(this);
        this.onSaveFormListener = this.onSaveFormListener.bind(this);
        this.formRef = createRef();
    }

    state = {
        formData: {
            subscriptionLimit: {
                id: 0,
                adminLimit: 2,
                targetLimit: 10,
                programManagerLimit: 2,
                controlLimit: 10,
                generalLimit: 2,
                readOnlyLimit:2,
                riskLimit: 10,
                issueLimit: 10
            }
        },
        invalidFields: [],
    }


    onFormChangeHandler(event) {
        this.props.onChange(event);
    }

    onFormControlChange(event) {
        const { formData } = this.state;
        const { id, value } = event.target;
        formData.subscriptionLimit[id] = value;

        this.setState({ formData });
        this.onFormChangeHandler(formData);

        event.preventDefault();
    }


    componentDidMount() {
        if (this.props.data.id && this.props.data.id !== 0) {
            this.setState({ formData: { ...this.state.formData, subscriptionLimit: this.props.data.subscription.subscriptionLimit } });
        }
        window.addEventListener(VALIDATE_ACCOUNT_FORM, this.onSaveFormListener);
    }

    onSaveFormListener(event) {
        const state = this.state;

        if (this.formRef && this.formRef.current) {
            const isValid = this.formRef.current.checkValidity()
            this.props.onInvalidate(!isValid);

            if (!isValid) {
                state.invalidFields = [];
                event.detail.forEach((fieldName) => {
                    if (state.formData.subscriptionLimit[fieldName] !== undefined && state.formData.subscription.subscriptionLimit[fieldName] === "") {
                        state.invalidFields.push(fieldName);
                    }
                })
                this.setState(state);
            } else {
                window.dispatchEvent(new Event(SAVE_ACCOUNT_FORM));
            }
        }

    }

    componentWillUnmount(): void {
        window.removeEventListener(VALIDATE_ACCOUNT_FORM, this.onSaveFormListener);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.data !== this.props.data && this.props.data.subscription) {
            this.setState({ formData: { ...this.state.formData, subscriptionLimit: this.props.data.subscription?.subscriptionLimit } });
        }
    }

    onBlurFormControlHandler(event) {
        const state = this.state;
        const target = event.currentTarget;
        if (target.required) {
            if (target.value.length === 0) {
                if (!state.invalidFields.includes(target.id)) {
                    state.invalidFields.push(target.id);
                }
            } else {
                if (state.invalidFields.includes(target.id)) {
                    const filteredList = state.invalidFields.filter(value => value !== target.id);
                    state.invalidFields = filteredList;
                }
            }
        }
        this.setState(state);
    }

    render() {

        const { subscriptionLimit } = this.state.formData;

        return (
            <Card>
                <Card.Header>Limit</Card.Header>
                <Card.Body>
                    <Form onSubmit={(e) => e.preventDefault()}>
                        <Row>
                            <Col lg={5}>
                                <Form.Group>
                                    <AttachTooltip title="Users with all access to the platform and perform system admin role." placement="top-start">
                                        <Form.Label>Admin User</Form.Label>
                                    </AttachTooltip>
                                    <Form.Control
                                        type="text"
                                        placeholder="eg. 2"
                                        id="adminLimit"
                                        defaultValue={subscriptionLimit.adminLimit}
                                        onChange={this.onFormControlChange}
                                        onBlur={this.onBlurFormControlHandler}
                                    />
                                </Form.Group>
                            </Col>
                            <Col lg={5}>
                                <Form.Group>
                                    <AttachTooltip title="Including asset related metrics." placement="top-start">
                                        <Form.Label>Target</Form.Label>
                                    </AttachTooltip>
                                    <Form.Control
                                        placeholder="eg. 2"
                                        id="targetLimit"
                                        defaultValue={subscriptionLimit.targetLimit}
                                        onChange={this.onFormControlChange}
                                        onBlur={this.onBlurFormControlHandler}
                                    />
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg={5}>
                                <Form.Group>
                                    <AttachTooltip title="Users with all access to the platform without system admin function." placement="top-start">
                                        <Form.Label>Manager User</Form.Label>
                                    </AttachTooltip>
                                    <Form.Control type="text"
                                        placeholder="eg. 20" id="programManagerLimit"
                                        defaultValue={subscriptionLimit.programManagerLimit}
                                        onChange={this.onFormControlChange}
                                        onBlur={this.onBlurFormControlHandler}
                                    />
                                </Form.Group>
                            </Col>
                            <Col lg={5}>
                                <Form.Group>
                                    <AttachTooltip title="Including control related metrics." placement="top-start">
                                        <Form.Label>Control</Form.Label>
                                    </AttachTooltip>
                                    <Form.Control
                                        placeholder="eg. 20"
                                        id="controlLimit"
                                        defaultValue={subscriptionLimit.controlLimit}
                                        onChange={this.onFormControlChange}
                                        onBlur={this.onBlurFormControlHandler}
                                    />
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg={5}>
                                <Form.Group>
                                    <AttachTooltip title="Users with limited access to read/write." placement="top-start">
                                        <Form.Label>General User</Form.Label>
                                    </AttachTooltip>
                                    <Form.Control type="text"
                                        placeholder="eg. 20" id="generalLimit"
                                        defaultValue={subscriptionLimit.generalLimit}
                                        onChange={this.onFormControlChange}
                                        onBlur={this.onBlurFormControlHandler}
                                    />
                                </Form.Group>
                            </Col>
                            <Col lg={5}>
                                <Form.Group>
                                    <AttachTooltip title="Including Risk related metrics" placement="top-start">
                                        <Form.Label>Risk</Form.Label>
                                    </AttachTooltip>
                                    <Form.Control
                                        placeholder="eg. 20"
                                        id="riskLimit"
                                        defaultValue={subscriptionLimit.riskLimit}
                                        onChange={this.onFormControlChange}
                                        onBlur={this.onBlurFormControlHandler}
                                    />
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg={5}>
                                <Form.Group>
                                    <AttachTooltip title="Users with read-only access" placement="top-start">
                                        <Form.Label>Read-Only User</Form.Label>
                                    </AttachTooltip>
                                    <Form.Control type="text"
                                        placeholder="eg. 20" id="readOnlyLimit"
                                        defaultValue={subscriptionLimit.readOnlyLimit}
                                        onChange={this.onFormControlChange}
                                        onBlur={this.onBlurFormControlHandler}
                                    />
                                </Form.Group>
                            </Col>
                            <Col lg={5}>
                                <Form.Group>
                                    <AttachTooltip title="Including risk mitigation metrics" placement="top-start">
                                        <Form.Label>Issue</Form.Label>
                                    </AttachTooltip>
                                    <Form.Control type="text"
                                        placeholder="eg. 20" id="issueLimit"
                                        defaultValue={subscriptionLimit.issueLimit}
                                        onChange={this.onFormControlChange}
                                        onBlur={this.onBlurFormControlHandler}
                                    />
                                </Form.Group>
                            </Col>
                        </Row>
                    </Form>
                </Card.Body>
            </Card>
        );
    }
}

export default connect(null, actions)(AccountLimitSavePage);