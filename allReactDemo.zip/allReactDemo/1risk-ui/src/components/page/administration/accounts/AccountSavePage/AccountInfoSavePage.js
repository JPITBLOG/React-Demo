import React, { Component, createRef } from "react";
import { Card, Form } from "react-bootstrap";
import { SAVE_ACCOUNT_FORM, VALIDATE_ACCOUNT_FORM } from "../../../../../events/types";
import FormSelector from "../../../../core/FormSelector";
import ArrayUtil from "../../../../../util/ArrayUtil";
import { connect } from "react-redux";
import * as actions from "../../../../../actions";

class AccountInfoSavePage extends Component {

    static defaultProps = {
        data: {
            id: 0
        },
        onChange: () => null
    }

    constructor(props) {
        super(props);
        this.onFormChangeHandler = this.onFormChangeHandler.bind(this);
        this.onFormControlChange = this.onFormControlChange.bind(this);
        this.onBlurFormControlHandler = this.onBlurFormControlHandler.bind(this);
        this.onSaveFormListener = this.onSaveFormListener.bind(this);
        this.formRef = createRef();
    }

    state = {
        formData: {
            id: 0,
            accountName: "",
            numberOfEmployee: "",
            website: "",
            industry: ""
        },
        invalidFields: [],
        industryOption:[],
        employeeOption:[],
    }

    onFormChangeHandler(event) {
        this.props.onChange(event);
    }

    onFormControlChange(event) {
        const { formData } = this.state;
        const { id, value } = event.target;
        formData[id] = value;

        this.setState({ formData });
        this.onFormChangeHandler(formData);
    }


    componentDidMount() {
        if (this.props.data.id && this.props.data.id !== 0) {
            this.setState({ formData: this.props.data });
        }
        window.addEventListener(VALIDATE_ACCOUNT_FORM, this.onSaveFormListener);
        this.props.getAccountOptions("employees");
        this.props.getAccountOptions("industry");
    }

    onSaveFormListener(event) {
        const state = this.state;

        if (this.formRef && this.formRef.current) {
            const isValid = this.formRef.current.checkValidity()
            this.props.onInvalidate(!isValid);

            if (!isValid) {
                state.invalidFields = [];
                event.detail.forEach((fieldName) => {
                    if (state.formData[fieldName] !== undefined && state.formData[fieldName] === "") {
                        state.invalidFields.push(fieldName);
                    }
                })
                this.setState(state);
            } else {
                window.dispatchEvent(new Event(SAVE_ACCOUNT_FORM));
            }
        }

    }

    componentWillUnmount(): void {
        window.removeEventListener(VALIDATE_ACCOUNT_FORM, this.onSaveFormListener);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.data !== this.props.data) {
            this.setState({ formData: this.props.data });
        }
        if(prevProps.accountOptions!==this.props.accountOptions){
            const {fieldName,items} = this.props.accountOptions;
            switch (fieldName) {
                case "employees":
                    this.setState({ employeeOption: items })
                    break;
                case "industry":
                    this.setState({ industryOption: items })
                    break;
                default:
                    console.log("options not in use: "+fieldName);
            }
        }
    }

    onBlurFormControlHandler(event) {
        const state = this.state;
        const target = event.currentTarget;
        if (target.required) {
            if (target.value.length === 0) {
                if (!state.invalidFields.includes(target.id)) {
                    state.invalidFields.push(target.id);
                }
            } else {
                if (state.invalidFields.includes(target.id)) {
                    const filteredList = state.invalidFields.filter(value => value !== target.id);
                    state.invalidFields = filteredList;
                }
            }
        }
        this.setState(state);
    }

    render() {

        const { accountName, numberOfEmployee, website, industry } = this.state.formData;
        const { employeeOption,industryOption } = this.state;

        return (
            <Card>
                <Card.Header> Account Info</Card.Header>
                <Card.Body>
                    <Form onSubmit={(e) => e.preventDefault()} ref={this.formRef}>
                        <Form.Group>
                            <Form.Label>Account Name*</Form.Label>
                            <Form.Control required type="text"
                                placeholder=""
                                id="accountName"
                                defaultValue={accountName}
                                onChange={this.onFormControlChange}
                                onBlur={this.onBlurFormControlHandler}
                                isInvalid={this.state.invalidFields.includes("accountName")}
                            />
                            <Form.Control.Feedback type="invalid">
                                Field is required
                                </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Number Of Employee</Form.Label>
                            <FormSelector
                                id="numberOfEmployee"
                                value={ArrayUtil.getItemByValue(employeeOption, "value", numberOfEmployee)}
                                name="numberOfEmployee"
                                classNamePrefix="select"
                                isSearchable
                                options={employeeOption}
                                onBlur={this.onBlurFormControlHandler}
                                onChange={this.onFormControlChange}
                            />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Website</Form.Label>
                            <Form.Control
                                placeholder=""
                                id="website"
                                defaultValue={website}
                                onChange={this.onFormControlChange}
                                onBlur={this.onBlurFormControlHandler}
                            />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Industry</Form.Label>
                            <FormSelector
                                id="industry"
                                value={ArrayUtil.getItemByValue(industryOption, "value", industry)}
                                name="industry"
                                classNamePrefix="select"
                                isSearchable
                                options={industryOption}
                                onBlur={this.onBlurFormControlHandler}
                                onChange={this.onFormControlChange}
                            />
                        </Form.Group>
                    </Form>
                </Card.Body>
            </Card>)
    }

}

const mapStateToProps = (state) => {
    return ({
        accountOptions: state.admin.accountOptions
    })
}

export default connect(mapStateToProps, actions)(AccountInfoSavePage)