import React from "react";
import { Card, Col, Row } from "react-bootstrap";
import DateUtil from "../../../../../util/DateUtil";
import { Button } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { activateSubscription, setSystemMessage } from '../../../../../actions/';
import StatusLabel, {ACCOUNT_ACTIVE_STATUS, ACCOUNT_INACTIVE_STATUS} from "../../../../core/StatusLabel";
import moment from "moment";

const AccountSubscriptionDetail = (props) => {

    const headerText = "Subscription";
    let subscription = props.subscriptionDetail;
    const dispatch = useDispatch();

    const onActivateClick = (event) => {
        if (!subscription) {
            dispatch(setSystemMessage("danger", "Account activation failed. Missing subscription data."))
        }
        else if (props.defaultAccount) {
            dispatch(setSystemMessage("danger", "Default account cannot be deactivated."))
        }
        else {
            dispatch(activateSubscription(props.referenceId));
        }
        event.preventDefault();
    }

    if (!subscription) {
        subscription = {
            customerSupportLevel: "Basic",
            contractTermOrd: 0,
            startDate: new Date(),
            endDate: moment(new Date(), "MM/dd/yyyy").add(2, 'week'),
            autoRenewal: true,
        }
    }

    return (
        <div className="content-widget">
            <Card>
                <Card.Header>
                    <Row>
                        <Col lg={10}>{headerText}</Col>
                        <Col className="account-right-header" lg={2}>
                            {subscription?.active ? <Button variant="outline-secondary" onClick={onActivateClick}>Deactivate</Button> : <Button variant="primary" onClick={onActivateClick}>Activate</Button>}
                        </Col>
                    </Row>
                </Card.Header>
                <Card.Body>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                License Key
                            </Card.Title>
                            <Card.Text>
                                <StatusLabel status={subscription?.active ? ACCOUNT_ACTIVE_STATUS : ACCOUNT_INACTIVE_STATUS}>
                                    {subscription?.licenseKey}
                                </StatusLabel>
                            </Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>Custom Support Level</Card.Title>
                            <Card.Text>{subscription?.customerSupportLevel}</Card.Text>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Start Date
                            </Card.Title>
                            <Card.Text>{DateUtil.format(subscription?.startDate)}</Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                End Date
                            </Card.Title>
                            <Card.Text>{DateUtil.format(subscription?.endDate)}</Card.Text>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Contract Term
                        </Card.Title>
                            <Card.Text>{subscription?.contractTerm}</Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                Auto-Renewal
                        </Card.Title>
                            <Card.Text>{subscription?.autoRenewal ? "Yes" : "No"}</Card.Text>
                        </section>
                    </div>
                </Card.Body>
            </Card>
        </div>);
}

export default (AccountSubscriptionDetail);