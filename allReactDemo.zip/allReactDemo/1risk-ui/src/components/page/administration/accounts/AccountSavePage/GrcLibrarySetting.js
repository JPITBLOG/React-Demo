import React, { Component } from "react";
import {Button, Card, Form} from "react-bootstrap";
import TagAutocomplete from "../../../../core/TagAutocomplete";
import * as actions from "../../../../../actions/"
import { connect } from "react-redux";
import ArrayUtil from "../../../../../util/ArrayUtil";

class GrcLibrarySetting extends Component {

    static defaultProps = {
        data: {
            id: 0
        },
        onChange: () => null
    }

    state = {
        selectedTags: [],
        data: {
            id: 0
        },
        obligations: [],

    }

    constructor(props) {
        super(props);
        this.onSelectorChangeHandler = this.onSelectorChangeHandler.bind(this);
        this.onRemoveAllObligations = this.onRemoveAllObligations.bind(this);
        this.onSelectAllObligations = this.onSelectAllObligations.bind(this)
    }

    componentDidMount() {
        if (this.props.obligationsFilterData.length === 0) {
            this.props.getObligationFilter();
        } else {
            this.setState({ obligations: this.props.obligationsFilterData });
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        if (prevProps.obligationsFilterData !== this.props.obligationsFilterData) {
            this.setState({ obligations: this.props.obligationsFilterData });
        }

        if (prevProps.data !== this.props.data) {

            const { tags } = this.props.data;

            const state = this.state;
            state.data = this.props.data;

            state.selectedTags = ArrayUtil.parseToDropdownCollection(tags);
            this.setState(state);
        }

        if (prevProps.savedTagData !== this.props.savedTagData) {

            let { tags } = this.props.data;
            const state = this.state;

            const { fieldName, value } = this.props.savedTagData;
            switch (fieldName) {
                case "tags":
                    tags = ArrayUtil.addToCollection(tags, value);
                    state.selectedTags = ArrayUtil.parseToDropdownCollection(tags);
                    this.props.onChange({
                        fieldName: "tags",
                        value: this.state.selectedTags
                    })
                    break;
                default:
                    break;
            }

            this.setState(state);
        }

        if (prevProps.entityTagsData !== this.props.entityTagsData) {

            const state = this.state;

            const { entityTagsData } = this.props;
            const data = entityTagsData.map((item) => {
                return { label: item.value, value: item.value }
            });
            if (data.length > 0) {
                const fieldName = entityTagsData[0].fieldName;
                switch (fieldName) {
                    case "tags":
                        state.tagsOptions = data;
                        break;
                    default:
                        break;
                }
            }
            this.setState(state);
        }
    }

    onSelectorChangeHandler(event) {
        const fieldName = event.id.split("-")[0];
        const state = this.state;
        state[`selectedTags`] = event.value;
        this.setState(state);
        this.props.onChange({
            fieldName: fieldName,
            value: event.value
        })
    }

    onRemoveAllObligations(event) {
        this.setState({ selectedTags: [] });
        event.preventDefault()
    }

    onSelectAllObligations(event) {
        this.setState({ selectedTags: this.state.obligations })
        event.preventDefault()
    }

    render() {
        const { selectedTags, obligations } = this.state;
        return (
            <Card>
                <Card.Header>Grc Library Settings</Card.Header>
                <Card.Body>
                    <Form>
                        <Form.Group>
                            <Form.Label>GRC Library</Form.Label>
                            <Card.Text>Add the Obligation Name to include in your GRC Library for this account.</Card.Text>
                            <TagAutocomplete
                                id="tags"
                                options={obligations}
                                onChange={this.onSelectorChangeHandler}
                                value={selectedTags} />
                        </Form.Group>
                        <Button variant="link" onClick={this.onSelectAllObligations}>Select All</Button> | <Button variant="link" onClick={this.onRemoveAllObligations}>Remove All</Button>
                    </Form>
                </Card.Body>
            </Card>
        );
    }
}

const mapStateToProps = (state) => {
    return ({
        obligationsFilterData: state.searchFilter.obligationsFilterData,
        entityTagsData: state.searchFilter.entityTagsData,
        savedTagData: state.searchFilter.savedTagData
    })
}

export default connect(mapStateToProps, actions)(GrcLibrarySetting);