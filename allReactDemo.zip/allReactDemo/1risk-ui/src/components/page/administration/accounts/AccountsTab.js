import React, { Component } from 'react';
import { connect } from "react-redux";
import * as actions from "../../../../actions";
import withEventBus from "../../../core/withEventBus";
import UUIDUtil from "../../../../util/UUIDUtil";

import PaginationUtil from "../../../../util/PaginationUtil";
import TopActionMenu from "../../../core/TopActionMenu";
import ObjectUtil from "../../../../util/ObjectUtil";
import ExportUtil from "../../../../util/ExportUtil";
import ConfirmWindow from "../../../core/ConfirmWindow";
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import DataTableIDLink from "../../../core/DataTable/DataTableIDLink";
import DataTable from "../../../core/DataTable";

import DataTableUtil from "../../../../util/DataTableUtil";
import ReportWrapper from "../../../core/reportWrapper";
import ReactToPrint from "react-to-print";
import SearchOnTypeV2 from "../../../core/SearchOnTypeV2";
import DefaultAccountLabel from "../DefaultAccountLabel";
import DataTableDateField from "../../../core/DataTable/DataTableDateField";

import BulkFormWindow from "../../../core/BulkFormWindow";

class AccountsTab extends Component {

    static defaultProps = {
        onLoad: () => null
    };

    state = {
        tableViewName: UUIDUtil.v4(),
        selectedItems: [],
        prevSelectedItems: [],
        pagination: PaginationUtil.generatePaginationRequest(0, 50),
        lastPagination: "",
        filters: [],
        lastFilters: [],
        editMode: false,
        searchOnTypeValue: "",
        searchLoading: false,
        isPrinting: false,
        bulkOptions: {
            show: false,
            type: "userSelect",
            fieldName: "ownerId",
            fieldLabel: "Owner"
        }
    }

    constructor(props) {
        super(props);
        this.onTableViewChangeHandler = this.onTableViewChangeHandler.bind(this);
        this.onSelectedHandler = this.onSelectedHandler.bind(this);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
        this.updateFilter = this.updateFilter.bind(this);
        this.isDeleteEnabled = this.isDeleteEnabled.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onExportHandler = this.onExportHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.onBulkChangeHandler = this.onBulkChangeHandler.bind(this);
        this.onBulkCloseHandler = this.onBulkCloseHandler.bind(this);
        this.onBulkActionHandler = this.onBulkActionHandler.bind(this);
        this.onClearSelected = this.onClearSelected.bind(this);
        this.tableRef = null;
    }

    isDeleteEnabled() {
        return this.state.selectedItems.length > 0;
    }

    componentDidMount() {
        this.props.getAccountTableFilters();
        this.loadTopMenuItems();
    }

    loadTopMenuItems() {

        const { selectedItems } = this.state;
        const isSectionEnabled = selectedItems.length < 1;
        const deleteLabel = isSectionEnabled ? "Delete" : `Delete (${selectedItems.length} selected)`;
        const deactivateLabel = isSectionEnabled ? "Deactivate" : `Deactivate (${selectedItems.length} selected)`;
        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label={deleteLabel} icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label={deactivateLabel} icon="ban" onClick={(e) => console.log(e)} />,
            <TopActionMenu.ButtonMenuItem label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuSeparator />,
            <TopActionMenu.ButtonMenuItem label="Bulk Operations" isTitle={true} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label="Change Owner" icon="edit" onClick={() => this.onBulkChangeHandler("ownerId")} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload" icon="upload" onClick={(e) => console.log(e)} />
        ], false);

    }

    onBulkChangeHandler(type) {

        const { bulkOptions } = this.state;

        switch (type) {
            case "ownerId":
                bulkOptions.fieldLabel = "Owner";
                bulkOptions.type = "userSelect";
                break;
            default:
                bulkOptions.type = "input";
        }

        bulkOptions.show = true;
        bulkOptions.fieldName = type;

        this.setState({ bulkOptions });
    }

    onBulkCloseHandler() {
        const { bulkOptions } = this.state;
        bulkOptions.show = false;
        this.setState({ bulkOptions });
    }

    onBulkActionHandler(event) {

        const { selectedItems, bulkOptions } = this.state;

        let entityValues = [event.value];
        if (Array.isArray(event.value)) {
            entityValues = event.value.map((item) => item.value);
        }

        const formData = {
            entityName: "account",
            fieldName: event.target.name,
            entityIds: selectedItems.map((item) => item.id),
            entityValues: entityValues,
            type: bulkOptions.type,
            replace: event?.replace
        }

        const internalIds = selectedItems.map((selectedItem) => selectedItem.internalId);

        this.props.bulkUpdateRecords(formData, (data, err) => {
            if (!err) {
                this.executeSearch();
                this.props.setSystemMessage("success", `Record ${internalIds.join(", ")}, change ${bulkOptions.fieldLabel} saved`)
            }
        })
    }


    onDeleteHandler() {
        const { deleteAccounts } = this.props;
        const { selectedItems } = this.state;
        const self = this;

        const deleteRecord = () => {
            const idsToDelete = self.state.selectedItems.map((item) => item.referenceId);
            const internalIds = selectedItems.map((selectedItem) => selectedItem.internalId);
            deleteAccounts(idsToDelete, (data, err) => {
                if (!err) {
                    self.onClearSelected();
                    self.executeSearch();
                    this.props.setSystemMessage("success", `Record ${internalIds.join(", ")}, deleted`)
                }
            })
        }

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow selectedItems={selectedItems.length} onClose={onClose} onAction={deleteRecord} />
        });

    }

    onClearSelected() {
        this.setState({ selectedItems: [] });
    }

    onExportHandler() {
        const { items } = this.props.accounts;
        const { selectedItems } = this.state;
        ExportUtil.generateCsv(this.getColumns(), (selectedItems.length > 0 ? selectedItems : items), "accounts");
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        const { prevSelectedItems, selectedItems } = this.state;

        if (prevSelectedItems.length !== selectedItems.length) {
            this.loadTopMenuItems();
            this.setState({ prevSelectedItems: ObjectUtil.clone(selectedItems) });
        }

        const self = this;
        PaginationUtil.searchWithFilter(this.state, state => {
            self.setState(state);
            self.executeSearch()
        });

    }

    onTableViewChangeHandler(event) {
        const state = this.state;
        state.pagination = event;
        this.setState(state);
        this.executeSearch()
    }

    onSearchTypeHandler(event) {
        this.updateFilter(event);
    }

    executeSearch() {

        this.setState({ searchLoading: true });

        const { pagination, filters } = this.state;

        const activeFilters = PaginationUtil.getActiveFilters(filters);

        this.props.getAccountsData(activeFilters, pagination, () => this.setState({ searchLoading: false }));

    }

    updateFilter(selectedFilter) {
        const state = this.state;
        let filterUpdated = false;
        state.filters.forEach((filter, index) => {
            if (filter.name === selectedFilter.name) {
                state.filters[index].value = selectedFilter.value;
                filterUpdated = true;
            }
        });
        if (!filterUpdated) {
            state.filters.push(selectedFilter);
        }
        this.setState(state);
    }

    onSelectedHandler(item) {
        this.setState({ selectedItems: item });
    }

    onAddClickHandler() {
        this.props.history.push('/admin/accounts/new');
    }

    getColumns() {

        const isOpenTab = (this.props.objectId !== 0 && this.props.objectId !== undefined);

        return [
            {
                label: "HiddenRefId",
                name: "referenceId",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "ID",
                name: "internalId",
                options: {
                    filter: false,
                    sort: true,
                    display: true,
                    customBodyRender: (value, tableMeta) =>
                        <DataTableIDLink newTab={isOpenTab}
                            value={value}
                            tableMeta={tableMeta}
                            uri="/admin/accounts"
                        />
                }
            },
            {
                label: "Account Name",
                name: "accountName",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                    customBodyRender: (value, tableMeta) => <DefaultAccountLabel value={value} tableMeta={tableMeta} />
                }
            },
            {
                label: "Default Account",
                name: "defaultAccount",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "Industry",
                name: "industry",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.industries)

                }
            },
            {
                label: "Number of Employee",
                name: "numberOfEmployee",
                options: {
                    sort: true,
                    display: false,
                    filter: false
                }
            },
            {
                label: "Website",
                name: "website",
                options: {
                    sort: true,
                    display: false,
                    filter: false,
                }
            },
            {
                label: "Status",
                name: "status",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.statuses)
                }
            },
            {
                label: "Owner",
                name: "ownerName",
                options: {
                    sort: true,
                    display: true,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.owners)
                }
            },
            {
                label: "Created By",
                name: "createdBy",
                options: {
                    filter: true,
                    sort: true,
                    display: false,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdBys)
                }
            },
            {
                label: "Created Date",
                name: "createdAt",
                options: {
                    filter: true,
                    sort: true,
                    display: true,
                    customBodyRender: (value) => <DataTableDateField value={value} />,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdDates)
                }
            },
            {
                label: "Last Modified By",
                name: "updatedBy",
                options: {
                    sort: true,
                    display: true,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedBys)
                }
            },
            {
                label: "Last Modified Date",
                name: "updatedAt",
                options: {
                    filter: true,
                    sort: true,
                    display: true,
                    customBodyRender: (value) => <DataTableDateField value={value} />,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedDates)
                }
            },

        ]
    }

    render() {
        const { searchOnTypeValue, searchLoading, isPrinting, bulkOptions, selectedItems } = this.state

        return (<div className="account-tab">
            <BulkFormWindow
                selectedItems={selectedItems}
                entityName="accounts"
                onClose={this.onBulkCloseHandler}
                onAction={this.onBulkActionHandler}
                {...bulkOptions}
            />
            <div className="single-content active">

                <div className="filter-form">
                    <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler} />
                </div>

                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.tableRef}
                    onBeforeGetContent={() => this.setState({ isPrinting: true })}
                    onAfterPrint={() => this.setState({ isPrinting: false })}
                />

                <ReportWrapper entityName="Accounts" ref={el => (this.tableRef = el)} className="tab-container">
                    <DataTable
                        page={this.props.accounts}
                        loading={searchLoading}
                        columns={this.getColumns()}
                        isPrinting={isPrinting}
                        onPaginationChange={(e) => this.setState({ pagination: e })}
                        onFilterChange={(e) => this.setState({ filters: e })}
                        onSelected={this.onSelectedHandler}
                        title="Manage Accounts" />
                </ReportWrapper>
            </div>
        </div>);
    }
}

function mapStateToProps(state) {
    return {
        accounts: state.admin.accounts,
        tableFilters: state.admin.accountTableFilters
    }
}

export default withEventBus(connect(mapStateToProps, actions)(AccountsTab));