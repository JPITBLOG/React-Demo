export const autoRenewalOptions = [
    { label: 'Yes', value: true },
    { label: 'No', value: false }
]