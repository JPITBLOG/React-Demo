import React from "react";
import { Card } from "react-bootstrap";
import StatusLabel from "../../../../core/StatusLabel";
import EnumLabel from "../../../../core/EnumLabel";

const AccountInfoDetail = (props) => {

    const headerText = "Account Info"

    const { internalId, accountName, defaultAccount, industry, numberOfEmployee, status, website } = props.accountDetail;

    return (
        <div className="content-widget">
            <Card>
                <Card.Header>{headerText}</Card.Header>
                <Card.Body>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Account Name
                            </Card.Title>
                            <Card.Text>{accountName}
                                {defaultAccount && <StatusLabel active={true}>(Default)</StatusLabel>}
                            </Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>ID</Card.Title>
                            <Card.Text>{internalId}</Card.Text>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Industry
                            </Card.Title>
                            <Card.Text><EnumLabel>{industry}</EnumLabel></Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                Status
                            </Card.Title>
                            <StatusLabel status={status}>{status}</StatusLabel>
                        </section>
                    </div>
                    <div className="account-wrapper">
                        <section className="account-section">
                            <Card.Title>
                                Number of Employee
                            </Card.Title>
                            <Card.Text>{numberOfEmployee}</Card.Text>
                        </section>
                        <section className="account-section">
                            <Card.Title>
                                Website
                            </Card.Title>
                            <Card.Text>{website}</Card.Text>
                        </section>
                    </div>
                </Card.Body>
            </Card>

        </div>);
}

export default (AccountInfoDetail);