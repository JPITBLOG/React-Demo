import React, { Component, createRef } from "react";
import { Card, Form } from "react-bootstrap";
import { SAVE_ACCOUNT_FORM, VALIDATE_ACCOUNT_FORM } from "../../../../../events/types";
import FormSelector from "../../../../core/FormSelector";
import ArrayUtil from "../../../../../util/ArrayUtil";
import { connect } from "react-redux";
import * as actions from "../../../../../actions";
import AttachTooltip from "../../../../core/AttachItemTooltip";
import { autoRenewalOptions } from "../AccountOptions";
import DatePickerForm from "../../../../core/DatePickerForm";
import moment from 'moment';

class AccountSubscriptionSavePage extends Component {

    static defaultProps = {
        data: {
            id: 0
        },
        onChange: () => null
    }

    constructor(props) {
        super(props);
        this.onFormChangeHandler = this.onFormChangeHandler.bind(this);
        this.onFormControlChange = this.onFormControlChange.bind(this);
        this.onBlurFormControlHandler = this.onBlurFormControlHandler.bind(this);
        this.onSaveFormListener = this.onSaveFormListener.bind(this);
        this.formRef = createRef();
    }

    state = {
        formData: {
            subscription: {
                id: 0,
                customerSupportLevel: "Basic",
                contractTermOrd: 0,
                startDate: new Date(),
                endDate: moment(new Date(), "MM/dd/yyyy").add(2, 'week'),
                autoRenewal: true,
            },
            accountId: 0
        },
        invalidFields: [],
        contractTermOptions: []
    }

    onFormChangeHandler(event) {
        this.props.onChange(event);
    }

    endDateSelector(value) {
        const { formData } = this.state;
        const now = new Date(formData.subscription.startDate);
        let endDate;
        
        switch (value.toString()) {
            case "0":
                endDate = moment(now, "MM/dd/yyyy").add(2, 'weeks');
                break;
            case '1':
                endDate = moment(now, "MM/dd/yyyy").add(1, 'months');
                break;
            case '2':
                endDate = moment(now, "MM/dd/yyyy").add(12, 'months');
                break;
            case '3':
                endDate = moment(now, "MM/dd/yyyy").add(24, 'months');
                break;
            case '4':
                endDate = moment(now, "MM/dd/yyyy").add(36, 'months');
                break;
            case '5':
                endDate = moment(now, "MM/dd/yyyy").add(48, 'months');
                break;
            case '6':
                endDate = moment(now, "MM/dd/yyyy").add(60, 'months');
                break;
            default:
                endDate = new Date();
                break
        }
        return endDate;
    }

    onFormControlChange(event) {
        const { formData } = this.state;
        const { id, value } = event.target;
        formData.subscription[id] = value;

        if (id === "contractTermOrd") {
            const endDate = this.endDateSelector(value);
            formData.subscription.endDate = new Date(endDate);
        }

        if (id === "startDate") {
            const contractTerm = formData.subscription.contractTermOrd;
            const endDate = this.endDateSelector(contractTerm);
            formData.subscription.endDate = new Date(endDate);
        }

        this.setState({ formData });
        this.onFormChangeHandler(formData);
    }


    componentDidMount() {
        if (this.props.data.id && this.props.data.id !== 0) {
            this.setState({ formData: { ...this.state.formData, accountId: this.props.data.id, subscription: this.props.data.subscription } });
        }

        this.props.getSubscriptionOptions("contractTerm");
        this.props.getSubscriptionOptions("customerSupportLevel");

        // this.props.getSubscriptionOptions("contractTerm", (response, err) => {
        //     if (!err) {
        //         this.setState({ contractTermOptions: response })
        //     }
        // });
        window.addEventListener(VALIDATE_ACCOUNT_FORM, this.onSaveFormListener);
    }

    onSaveFormListener(event) {
        const state = this.state;

        if (this.formRef && this.formRef.current) {
            const isValid = this.formRef.current.checkValidity()
            this.props.onInvalidate(!isValid);

            if (!isValid) {
                state.invalidFields = [];
                event.detail.forEach((fieldName) => {
                    if (state.formData.subscription[fieldName] !== undefined && state.formData.subscription[fieldName] === "") {
                        state.invalidFields.push(fieldName);
                    }
                })
                this.setState(state);
            } else {
                window.dispatchEvent(new Event(SAVE_ACCOUNT_FORM));
            }
        }

    }

    componentWillUnmount(): void {
        window.removeEventListener(VALIDATE_ACCOUNT_FORM, this.onSaveFormListener);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.data !== this.props.data && this.props.data.subscription) {
            this.setState({ formData: { ...this.state.formData, accountId: this.props.data.id, subscription: this.props.data.subscription } });
        }
        if(prevProps.subscriptionOptions!==this.props.subscriptionOptions){
            const {fieldName,items} = this.props.subscriptionOptions;
            switch (fieldName) {
                case "contractTerm":
                    this.setState({ contractTermOptions: items })
                    break;
                case "customerSupportLevel":
                    this.setState({ customerSupportLevelOptions: items })
                    break;
                default:
                    console.log("field not in use: "+fieldName);
            }
        }
    }

    onBlurFormControlHandler(event) {
        const state = this.state;
        const target = event.currentTarget;
        if (target.required) {
            if (target.value && target.value.length === 0) {
                if (!state.invalidFields.includes(target.id)) {
                    state.invalidFields.push(target.id);
                }
            } else {
                if (state.invalidFields.includes(target.id)) {
                    const filteredList = state.invalidFields.filter(value => value !== target.id);
                    state.invalidFields = filteredList;
                }
            }
        }
        this.setState(state);
    }

    render() {
        const { subscription } = this.state.formData;
        const { contractTermOptions,customerSupportLevelOptions } = this.state;
        return (
            <Card>
                <AttachTooltip title="All fields are required to activate the account." placement="top-start">
                    <Card.Header>Subscription</Card.Header>
                </AttachTooltip>
                <Card.Body>
                    <Form onSubmit={(e) => e.preventDefault()} ref={this.formRef}>
                        <Form.Group>
                            <Form.Label>Custom Support Level*</Form.Label><br />
                            <FormSelector
                                required
                                id="customerSupportLevel"
                                value={ArrayUtil.getItemByValue(customerSupportLevelOptions, "value", subscription.customerSupportLevel.toUpperCase())}
                                isInvalid={this.state.invalidFields.includes("customerSupportLevel")}
                                name="customerSupportLevel"
                                classNamePrefix="select"
                                isSearchable
                                options={customerSupportLevelOptions}
                                onBlur={this.onBlurFormControlHandler}
                                onChange={this.onFormControlChange}
                            />
                            <Form.Control.Feedback type="invalid">
                                Field is required
                            </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Contract Term*</Form.Label><br />
                            <FormSelector
                                required
                                id="contractTermOrd"
                                value={ArrayUtil.getItemByValue(contractTermOptions, "value", subscription.contractTermOrd)}
                                isInvalid={this.state.invalidFields.includes("contractTermOrd")}
                                name="contractTermOrd"
                                classNamePrefix="select"
                                isSearchable
                                options={contractTermOptions}
                                onBlur={this.onBlurFormControlHandler}
                                onChange={this.onFormControlChange}
                            />
                            <Form.Control.Feedback type="invalid">
                                Field is required
                                </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="form_group_datepicker">
                            <Form.Label>Start Date*</Form.Label>
                            <DatePickerForm
                                required
                                id="startDate"
                                selectedDate={subscription.startDate}
                                onChange={this.onFormControlChange} />
                            <Form.Control.Feedback type="invalid">
                                Field is required
                            </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="form_group_datepicker">
                            <Form.Label>End Date*</Form.Label>
                            <DatePickerForm readOnly={true} selectedDate={subscription.endDate} />
                            <Form.Control.Feedback type="invalid">
                                Field is required
                            </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Auto Renewal*</Form.Label><br />
                            <FormSelector
                                required
                                id="autoRenewal"
                                value={ArrayUtil.getItemByValue(autoRenewalOptions, "value", subscription.autoRenewal)}
                                isInvalid={this.state.invalidFields.includes("autoRenewal")}
                                name="autoRenewal"
                                classNamePrefix="select"
                                isSearchable
                                options={autoRenewalOptions}
                                onBlur={this.onBlurFormControlHandler}
                                onChange={this.onFormControlChange}
                            />
                            <Form.Control.Feedback type="invalid">
                                Field is required
                                </Form.Control.Feedback>
                        </Form.Group>
                    </Form>
                </Card.Body>
            </Card>
        );
    }
}

const mapStateToProps = (state) => {
    return ({
        subscriptionOptions: state.admin.subscriptionOptions
    })
}

export default connect(mapStateToProps, actions)(AccountSubscriptionSavePage);