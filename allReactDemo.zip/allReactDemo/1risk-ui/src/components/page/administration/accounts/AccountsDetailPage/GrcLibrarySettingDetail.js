import React, { Component } from "react";
import { Card, Form } from "react-bootstrap";

class GrcLibrarySettingDetail extends Component {

    render() {
        const selectedTags = [{ label: "21 CFR Part 11 Electronic Records; Electronic Signatures", value: "8" }, { label: "COBIT 5", value: "4" }]
        const tags = selectedTags.map(tags => {
            return <li className="list-grc-library">{tags.label}</li>
        });

        return (
            <Card>
                <Card.Header>Grc Library Settings</Card.Header>
                <Card.Body>
                    <Form>
                        <Form.Group>
                            <Form.Label>GRC Library</Form.Label>
                            <Card.Text>This account have access to the below Obligation content library.</Card.Text>
                            {tags}
                        </Form.Group>
                    </Form>
                </Card.Body>
            </Card>
        );
    }
}

export default (GrcLibrarySettingDetail);