import React, {Component} from "react";
import pageWrapper, {PAGE_TYPE_VIEW} from "../../../../core/pageWrapper";
import * as actions from "../../../../../actions"
import {connect} from "react-redux";
import PageUtil from "../../../../../util/PageUtil";
import BrowserUtil from "../../../../../util/BrowserUtil";
import TopActionMenu from "../../../../core/TopActionMenu";
import ReactToPrint from "react-to-print";
import ReportWrapper from "../../../../core/reportWrapper";
import BreadcrumbUtil from "../../../../../util/BreadcrumbUtil";
import {Card, Col, Row, Tab, Tabs} from "react-bootstrap";
import EntityInfoWidget from "../../../../core/EntityInfoWidget";
import StringUtil from "../../../../../util/StringUtil";
import AccountInfoDetail from "./AccountInfoDetail";
import AccountSubscriptionDetail from "./AccountSubscriptionDetail";
import AccountLimitDetail from "./AccountLimitDetail";
import '../../AdministrationPage.css'
import ImageThumbnailContainer from "../../../../core/ImageThumbnailContainer";

class AccountDetailPage extends Component {
    state = {
        accountDetail: {},
        activeTab: "details",
        tabs: [
            "details",
            "manage-users",
            "manage-subscription",
            "app-settings"
        ]
    }

    constructor(props) {
        super(props);
        this.populatePage = this.populatePage.bind(this);
        this.populateHeader = this.populateHeader.bind(this);
        this.getObjectId = this.getObjectId.bind(this);
        this.onCancelHandler = this.onCancelHandler.bind(this)
        this.onEditClickHandler = this.onEditClickHandler.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onTabSelectHandler = this.onTabSelectHandler.bind(this);
    }

    componentDidMount() {
        this.selectTabByUrl();
        BrowserUtil.scrollToTop();
        this.populatePage();
        this.loadTopMenuItems();
    }

    getObjectId() {
        return this.props.accountDetail?.id
    }

    populatePage() {
        this.pageUtil = new PageUtil(this.props);
        if (this.pageUtil.exists("id")) {
            const accountId = this.pageUtil.get("id");
            this.props.getAccountById(accountId, (response, err) => {
                if (err) {
                    this.props.history.push("/admin/accounts")
                } else {
                    // this.props.getSubscriptionByAccountId(response.referenceId, (data, err) => {
                    //     if (err) {
                    //         console.log(err);
                    //     }
                    // })
                }
            });
        }
    }

    loadTopMenuItems() {
        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Edit" icon="edit" onClick={this.onEditClickHandler} />,
            <TopActionMenu.ButtonMenuItem label="Delete" icon="trash" onClick={(e) => console.log(e)} />,
            <TopActionMenu.ButtonMenuItem label="Deactivate" icon="ban" onClick={(e) => console.log(e)} />,
            <TopActionMenu.ButtonMenuItem label="Print Screen" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuItem disabled label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload Template" icon="upload" onClick={(e) => console.log(e)} />
        ], false);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        if(prevProps.subscriptionStatus !== this.props.subscriptionStatus){
            this.props.getAccountById(this.state.accountDetail.referenceId);
        }

        if (prevProps.accountDetail !== this.props.accountDetail && this.props.accountDetail !== this.state.accountDetail) {
            this.populateHeader(true);
            this.setState({ accountDetail: this.props.accountDetail });
        }

        if (this.props.match.params !== prevProps.match.params) {
            this.selectTabByUrl();
        }
    }

    selectTabByUrl() {
        const { tab } = this.props.match.params;
        const { tabs } = this.state;
        const selectedTab = tabs.filter((e) => e === tab);

        if (selectedTab.length > 0) {
            this.setState({ activeTab: tab });
        }

        this.populateHeader(true);

    }

    onTabSelectHandler(tabName) {

        const { referenceId } = this.props.accountDetail;

        this.setState({ activeTab: tabName });

        const url = `/admin/accounts/${referenceId}`;

        if (tabName === "details") {
            this.loadTopMenuItems();
            this.props.history.push(url);
        } else {
            this.props.history.push(url + "/" + tabName);
        }

    }

    populateHeader(init = false) {
        this.pageUtil = new PageUtil()
        const { internalId, referenceId } = this.props.accountDetail;
        const { activeTab } = this.state;
        if (internalId) {
            let breadcrumb = BreadcrumbUtil.createRequest("Admin", internalId, true);
            if (activeTab !== "details") {
                const prev = breadcrumb;
                prev.uri = `/admin/accounts/${referenceId}`;
                breadcrumb = BreadcrumbUtil.createRequest("Admin", StringUtil.toTitleCase(activeTab), false, prev);
            }
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_VIEW, "Manage Accounts")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }
    }

    onEditClickHandler = (event) => {
        const accountDetail = this.props.accountDetail
        this.props.history.push(`/admin/accounts/edit/${accountDetail.referenceId}`);
        event.preventDefault();
    }

    onCancelHandler = (event) => {
        const redirectUrl = "/admin/accounts";
        this.props.history.push(redirectUrl);
        event.preventDefault();
    }

    render() {
        const { createdAt, updatedAt, ownerName, internalId, logoUrl, referenceId, defaultAccount, subscription } = this.props.accountDetail;
        return (
            <div>
                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.contentRef}
                />
                <ReportWrapper entityName="Account" ref={el => (this.contentRef = el)}>
                    <section id="content-wrap" className="right-content-wrap">
                        <Row className="tab-wrap">
                            <Col lg={12}>
                                <Tabs mountOnEnter={true} unmountOnExit={true} activeKey={this.state.activeTab} onSelect={this.onTabSelectHandler}>
                                    <Tab eventKey="details" title="Details">
                                        <Row>
                                            <Col lg={9} className="left-col">
                                                <AccountInfoDetail {...this.props} />
                                            </Col>
                                            <Col lg={3} className="right-col">
                                                <Card>
                                                    <Card.Header>
                                                        Logo
                                                    </Card.Header>
                                                    <Card.Body>
                                                        <ImageThumbnailContainer src={logoUrl} alt="Logo"/>
                                                    </Card.Body>
                                                </Card>
                                                <EntityInfoWidget createdAt={createdAt}
                                                    updatedAt={updatedAt}
                                                    ownerName={ownerName}
                                                    recordId={internalId} />
                                            </Col>
                                        </Row>
                                    </Tab>
                                    <Tab eventKey="manage-users" title="Manage Users">
                                        <div>Manage Users</div>
                                    </Tab>
                                    <Tab eventKey="manage-subscription" title="Manage Subscription">
                                        <Row>
                                            <Col lg={9} className="left-col">
                                                <AccountSubscriptionDetail subscriptionDetail={subscription} referenceId={referenceId} defaultAccount={defaultAccount} />
                                            </Col>
                                            <Col lg={3} className="right-col">
                                                <AccountLimitDetail subscriptionDetail={subscription} />
                                            </Col>
                                        </Row>
                                    </Tab>
                                    {/*<Tab eventKey="app-settings" title="App Settings">*/}
                                    {/*    <GrcLibrarySettingDetail/>*/}
                                    {/*</Tab>*/}
                                </Tabs>
                            </Col>
                        </Row>
                    </section>
                </ReportWrapper>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return ({
        accountDetail: state.admin.accountDetail,
        subscriptionStatus: state.admin.subscriptionStatus
    })
}

export default pageWrapper(connect(mapStateToProps, actions)(AccountDetailPage));