import React from "react";
import { Card, Row, Col } from "react-bootstrap";

const AccountLimitDetail = (props) => {

    const headerText = "Usage Meter";

    const subscription = props.subscriptionDetail;

    let subscriptionLimitList = {};

    if (subscription && subscription.subscriptionLimit) {
        subscriptionLimitList = subscription.subscriptionLimit;
    } else {
        subscriptionLimitList = {
            adminLimit: 2,
            targetLimit: 10,
            programManagerLimit: 2,
            controlLimit: 10,
            generalLimit: 2,
            readOnlyLimit: 2,
            riskLimit: 10,
            issueLimit: 10
        }
    }

    return (
        <div className="content-widget">
            <Card>
                <Card.Header>{headerText}</Card.Header>
                <Card.Body>
                    <div className="account-limit-usage">
                        <Row>
                            <Col lg={6}> <Card.Title>Metric</Card.Title></Col>
                            <Col lg={3}> <Card.Title>Used</Card.Title></Col>
                            <Col lg={3}> <Card.Title>Limit</Card.Title></Col>
                        </Row>
                    </div>
                    <div className="account-limit-usage">
                        <Row>
                            <Col lg={6}> Admin User</Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.adminUsage}</Card.Text></Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.adminLimit}</Card.Text></Col>
                        </Row>
                    </div>
                    <div className="account-limit-usage">
                        <Row>
                            <Col lg={6}> Manage User</Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.programManagerUsage}</Card.Text></Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.programManagerLimit}</Card.Text></Col>
                        </Row>
                    </div>
                    <div className="account-limit-usage">
                        <Row>
                            <Col lg={6}> General User</Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.generalUsage}</Card.Text></Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.generalLimit}</Card.Text></Col>
                        </Row>
                    </div>
                    <div className="account-limit-usage">
                        <Row>
                            <Col lg={6}> Read-Only User</Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.readOnlyUsage}</Card.Text></Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.readOnlyLimit}</Card.Text></Col>
                        </Row>
                    </div>
                    <div className="account-limit-usage">
                        <Row>
                            <Col lg={6}> Target</Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.targetUsage}</Card.Text></Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.targetLimit}</Card.Text></Col>
                        </Row>
                    </div>
                    <div className="account-limit-usage">
                        <Row>
                            <Col lg={6}> Control</Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.controlUsage}</Card.Text></Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.controlLimit}</Card.Text></Col>
                        </Row>
                    </div>
                    <div className="account-limit-usage">
                        <Row>
                            <Col lg={6}> Risk</Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.riskUsage}</Card.Text></Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.riskLimit}</Card.Text></Col>
                        </Row>
                    </div>
                    <div className="account-limit-usage">
                        <Row>
                            <Col lg={6}> Issue</Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.issueUsage}</Card.Text></Col>
                            <Col lg={3}><Card.Text>{subscriptionLimitList?.issueLimit}</Card.Text></Col>
                        </Row>
                    </div>
                </Card.Body>
            </Card>
        </div>);
}

export default (AccountLimitDetail);