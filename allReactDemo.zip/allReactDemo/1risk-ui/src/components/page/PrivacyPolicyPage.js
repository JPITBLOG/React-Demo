import React from 'react';

export default () =>{
    return(
        <div>
            <div className="ui center aligned basic segment">
                <div className="ui header">CyberOne Security Inc.<br/>Terms of Service and Privacy Policy<br/>Last
                    Updated 8.16.2018
                </div>
            </div>
            <h3>Terms of Service</h3>
            <p><strong>Subject Understanding</strong></p>
            <p>CyberOne applications is not for public use. It is for authorized user that agreed to our Non-Disclosure
                Agreement and Master contract terms between CyberOne and our customer. By using this site, you agreed
                that you&rsquo;ve been authorized by the appropriate CyberOne customer. CyberOne customer is responsible
                for performing security review on all access control periodically to provide access control provisioning
                instructions. If you are not an authorized user of CyberOne, DO NOT PROCEED AND USE THIS SITE. If you
                received an email to register by accident by any source, please contact&nbsp;<a
                    href="mailto:support@cb1security.com">support@cb1security.com</a>&nbsp;to notify us to report the
                request.</p>
            <p>All subject understand that CyberOne is a risk and compliance application that monitor and track audit
                records for user&rsquo;s activities and inputs. Users shall not share their user account at any time.
                When user provide attestation to its risk and compliance response, the audit log may be use for audit,
                compliance, and legal purposes by the customer.</p>
            <p><strong>Acceptable Use of this Application</strong></p>
            <p>All user shall not use language that may discriminate and harm, or in anyways, violates the code of
                conduct by your employer who ultimately is the authorized party for accessing the CyberOne application
                by our customer.</p>
            <p>All user shall not use the application to fraud or maliciously cause harm to the CyberOne application and
                data presented in the application including content data, source code, and processing data.</p>
            <p><strong>Application Hosting</strong></p>
            <p>Our applications are hosted using a third party trusted infrastructure services and it is deployed
                according to our customer&rsquo;s approved architecture specifications to support both domestic,
                European Union, and other global requests. Accordingly, data obtained could be processed outside the
                European Union. As such, CyberOne Security practices follows applicable data transferred requirements in
                the US, European Union, and other applicable law when transferring data within and out of the European
                Union.</p>
            <p><strong>Non-Disclosure &amp; Confidentiality</strong></p>
            <p>All users agrees to CyberOne Security non-disclosure agreement. By accepting this term, you are also
                accepting our mutual non-disclosure agreement.</p>
            <p>All content, source code, and processing data the CyberOne application is Confidential. This includes
                Control Library, Test Plans, Assessment Questions, and other data presented on this site. Under no
                circumstance does the user of this application have the rights to share copyright, trademark, and
                company confidential information with unauthorized parties. If you have doubt or have question on
                handling confidential data on this application, contact us with your question at&nbsp;<a
                    href="mailto:support@cb1security.com">support@cb1security.com</a>&nbsp;before sharing any
                information un-verified authorized users.</p>
            <p><strong>We Use Cookies to Improve User Experiences</strong></p>
            <p>Cookies help us provide you with a better experience on our applications. We use cookies to monitor your
                browsing history and to provide a faster and better user experience throughout our applications. A
                cookie in no way gives us access to your computer or any information about you, other than the data you
                choose to share with us. You may choose to accept or decline cookies. Most web browsers automatically
                accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. This
                may prevent you from taking full advantage of the website.</p>
            <p><strong>Report a Case</strong></p>
            <p>All users are required to report a case to CyberOne when anything seems unusual or is suspected of
                unusual behavior when using the C1 Platform. To report a case, please contact us at&nbsp;<a
                    href="mailto:support@cb1security.com">support@cb1security.com</a>.</p>
            <h3>Privacy Policy</h3>
            <p><strong>Subject Consent</strong></p>
            <p>By accepting our term and condition, you are giving CyberOne Security Inc. consent to process your data.
                You may at any time withdraw a consent granted hereunder by contacting us at&nbsp;<a
                    href="mailto:support@cb1security.com">support@cb1security.com</a>. In case of withdrawal, CyberOne
                Security will notify our customer requesting your information and we will not process your Personal Data
                subject to this consent, unless legally required to do so. In the event that CyberOne Security is
                required to retain your Personal Data for legal reasons, it will be restricted from further processing
                and only retained for the term required by law. Any withdrawal has no effect on past processing of
                personal data by by CyberOne Security up to the point in time of your withdrawal.</p>
            <p><strong>Your Personal Data</strong></p>
            <p>CyberOne Security only holds basic data about the person&rsquo;s name and email address when authorized
                to use our application. CyberOne process this basic personal information for the customer&rsquo;s risk
                and compliance management usage. Your basic personal data is also used for CyberOne&rsquo;s user access
                identification. All data processed on CyberOne applications is protected with reasonable security
                measures. You may object to CyberOne for using your information for the above purposes at any time by
                not using our application and contacting us at&nbsp;<a
                    href="mailto:support@cb1security.com">support@cb1security.com</a>&nbsp;to remove your information.
            </p>
            <p><strong>Subject Rights</strong></p>
            <p>We do not intend for our cloud application or online services to be used by anyone unauthorized by our
                customer. If you are asked to register on this site without an authorization, please contact us
                immediately at&nbsp;<a href="mailto:support@cb1security.com">support@cb1security.com</a>.</p>
            <p>Except as otherwise mentioned in this privacy notice and in compliance of our contractual terms with
                customers, we keep your personal information only for as long as required by us to provide you with the
                services you have requested; to comply with other law, or to support a claim or defense in court.</p>
            <p>Our privacy policy has been compiled to comply with the law of every country or legal jurisdiction in
                which we aim to do business. If you think it fails to satisfy the law of your jurisdiction, we should
                like to hear from you. It is your choice as to whether you wish to use our application.</p>
            <p>We may update this privacy notice from time to time as necessary. The terms that apply to you are those
                posted here on our application on the day you use our website. We advise you to print a copy for your
                records.</p>
            <p><strong>Contact Us for Questions</strong></p>
            <p>If you have any question regarding our privacy policy, please contact us at&nbsp;<a
                href="mailto:support@cb1security.com">support@cb1security.com</a>.</p>
        </div>
    );
}