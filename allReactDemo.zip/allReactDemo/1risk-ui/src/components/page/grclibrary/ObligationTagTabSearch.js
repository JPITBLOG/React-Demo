import React, {Component} from 'react';
import UUIDUtil from "../../../util/UUIDUtil";
import FilterChip from "../../core/FilterChip";
import ClearIcon from "@material-ui/icons/Clear";
import {Button, Col, Row} from "react-bootstrap";
import {connect} from "react-redux";
import * as actions from "../../../actions";
import SearchOnTypeV2 from "../../core/SearchOnTypeV2";

import './ObligationTagTabSearch.css';
import MultiSelectorDropDown from "../../core/MultiSelectorDropDown";

class ObligationTagTabSearch extends Component{

    static defaultProps={
        showObligationFilter: true,
        showTagFilter: true
    }

    constructor(props) {
        super(props);
        this.state={
            searchOnTypeName:UUIDUtil.v4(),
            selectedObligations:[],
            selectedTags:[],
            obligationsFilterData:[],
            dropdownHeight:400,
            searchOnTypeValue:null,
        }
        this.onClickResetHandler = this.onClickResetHandler.bind(this);
        this.onChangeObligationsHandler = this.onChangeObligationsHandler.bind(this);
        this.onChangeTagHandler = this.onChangeTagHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.removeFromSelectedList = this.removeFromSelectedList.bind(this);
        this.onCloseFilterHandler = this.onCloseFilterHandler.bind(this);
        this.sendFilterChange = this.sendFilterChange.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
    }

    onClickResetHandler(event){
        const state = this.state
        const collections = "selectedObligations,selectedTags".split(",");
        collections.forEach((name)=>{
            state[name]=[];
        });
        state.searchOnTypeValue=null;
        this.setState(state);
        this.props.onResetFilters();
        event.preventDefault();
    }

    onChangeObligationsHandler(value){
        this.setState({ selectedObligations: value });
    }

    onChangeTagHandler(value){
        this.setState({ selectedTags: value });
    }

    onCloseFilterHandler(event){
        this.sendFilterChange(event);
    }

    sendFilterChange(event){

        const {selectedObligations,selectedTags} = this.state

        const response = {
            "name": event,
            "value": ""
        }

        switch (event) {
            case "obligation":
                response.value= JSON.stringify(selectedObligations.map((obligation)=>obligation.value));
                break;
            case "tag":{
                response.value=JSON.stringify(selectedTags);
                break;
            }
            default:
                break;
        }
        this.props.onFilterChange(response);
    }


    renderChips(){
        let chipList=[];
        this.state.selectedObligations.forEach(value => {
            chipList.push(this.renderChip('obligation',value));
        });
        this.state.selectedTags.forEach(value => {
            chipList.push(this.renderChip('tag',value))
        });

        return chipList;
    }

    renderChip(type,data,labelKey="label",valueKey="value"){
        const chipId = `chip-${type}-${data[valueKey]}`;
        return (<FilterChip key={chipId} id={chipId}
                            label={data[labelKey]}
                            onDelete={this.onDeleteHandler} color="default"
                            deleteIcon={<ClearIcon/>}
        />);
    }

    onDeleteHandler(event){
        const itemId = event.currentTarget.parentNode.id.split("-");
        switch (itemId[1]) {
            case "obligation":
                this.removeFromSelectedList(itemId[1],"selectedObligations",itemId[2],"value")
                break;
            case "tag":
                this.removeFromSelectedList(itemId[1],"selectedTags",itemId[2],"value")
                break;
            default:
                break;
        }
    }

    removeFromSelectedList(event,listName,idToDelete,valueKey){
        const state = this.state;
        state[listName]=state[listName].filter(function(item){
            return String(item[valueKey]) !== String(idToDelete);
        });
        this.setState(state);
        this.sendFilterChange(event);
    }

    onSearchTypeHandler(event){
        this.props.onSearchType(event);
        this.setState({searchOnTypeValue:event.value});
    }
    
    onAddClickHandler(event){
        this.props.onAddClick(event);
    }
    
    render() {
        const {selectedObligations,selectedTags,searchOnTypeValue} = this.state;
        const {showObligationFilter,showTagFilter} = this.props;
        return(<div className="obligation-section-search"><div className="filter-form">
            <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler}/>
            <Row>
                {showObligationFilter && <Col lg={3} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedObligations}
                        options={this.props.obligationsFilterData}
                        onChange={this.onChangeObligationsHandler}
                        onClose={()=>this.onCloseFilterHandler("obligation")}
                        singularSelectedPlaceholder="%s Obligation selected"
                        manySelectedPlaceholder="%s Obligations selected"
                        placeholder="Filter by Obligation"
                    />
                </Col>}
                {showTagFilter && <Col lg={2} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedTags}
                        options={[]}
                        onChange={this.onChangeTagHandler}
                        onClose={()=>this.onCloseFilterHandler("tag")}
                        singularSelectedPlaceholder="%s Tag selected"
                        manySelectedPlaceholder="%s Tags selected"
                        placeholder="Filter by Tags"
                    />
                </Col>}
                <Col lg={2} className="form-group">
                    <Button variant="link" onClick={this.onClickResetHandler}>Clear all</Button>
                </Col>
            </Row>
            <div className="filters-option filter-selection-col">
                {this.renderChips()}
            </div>
        </div></div>)
    }
}

const mapStateToProps = (state)=>{
    return({
        obligationsFilterData: state.searchFilter.obligationsFilterData
    });
}

export default connect(mapStateToProps,actions)(ObligationTagTabSearch);
