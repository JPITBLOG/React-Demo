import React, {Component} from 'react';
import {Button, Col, Row} from "react-bootstrap";
import ClearIcon from '@material-ui/icons/Clear';
import FilterChip from "../../../core/FilterChip";
import {connect} from "react-redux";
import * as actions from "../../../../actions";
import MultiSelectorDropDown from "../../../core/MultiSelectorDropDown";
import SearchOnTypeV2 from "../../../core/SearchOnTypeV2";

class ObligationTabSearch extends Component{

    static defaultProps = {
        onAddClick:()=>null,
        onFilterChange:()=>null
    }

    state={
        industryOptions:[],
        regionOptions:[],
        typeOptions:[],
        searchOnTypeValue:null,
        selectedIndustryTags:[],
        selectedRegionTags:[],
        selectedTypeTags:[],
    }

    constructor(props) {
        super(props);
        this.onChangeIndustryHandler = this.onChangeIndustryHandler.bind(this);
        this.onChangeRegionHandler = this.onChangeRegionHandler.bind(this);
        this.onChangeTypeHandler = this.onChangeTypeHandler.bind(this);
        this.onClickResetHandler = this.onClickResetHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onCloseFilterHandler = this.onCloseFilterHandler.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
        this.sendFilterChange = this.sendFilterChange.bind(this);
    }

    componentDidMount() {
        this.props.getEntityTags("obligation","industryTags");
        this.props.getEntityTags("obligation","regionTags");
        this.props.getEntityTags("obligation","typeTags");
    }

    componentDidUpdate(prevProps, prevState, snapshot){
        if(prevProps.entityTagsData!==this.props.entityTagsData){

            const state = this.state;

            const {entityTagsData} = this.props;
            const mapFunction = (item)=>{
                return {label:item.value,value:item.value}
            }
            const data = entityTagsData.map(mapFunction);
            if(data.length>0){
                const fieldName = entityTagsData[0].fieldName;
                switch (fieldName) {
                    case "industry_tags":
                        state.industryOptions = data;
                        break;
                    case "region_tags":
                        state.regionOptions = data;
                        break;
                    case "type_tags":
                        state.typeOptions = data;
                        break;
                    default:
                        break;
                }
            }
            this.setState(state);
        }
    }

    onChangeIndustryHandler(value){
        this.setState({ selectedIndustryTags: value });
    }

    onChangeRegionHandler(value){
        this.setState({ selectedRegionTags: value });
    }

    onChangeTypeHandler(value){
        this.setState({ selectedTypeTags: value });
    }

    onClickResetHandler(event){
        const state = this.state
        const collections = "selectedIndustryTags,selectedRegionTags,selectedTypeTags".split(",");
        collections.forEach((name)=>{
            state[name]=[];
        });
        state.searchOnTypeValue=null;
        this.setState(state);
        this.props.onResetFilters();
        event.preventDefault();
    }

    onSearchTypeHandler(event){
        this.props.onSearchType(event);
        this.setState({searchOnTypeValue:event.value});
    }

    onDeleteHandler(event){
        const itemId = event.currentTarget.parentNode.id.split("-");
        switch (itemId[1]) {
            case "industry":
                this.removeFromSelectedList("selectedIndustryTags",itemId[2])
                break;
            case "region":
                this.removeFromSelectedList("selectedRegionTags",itemId[2])
                break;
            case "type":
                this.removeFromSelectedList("selectedTypeTags",itemId[2])
                break;
            default:
                break;
        }
    }

    onCloseFilterHandler(event){
        this.sendFilterChange(event)
    }

    sendFilterChange(event){

        const {selectedIndustryTags,selectedRegionTags,selectedTypeTags} = this.state

        const response = {
            "name": event,
            "value": ""
        }

        switch (event) {
            case "industryTags":
                response.value= JSON.stringify(selectedIndustryTags.map((obligation)=>obligation.value));
                break;
            case "regionTags":
                response.value= JSON.stringify(selectedRegionTags.map((obligation)=>obligation.value));
                break;
            case "typeTags":
                response.value= JSON.stringify(selectedTypeTags.map((obligation)=>obligation.value));
                break;
            default:
                break;
        }
        this.props.onFilterChange(response);
    }

    removeFromSelectedList(listName,idToDelete){
        const state = this.state;
        state[listName]=state[listName].filter(function(item, index, arr){
            return item.value !== idToDelete;
        });
        this.setState(state);
    }

    renderChips(){
        let chipList=[];
        this.state.selectedIndustryTags.forEach(value => {
            chipList.push(this.renderChip('industry',value))
        });
        this.state.selectedRegionTags.forEach(value => {
            chipList.push(this.renderChip('region',value))
        });
        this.state.selectedTypeTags.forEach(value => {
            chipList.push(this.renderChip('type',value))
        });

        return chipList;
    }

    renderChip(type,data){
        const chipId = `chip-${type}-${data.value}`;
        return (<FilterChip key={chipId} id={chipId}
                           label={data.label}
                           onDelete={this.onDeleteHandler} color="default"
                           deleteIcon={<ClearIcon/>}
        />);
    }

    onAddClickHandler(event){
        this.props.onAddClick(event);
    }

    render() {
        const {selectedIndustryTags,selectedRegionTags,selectedTypeTags,industryOptions,regionOptions,typeOptions,searchOnTypeValue} = this.state;
        return(<div className="filter-form">
            <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler}/>
            <Row>
                <Col lg={2} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedIndustryTags}
                        options={industryOptions}
                        onChange={this.onChangeIndustryHandler}
                        onClose={(e)=>this.onCloseFilterHandler("industryTags",e)}
                        placeholder="Filter by Industry"
                        manySelectedPlaceholder="%s Industries selected"
                        singularSelectedPlaceholder="%s Industry selected"
                    />
                </Col>
                <Col lg={2} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedRegionTags}
                        options={regionOptions}
                        onChange={this.onChangeRegionHandler}
                        onClose={(e)=>this.onCloseFilterHandler("regionTags",e)}
                        placeholder="Filter by Region"
                        manySelectedPlaceholder="%s Regions selected"
                        singularSelectedPlaceholder="%s Region selected"
                    />
                </Col>
                <Col lg={2} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedTypeTags}
                        options={typeOptions}
                        onChange={this.onChangeTypeHandler}
                        onClose={(e)=>this.onCloseFilterHandler("typeTags",e)}
                        placeholder="Filter by Type"
                        manySelectedPlaceholder="%s Types selected"
                        singularSelectedPlaceholder="%s Type selected"
                    />
                </Col>
                <Col lg={2} className="form-group">
                    <Button variant="link" onClick={this.onClickResetHandler}>Clear all</Button>
                </Col>
            </Row>
            <div className="filters-option">
                {this.renderChips()}
            </div>
        </div>)
    }
}

const mapStateToProps = (state) =>{
    return{
        entityTagsData:state.searchFilter.entityTagsData
    }
}

export default connect(mapStateToProps,actions)(ObligationTabSearch);