import React, {Component, createRef} from "react";
import {Card, Form} from "react-bootstrap";
import PropTypes from 'prop-types';
import {SAVE_OBLIGATION_FORM, VALIDATE_OBLIGATION_FORM} from "../../../../../events/types";
import FormEditor from "../../../../core/FormEditor";

class ObligationSavePageForm extends Component{

    static defaultProps={
        data:{
            id:0
        }
    }

    constructor(props) {
        super(props);
        this.onFormChangeHandler = this.onFormChangeHandler.bind(this);
        this.onFormControlChange = this.onFormControlChange.bind(this);
        this.onEditorChangeHandler = this.onEditorChangeHandler.bind(this);
        this.onBlurFormControlHandler = this.onBlurFormControlHandler.bind(this);
        this.onSaveFormListener = this.onSaveFormListener.bind(this);
        this.formRef = createRef();
    }

    state = {
        formData: {
            id: 0,
            obligationName: "",
            obligationVersion:"",
            description: ""
        },
        invalidFields:[]
    }

    static defaultProps={
        onChange:()=>null
    }

    onFormChangeHandler(event){
        this.props.onChange(event);
    }

    onFormControlChange(event){
        const {formData} = this.state;
        const {id,value} = event.target;
        formData[id]=value;

        this.setState({formData});
        this.onFormChangeHandler(formData);

        event.preventDefault();
    }

    onEditorChangeHandler = (content, editor) => {
        const formData = this.state.formData;
        formData.description=content;
        this.setState({formData});
        this.onFormChangeHandler(formData);
    }

    componentDidMount(){
        if(this.props.data.id && this.props.data.id !==0){
            this.setState({formData:this.props.data});
        }
        window.addEventListener(VALIDATE_OBLIGATION_FORM,this.onSaveFormListener);
    }

    onSaveFormListener(event){
        const state = this.state;

        if(this.formRef && this.formRef.current){
            const isValid = this.formRef.current.checkValidity()
            this.props.onInvalidate(!isValid);

            if(!isValid){
                state.invalidFields=[];
                event.detail.forEach((fieldName)=>{                   
                    if(state.formData[fieldName] !== undefined && state.formData[fieldName] === ""){
                        state.invalidFields.push(fieldName);
                    }
                })
                this.setState(state);
            }else{
                window.dispatchEvent(new Event(SAVE_OBLIGATION_FORM));
            }
        }

    }

    componentWillUnmount(): void {
        window.removeEventListener(VALIDATE_OBLIGATION_FORM,this.onSaveFormListener);
    }

    componentDidUpdate(prevProps, prevState, snapshot){
        if(prevProps.data !== this.props.data){
            this.setState({formData:this.props.data});
        }
    }

    onBlurFormControlHandler(event){
        const state = this.state;
        const target = event.currentTarget;
        if(target.required){
            if(target.value.length===0){
                if(!state.invalidFields.includes(target.id)){
                    state.invalidFields.push(target.id);
                }
            }else{
                if(state.invalidFields.includes(target.id)){
                    const filteredList = state.invalidFields.filter(value => value !== target.id);
                    state.invalidFields = filteredList;
                }
            }
        }
        this.setState(state);
    }

    render(){
        const {obligationName,obligationVersion,description} = this.state.formData;
        return (<Card>
            <Card.Header>Obligation</Card.Header>
            <Card.Body>
                <Form onSubmit={(e)=>e.preventDefault()} ref={this.formRef}>
                    <Form.Group>
                        <Form.Label>Obligation Name*</Form.Label>
                        <Form.Control required type="text"
                                      placeholder="eg. FFIEC UBPR" id="obligationName"
                                      defaultValue={obligationName}
                                      onChange={this.onFormControlChange}
                                      onBlur={this.onBlurFormControlHandler}
                                      isInvalid={this.state.invalidFields.includes("obligationName")}
                        />
                        <Form.Control.Feedback type="invalid">
                            Please provide a name.
                        </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Version*</Form.Label>
                        <Form.Control required
                            placeholder="eg. 2018"
                            id="obligationVersion"
                            defaultValue={obligationVersion}
                            onChange={this.onFormControlChange}
                            onBlur={this.onBlurFormControlHandler}
                            isInvalid={this.state.invalidFields.includes("obligationVersion")}
                        />
                        <Form.Control.Feedback type="invalid">
                            Please provide version.
                        </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Description</Form.Label>
                        <FormEditor
                            initialValue={description}
                            onEditorChange={this.onEditorChangeHandler}/>
                    </Form.Group>
                </Form>
            </Card.Body>
        </Card>);
    }

}

ObligationSavePageForm.propTypes={
    obligationDetail: PropTypes.object
}

export default (ObligationSavePageForm)