import React, {Component} from "react";
import {Card, Form} from "react-bootstrap";
import FormTagSelector from "../../../../core/FormTagSelector";
import * as actions from "../../../../../actions/"
import {connect} from "react-redux";
import ArrayUtil from "../../../../../util/ArrayUtil";
import StringUtil from "../../../../../util/StringUtil";

class ObligationAttributesForm extends Component{

    static defaultProps={
        data:{
            id:0
        },
        onChange:()=>null
    }

    state={
        industryOptions:[],
        regionOptions:[],
        typeOptions:[],
        selectedIndustryTags:[],
        selectedRegionTags:[],
        selectedTypeTags:[],
        data:{
            id:0
        }
    }

    constructor(props) {
        super(props);
        this.onSelectorChangeHandler = this.onSelectorChangeHandler.bind(this);
        this.onTagCreatedHandler = this.onTagCreatedHandler.bind(this);
    }

    componentDidMount(){
        this.props.getEntityTags("obligation","industryTags");
        this.props.getEntityTags("obligation","regionTags");
        this.props.getEntityTags("obligation","typeTags");
    }

    componentDidUpdate(prevProps, prevState, snapshot){

        if(prevProps.data!==this.props.data){

            const {industryTags,regionTags,typeTags} = this.props.data;

            const state = this.state;
            state.data = this.props.data;

            state.selectedIndustryTags = ArrayUtil.parseToDropdownCollection(industryTags);
            state.selectedRegionTags = ArrayUtil.parseToDropdownCollection(regionTags);
            state.selectedTypeTags = ArrayUtil.parseToDropdownCollection(typeTags);
            this.setState(state);
        }

        if(prevProps.savedTagData!==this.props.savedTagData){

            let {industryTags,regionTags,typeTags} = this.props.data;
            const state = this.state;

            const {fieldName,value} = this.props.savedTagData;
            switch (fieldName) {
                case "industry_tags":
                    industryTags=ArrayUtil.addToCollection(industryTags,value);
                    state.selectedIndustryTags = ArrayUtil.parseToDropdownCollection(industryTags);
                    this.props.getEntityTags("obligation","industryTags");
                    this.props.onChange({
                        fieldName: "industryTags",
                        value: this.state.selectedIndustryTags
                    })
                    break;
                case "region_tags":
                    regionTags=ArrayUtil.addToCollection(regionTags,value);
                    state.selectedRegionTags = ArrayUtil.parseToDropdownCollection(regionTags);
                    this.props.getEntityTags("obligation","regionTags");
                    this.props.onChange({
                        fieldName: "regionTags",
                        value: this.state.selectedRegionTags
                    })
                    break;
                case "type_tags":
                    typeTags=ArrayUtil.addToCollection(typeTags,value);
                    state.selectedTypeTags = ArrayUtil.parseToDropdownCollection(typeTags);
                    this.props.getEntityTags("obligation","typeTags");
                    this.props.onChange({
                        fieldName: "typeTags",
                        value: this.state.selectedTypeTags
                    })
                    break;
                default:
                    break;
            }

            this.setState(state);
        }

        if(prevProps.entityTagsData!==this.props.entityTagsData){

            const state = this.state;

            const {entityTagsData} = this.props;
            const data = entityTagsData.map((item)=>{
                return {label:item.value,value:item.value}
            });
            if(data.length>0){
                const fieldName = entityTagsData[0].fieldName;
                switch (fieldName) {
                    case "industry_tags":
                        state.industryOptions = data;
                        break;
                    case "region_tags":
                        state.regionOptions = data;
                        break;
                    case "type_tags":
                        state.typeOptions = data;
                        break;
                    default:
                        break;
                }
            }
            this.setState(state);
        }
    }

    onSelectorChangeHandler(event) {
        const fieldName = event.target.name;
        const state = this.state;
        state[`selected${StringUtil.capitalize(fieldName)}`] = event.value;
        this.setState(state);
        this.props.onChange({
            fieldName: fieldName,
            value: event.value
        })
    }

    onTagCreatedHandler(event){
        const fieldName = event.id.split("-")[0];
        const tagRequest={
            entityName:"obligation",
            fieldName:fieldName,
            value:event.value
        }
        this.props.saveEntityTag(tagRequest);
    }

    render() {
        const {industryOptions,regionOptions,typeOptions,selectedIndustryTags,selectedRegionTags,selectedTypeTags} = this.state;
        return (
            <Card>
                <Card.Header>Attributes</Card.Header>
                <Card.Body>
                    <Form>
                        <Form.Group>
                            <Form.Label>Industry</Form.Label>
                            <FormTagSelector
                                name="industryTags"
                                value={selectedIndustryTags}
                                options={industryOptions}
                                onChange={this.onSelectorChangeHandler}
                            />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Region</Form.Label>
                            <FormTagSelector
                                name="regionTags"
                                value={selectedRegionTags}
                                options={regionOptions}
                                onChange={this.onSelectorChangeHandler}
                            />
                        </Form.Group>
                        <Form.Group>
                            <Form.Label>Type</Form.Label>
                            <FormTagSelector
                                name="typeTags"
                                value={selectedTypeTags}
                                options={typeOptions}
                                onChange={this.onSelectorChangeHandler}
                            />
                        </Form.Group>
                    </Form>
                </Card.Body>
            </Card>
        );
    }
}

const mapStateToProps = (state) =>{
    return({
        entityTagsData:state.searchFilter.entityTagsData,
        savedTagData:state.searchFilter.savedTagData
    })
}

export default connect(mapStateToProps,actions)(ObligationAttributesForm);