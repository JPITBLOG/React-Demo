import React, {Component} from 'react';
import {connect} from "react-redux";
import * as actions from "../../../../actions";
import withEventBus from "../../../core/withEventBus";
import UUIDUtil from "../../../../util/UUIDUtil";

import './ObligationTab.css';

import PaginationUtil from "../../../../util/PaginationUtil";
import TopActionMenu from "../../../core/TopActionMenu";
import ObjectUtil from "../../../../util/ObjectUtil";
import ExportUtil from "../../../../util/ExportUtil";
import ConfirmWindow from "../../../core/ConfirmWindow";

import {confirmAlert} from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import StringUtil from "../../../../util/StringUtil";
import DataTableIDLink from "../../../core/DataTable/DataTableIDLink";
import DataTable from "../../../core/DataTable";

import DataTableUtil from "../../../../util/DataTableUtil";
import ReportWrapper from "../../../core/reportWrapper";
import ReactToPrint from "react-to-print";
import SearchOnTypeV2 from "../../../core/SearchOnTypeV2";
import BulkFormWindow from "../../../core/BulkFormWindow";
import DataTableDateField from "../../../core/DataTable/DataTableDateField";
import DataTableDescriptionField from "../../../core/DataTable/DataTableDescriptionField";

class ObligationsTab extends Component{

    static defaultProps = {
        onLoad:()=>null
    };

    state={
        tableViewName: UUIDUtil.v4(),
        selectedItems: [],
        prevSelectedItems: [],
        pagination:PaginationUtil.generatePaginationRequest(0,50),
        lastPagination: "",
        sortDirection:PaginationUtil.initSortColumns(14),
        displayColumns: PaginationUtil.initDisplayColumns(14,[0,1,3,5,13]),
        filterList:PaginationUtil.initFilterLists(14),
        filters: [],
        lastFilters: [],
        editMode: false,
        searchOnTypeValue: "",
        searchLoading: false,
        isPrinting:false,
        bulkOptions:{
            show:false,
            type:"tag",
            fieldName:"industryTags",
            fieldLabel:"Industry"
        }
    }

    constructor(props) {
        super(props);
        this.onTableViewChangeHandler = this.onTableViewChangeHandler.bind(this);
        this.onSelectedHandler = this.onSelectedHandler.bind(this);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
        this.updateFilter = this.updateFilter.bind(this);
        this.isDeleteEnabled = this.isDeleteEnabled.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onExportHandler = this.onExportHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.onBulkChangeHandler = this.onBulkChangeHandler.bind(this);
        this.onBulkCloseHandler = this.onBulkCloseHandler.bind(this);
        this.onBulkActionHandler = this.onBulkActionHandler.bind(this);
        this.tableRef = null;
    }

    isDeleteEnabled(){
        return this.state.selectedItems.length > 0;
    }

    componentDidMount() {
        this.props.getObligationTableFilters();
        this.loadTopMenuItems();
    }

    loadTopMenuItems(){

        const {selectedItems} = this.state;
        const isSectionEnabled = selectedItems.length < 1;
        const deleteLabel = isSectionEnabled ? "Delete" : `Delete (${selectedItems.length} selected)`;

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Add New" icon="plus" onClick={this.onAddClickHandler} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label={deleteLabel} icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print" icon="print" onClick={()=>this.printRef.click()} />,
            <TopActionMenu.ButtonMenuSeparator/>,
            <TopActionMenu.ButtonMenuItem label="Bulk Operations" isTitle={true}/>,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label="Change Industry" icon="edit" onClick={() => this.onBulkChangeHandler("industryTags")} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label="Change Region" icon="edit" onClick={() => this.onBulkChangeHandler("regionTags")} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label="Change Type" icon="edit" onClick={() => this.onBulkChangeHandler("typeTags")} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label="Change Owner" icon="edit" onClick={() => this.onBulkChangeHandler("ownerId")} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload" icon="upload" onClick={(e) => console.log(e)} />
        ],false);

    }

    onBulkChangeHandler(type){

        const {bulkOptions} = this.state;

        switch (type) {
            case "industryTags":
                bulkOptions.fieldLabel="Industry";
                bulkOptions.type="tag";
                break;
            case "regionTags":
                bulkOptions.fieldLabel="Region";
                bulkOptions.type="tag";
                break;
            case "typeTags":
                bulkOptions.fieldLabel="Type";
                bulkOptions.type="tag";
                break;
            case "ownerId":
                bulkOptions.fieldLabel="Owner";
                bulkOptions.type="userSelect";
                break;
            default:
                bulkOptions.type="input";
        }

        bulkOptions.show=true;
        bulkOptions.fieldName=type;

        this.setState({bulkOptions});
    }

    onBulkCloseHandler(){
        const {bulkOptions} = this.state;
        bulkOptions.show=false;
        this.setState({bulkOptions});
    }

    onBulkActionHandler(event){

        const {selectedItems,bulkOptions} = this.state;
        console.log(event);

        let entityValues = [event.value];
        if(Array.isArray(event.value)){
            entityValues = event.value.map((item)=>item.value);
        }

        const formData = {
            entityName:"obligation",
            fieldName: event.target.name,
            entityIds: selectedItems.map((item)=>item.id),
            entityValues: entityValues,
            type: bulkOptions.type,
            replace: event?.replace
        }

        const internalIds = selectedItems.map((selectedItem)=>selectedItem.internalId);

        this.props.bulkUpdateRecords(formData,(data,err)=>{
            if(!err){
                this.executeSearch();
                this.props.getObligationTableFilters();
                this.props.setSystemMessage("success",`Record ${internalIds.join(", ")}, change ${bulkOptions.fieldLabel} saved`)
            }
        })
    }

    onDeleteHandler(){

        const {deleteObligations} = this.props;
        const {selectedItems} = this.state;
        const self = this;

        const deleteRecord = ()=>{
            const idsToDelete = self.state.selectedItems.map((item)=> item.referenceId);
            deleteObligations(idsToDelete,(data,err)=>{
                if(!err){
                    self.onClearSelected();
                    self.executeSearch();
                }
            })
        }

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow selectedItems={selectedItems.length} onClose={onClose} onAction={deleteRecord}/>
        });

    }

    onExportHandler(){
        const {items} = this.props.obligations;
        const {selectedItems}= this.state;
        ExportUtil.generateCsv(this.columns,(selectedItems.length > 0 ? selectedItems : items),"obligation");
    }

    componentDidUpdate(prevProps, prevState, snapshot){

        const {prevSelectedItems,selectedItems} = this.state;

        if(prevSelectedItems.length !== selectedItems.length){
            this.loadTopMenuItems();
            this.setState({prevSelectedItems:ObjectUtil.clone(selectedItems)});
        }

        const self = this;
        PaginationUtil.searchWithFilter(this.state,state=>{
            self.setState(state);
            self.executeSearch()
        });

    }

    onTableViewChangeHandler(event){
        const state = this.state;
        state.pagination = event;
        this.setState(state);
        this.executeSearch()
    }

    onSearchTypeHandler(event){
        this.updateFilter(event);
    }

    executeSearch(){

        this.setState({searchLoading:true});

        const {pagination,filters} = this.state;

        const activeFilters = PaginationUtil.getActiveFilters(filters);

        this.props.getObligationData(activeFilters,pagination,()=>this.setState({searchLoading:false}));

    }

    updateFilter(selectedFilter){
        const state = this.state;
        let filterUpdated = false;
        state.filters.forEach((filter,index)=>{
            if(filter.name === selectedFilter.name){
                state.filters[index].value = selectedFilter.value;
                filterUpdated=true;
            }
        });
        if(!filterUpdated){
            state.filters.push(selectedFilter);
        }
        this.setState(state);
    }

    onSelectedHandler(item) {
        this.setState({ selectedItems: item });
    }

    onAddClickHandler(){
        this.props.history.push('/grc-library/obligations/new');
    }

    getColumns(){

        const isOpenTab = (this.props.objectId !== 0 && this.props.objectId !== undefined);

        return [
            {
                label:"HiddenRefId",
                name:"referenceId",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label:"ID",
                name:"internalId",
                options: {
                    filter: false,
                    sort: true,
                    display: true,
                    customBodyRender: (value,tableMeta)=>
                        <DataTableIDLink newTab={isOpenTab}
                             value={value}
                             tableMeta={tableMeta}
                             uri="/grc-library/obligations"
                        />
                }
            },
            {
                label:"Obligation Name",
                name:"obligationName",
                options: {
                    sort: true,
                    display: true,
                    filter: false
                }
            },
            {
                label:"Description",
                name:"description",
                options: {
                    sort: true,
                    display: false,
                    filter: false,
                    customBodyRender: (value)=> <DataTableDescriptionField value={value}/>
                }
            },
            {
                label:"Version",
                name:"obligationVersion",
                options: {
                    sort: true,
                    display: true,
                    filter: false
                }
            },
            {
                label:"Obligation Section",
                name:"totalObligationSections",
                options: {
                    sort: true,
                    display: false,
                    filter: false
                }
            },
            {
                label:"Control Library",
                name:"totalControls",
                options: {
                    sort: true,
                    display: true,
                    filter: false
                }
            },
            {
                label:"Crosswalks",
                name:"totalCrosswalks",
                options: {
                    sort: true,
                    display: false,
                    filter: false
                }
            },
            {
                label:"Industry",
                name:"industryTags",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    customBodyRender: (value)=> StringUtil.join(value,", "),
                    filterOptions: this.props.tableFilters?.industryTags?.map((item)=>item.label)
                }
            },
            {
                label:"Region",
                name:"regionTags",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    customBodyRender: (value)=> StringUtil.join(value,", "),
                    filterOptions: this.props.tableFilters?.regionTags?.map((item)=>item.label)
                }
            },
            {
                label:"Type",
                name:"typeTags",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    customBodyRender: (value)=> StringUtil.join(value,", "),
                    filterOptions: this.props.tableFilters?.typeTags?.map((item)=>item.label)
                }
            },
            {
                label:"Owner",
                name:"ownerName",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.owners)
                }
            },
            {
                label:"Created By",
                name:"createdBy",
                options:{
                    filter: true,
                    sort: true,
                    display: false,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdBys)
                }
            },
            {
                label:"Created Date",
                name:"createdAt",
                options:{
                    filter: true,
                    sort: true,
                    display: false,
                    customBodyRender: (value)=> <DataTableDateField value={value}/> ,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateDateFilterOptions(this.props.tableFilters?.createdDates)
                }
            },
            {
                label:"Last Modified By",
                name:"updatedBy",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedBys)
                }
            },
            {
                label:"Last Modified Date",
                name:"updatedAt",
                options:{
                    filter: true,
                    sort: true,
                    display: true,
                    customBodyRender: (value)=> <DataTableDateField value={value}/>,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedDates)
                }
            }
        ]
    }

    render() {

        const {searchOnTypeValue,searchLoading,isPrinting,bulkOptions,selectedItems} = this.state
        console.log('data for get created date: ', this.props.obligations);
        debugger
        return(<div className="obligation-tab">

            <BulkFormWindow
                selectedItems={selectedItems}
                entityName="obligation"
                onClose={this.onBulkCloseHandler}
                onAction={this.onBulkActionHandler}
                {...bulkOptions}
            />

            <div className="single-content active">

                <div className="filter-form">
                    <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler}/>
                </div>

                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.tableRef}
                    onBeforeGetContent={()=>this.setState({isPrinting:true})}
                    onAfterPrint={()=>this.setState({isPrinting:false})}
                />

                <ReportWrapper entityName="Obligation" ref={el => (this.tableRef = el)} className="tab-container">
                    <DataTable
                        page={this.props.obligations}
                        loading={searchLoading}
                        columns={this.getColumns()}
                        isPrinting={isPrinting}
                        onPaginationChange={(e)=> this.setState({pagination:e})}
                        onFilterChange={(e)=>this.setState({filters:e})}
                        onSelected={this.onSelectedHandler}
                        title="Obligations"/>
                </ReportWrapper>

            </div>

        </div>);

    }
}

function mapStateToProps(state){
    return {
        obligations: state.grcLibrary.obligations,
        tableFilters: state.grcLibrary.obligationTableFilters
    }
}

export default withEventBus(connect(mapStateToProps,actions)(ObligationsTab));
