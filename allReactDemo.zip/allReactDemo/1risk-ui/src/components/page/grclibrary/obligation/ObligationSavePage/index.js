import React, {Component} from 'react';
import ActionOverlay from "../../../../core/ActionOverlay";
import {Button, Card, Col, Row} from "react-bootstrap";
import IconButton from "../../../../core/button/IconButton";
import pageWrapper, {PAGE_TYPE_ADD, PAGE_TYPE_EDIT} from "../../../../core/pageWrapper";
import PageUtil from "../../../../../util/PageUtil";
import {connect} from "react-redux";
import * as actions from '../../../../../actions/';
import ImageDropzone from "../../../../core/ImageDropzone";
import ObligationSavePageForm from "./ObligationSavePageForm";
import ObligationAttributesForm from "./ObligationAttributesForm";
import {SAVE_OBLIGATION_FORM, VALIDATE_OBLIGATION_FORM} from "../../../../../events/types";
import ArrayUtil from "../../../../../util/ArrayUtil";

class ObligationSavePage extends Component{

    state={
        obligationDetail:{},
        requiredFields: ["obligationName","obligationVersion"],
        lastLogoUrl:"",
        uploadInProgress: false,
        lastSavedId:""
    }

    componentDidMount(){

        this.props.resetSaveObligation();

        this.pageUtil = new PageUtil(this.props);
        if(this.pageUtil.exists("id") && this.pageUtil.get("id")!==undefined) {
            const {obligationDetail} = this.props;
            if (obligationDetail.id === undefined) {
                const obligationId = this.pageUtil.get("id");
                this.props.getObligationById(obligationId,(data,err)=>console.log(data));
            } else {
                this.setState({obligationDetail: this.props.obligationDetail});
            }
            const breadcrumb = {"title":"Grc Library","label":"Edit","init":false};
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_EDIT, "Obligations")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }else{
            const breadcrumb = {"title":"Grc Library","label":"Add New","init":false};
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_ADD, "Obligations")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }
        window.addEventListener(SAVE_OBLIGATION_FORM,this.onSaveHandler);
    }

    componentWillUnmount() {
        window.removeEventListener(SAVE_OBLIGATION_FORM,this.onSaveHandler);
    }

    componentDidUpdate(prevProps, prevState, snapshot){

        if(prevProps.obligationDetail!==this.props.obligationDetail){

            const state = this.state;

            const {internalId} = this.props.obligationDetail;
            const breadcrumb = {"title":"Grc Library","label":`${internalId}`,"init":false};
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb)
            this.props.onPageLoad(event);

            state.obligationDetail=this.props.obligationDetail;
            this.setState(state);

        }

    }

    constructor(props) {
        super(props);
        this.onCancelHandler = this.onCancelHandler.bind(this);
        this.onImageLoadHandler = this.onImageLoadHandler.bind(this);
        this.onImageClearHandler = this.onImageClearHandler.bind(this);
        this.onMainFormChange = this.onMainFormChange.bind(this);
        this.onClickSaveHandler = this.onClickSaveHandler.bind(this);
        this.onSaveHandler = this.onSaveHandler.bind(this);
        this.onTagsChangeHandler = this.onTagsChangeHandler.bind(this);
    }

    onSaveHandler(event){
        this.props.resetSaveObligation();
        const {obligationDetail,lastLogoUrl} = this.state;
        if(lastLogoUrl!==""){
            obligationDetail.logoUrl = lastLogoUrl;
        }
        this.props.saveObligation(obligationDetail,(data,err)=>{
            if(data && !err){
                this.props.history.push(`/grc-library/obligations/${data}`);
            }
        });
    }

    onCancelHandler(event){
        let redirectUrl = "/grc-library/obligations";
        if(this.pageUtil.exists("id")){
            redirectUrl+="/"+this.pageUtil.get("id");
        }
        this.props.history.push(redirectUrl);
        event.preventDefault();
    }

    onClickSaveHandler(event){
        window.dispatchEvent(new CustomEvent(VALIDATE_OBLIGATION_FORM,{detail: this.state.requiredFields}));
    }

    onImageLoadHandler(event){
        event.bucketPath="/public/dev/obligation";
        this.setState({uploadInProgress:true});
        this.props.uploadLogo(event,(location,err)=>{
            if(!err){
                const {obligationDetail} = this.state;
                obligationDetail.logoUrl=location;
                this.setState({obligationDetail});
                this.setState({lastLogoUrl:location});
            }
            this.setState({uploadInProgress:false});
        });
    }

    onImageClearHandler(){
        const {obligationDetail} = this.state;
        obligationDetail.logoUrl="";
        this.setState({obligationDetail});
    }

    onMainFormChange(event){
        const state = this.state;
        state.obligationDetail = Object.assign(state.obligationDetail, event);
        this.setState(state);
    }

    onTagsChangeHandler(event){
        if(!event.value){
            console.log("invalidEvent");
            return;
        }
        const state = this.state;
        const resultList = ArrayUtil.parseToStringCollection(event.value);
        state.obligationDetail[event.fieldName] = resultList;
        this.setState(state);
    }

    render() {
        const {obligationDetail,uploadInProgress} = this.state;
        return(<div className="save-container">
            <ActionOverlay visible={true}>
                <ActionOverlay.Actions>
                    <IconButton onClick={this.onClickSaveHandler} icon="check">Save</IconButton>
                    <Button onClick={this.onCancelHandler} variant="secondary">Cancel</Button>
                </ActionOverlay.Actions>
            </ActionOverlay>

            <Row>
                <Col lg={9} className="left-container">
                    <ObligationSavePageForm onInvalidate={(e)=>this.setState({invalid:e})} onChange={this.onMainFormChange} data={obligationDetail}/>
                </Col>
                <Col lg={3} className="right-container">
                    <Card>
                        <Card.Header>Logo</Card.Header>
                        <Card.Body>
                            <ImageDropzone loading={uploadInProgress} onLoad={this.onImageLoadHandler} onClear={this.onImageClearHandler} imageUrl={obligationDetail.logoUrl}/>
                        </Card.Body>
                    </Card>
                    <ObligationAttributesForm data={obligationDetail} onChange={this.onTagsChangeHandler}/>
                </Col>
            </Row>

        </div>)
    }
}

const mapStateToProps = (state) =>{
    return({
        obligationDetail: state.grcLibrary.obligationDetail,
        savedObligation: state.grcLibrary.savedObligation,
    })
}

export default pageWrapper(connect(mapStateToProps,actions)(ObligationSavePage))