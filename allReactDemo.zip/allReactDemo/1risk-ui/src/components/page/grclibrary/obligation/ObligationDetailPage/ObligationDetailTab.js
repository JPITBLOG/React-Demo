import React from "react";
import {Card, Col, Row} from "react-bootstrap";
import {connect, useSelector} from "react-redux";
import EntityInfoWidget from "../../../../core/EntityInfoWidget";
import ComponentUtil from "../../../../../util/ComponentUtil";
import AttributesContainer from "../../../../core/AttributesContainer";
import EntityUtil from "../../../../../util/EntityUtil";
import * as actions from "../../../../../actions/";

const ObligationDetailTab = (props) =>{

    const obligationDetail = useSelector(state => state.grcLibrary.obligationDetail);
    const {createdAt,updatedAt,internalId,ownerName} = obligationDetail;

    const getAttributes = ()=>{

        if(obligationDetail.id===undefined){
            return [];
        }

        const entity = new EntityUtil(obligationDetail);

        const attrList=[
            {
                title:"Industry",
                content:entity.getArray("industryTags"),
                type:"chip"
            },
            {
                title:"Region",
                content:entity.getArray("regionTags"),
                type:"chip"
            },
            {
                title:"Type",
                content:entity.getArray("typeTags"),
                type:"chip"
            }
        ];
        return attrList;
    }

    return(<div className="detail-page-container">
            <Row>
                <Col lg={8} className="left-col">
                    <Card className="card-section">
                        <Card.Body>
                            <Card.Title>Description</Card.Title>
                            <Card.Text dangerouslySetInnerHTML={ComponentUtil.createMarkup(obligationDetail.description)}></Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
                <Col lg={4} className="right-col">
                    <EntityInfoWidget createdAt={createdAt} updatedAt={updatedAt} ownerName={ownerName} recordId={internalId}/>
                    <AttributesContainer attributes={getAttributes()}/>
                </Col>
            </Row>
        </div>)
}

export default connect(null,actions)(ObligationDetailTab);