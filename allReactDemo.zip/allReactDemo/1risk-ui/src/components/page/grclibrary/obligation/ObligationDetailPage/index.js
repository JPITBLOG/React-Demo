import React, {Component} from "react";
import pageWrapper, {PAGE_TYPE_VIEW} from "../../../../core/pageWrapper";
import * as actions from "../../../../../actions"
import {connect} from "react-redux";
import PageUtil from "../../../../../util/PageUtil";
import DetailPageHeader from "../../../../core/DetailPageHeader";
import {Col, Row, Tab, Tabs} from "react-bootstrap";
import ObligationSectionsTab from "../../obligationSection/ObligationSectionsTab";
import ControlLibrariesTab from "../../controlLibrary/ControlLibrariesTab";
import CrosswalksTab from "../../crosswalk/CrosswalksTab";
import ObligationDetailTab from "./ObligationDetailTab";
import NotesTab from '../../notes/NotesTab';
import BrowserUtil from "../../../../../util/BrowserUtil";
import TopActionMenu from "../../../../core/TopActionMenu";
import AttachmentTab from '../../../attachments/AttachmentTab';
import ReactToPrint from "react-to-print";
import {confirmAlert} from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import
import ConfirmWindow from "../../../../core/ConfirmWindow";
import ReportWrapper from "../../../../core/reportWrapper";
import StringUtil from "../../../../../util/StringUtil";
import BreadcrumbUtil from "../../../../../util/BreadcrumbUtil";
import HistoryTab from '../../../history/HistoryTab';
import CommentTab from "../../../comment/CommentTab";

class ObligationDetailPage extends Component{

    state={
        activeTab: "details",
        tabs:[
            "details",
            "obligation-sections",
            "control-libraries",
            "crosswalks",
            "notes",
            "attachments",
            "comments",
            "history"
        ],
        obligationDetail:{}
    }

    constructor(props) {
        super(props);
        this.populatePage = this.populatePage.bind(this);
        this.populateHeader = this.populateHeader.bind(this);
        this.onTabSelectHandler = this.onTabSelectHandler.bind(this);
        this.onCancelHandler = this.onCancelHandler.bind(this)
        this.onEditClickHandler = this.onEditClickHandler.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
    }

    componentDidMount() {

        this.selectTabByUrl();
        BrowserUtil.scrollToTop();
        this.populatePage();
        this.loadTopMenuItems();

    }

    populatePage(){
        this.pageUtil = new PageUtil(this.props);
        if(this.pageUtil.exists("id")){
            const obligationId = this.pageUtil.get("id");
            this.props.getObligationById(obligationId,(response,err)=>{
                if(err){
                    this.props.history.push("/grc-library/obligations")
                }
            });
        }
    }

    loadTopMenuItems(){

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Edit" icon="edit" onClick={this.onEditClickHandler} />,
            <TopActionMenu.ButtonMenuItem label="Delete" icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print Screen" icon="print" onClick={()=>this.printRef.click()} />,
            <TopActionMenu.ButtonMenuItem disabled label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload Template" icon="upload" onClick={(e)=>console.log(e)} />
        ],false);

    }

    onDeleteHandler(){
        const {deleteObligation,history} = this.props;

        const deleteRecord = ()=>{
            deleteObligation(this.pageUtil.get("id"),(data,err)=>{
                if(!err){
                    history.push("/grc-library/obligations");
                }
            })
        }

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow onClose={onClose} onAction={deleteRecord}/>
        });

    }

    componentDidUpdate(prevProps, prevState, snapshot){

        if(prevProps.obligationDetail!==this.props.obligationDetail && this.props.obligationDetail !== this.state.obligationDetail){
            this.populateHeader(true);
            this.setState({obligationDetail:this.props.obligationDetail});
        }

        if(this.props.match.params!==prevProps.match.params){
            this.selectTabByUrl();
        }

    }

    selectTabByUrl(){
        const { tab } = this.props.match.params;
        const {tabs} = this.state;
        const selectedTab = tabs.filter((e) => e===tab);

        if(selectedTab.length>0){
            this.setState({activeTab:tab});
        }

        this.populateHeader(true);

    }

    onTabSelectHandler(tabName){

        const {referenceId} = this.props.obligationDetail;

        this.setState({activeTab:tabName});

        const url = `/grc-library/obligations/${referenceId}`;

        if(tabName==="details"){
            this.loadTopMenuItems();
            this.props.history.push(url);
        }else{
            this.props.history.push(url+"/"+tabName);
        }

    }

    populateHeader(init=false){
        this.pageUtil = new PageUtil()
        const {internalId,referenceId} = this.props.obligationDetail;
        const {activeTab} = this.state;
        if(internalId){
            let breadcrumb = BreadcrumbUtil.createRequest("Grc Library",internalId,true);
            if(activeTab!=="details"){
                const prev = breadcrumb;
                prev.uri = `/grc-library/obligations/${referenceId}`;
                breadcrumb = BreadcrumbUtil.createRequest("Grc Library",StringUtil.toTitleCase(activeTab),false,prev);
            }
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_VIEW, "Obligations")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }
    }

     onEditClickHandler = (event)=>{
        const obligationDetail=this.props.obligationDetail
        this.props.history.push(`/grc-library/obligations/edit/${obligationDetail?.referenceId}`);
        event.preventDefault();
    }

     onCancelHandler = (event)=>{
        const redirectUrl = "/grc-library/obligations";
        this.props.history.push(redirectUrl);
        event.preventDefault();
    }


    render(){
        const {obligationName,obligationVersion,logoUrl,id,referenceId} = this.props.obligationDetail;
        const infoHeader = <span><b>Version</b> {obligationVersion}</span>;
        return(
            <div>
                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.contentRef}
                />
                <ReportWrapper entityName="Obligation" ref={el => (this.contentRef=el)}>
                    <section  id="content-wrap" className="right-content-wrap">

                        <DetailPageHeader info={infoHeader} name={obligationName} logoUrl={logoUrl}/>
                        <Row className="tab-wrap">
                            <Col lg={12}>
                                <Tabs mountOnEnter={true} unmountOnExit={true} activeKey={this.state.activeTab} onSelect={this.onTabSelectHandler}>
                                    <Tab eventKey="details" title="Details">
                                        <ObligationDetailTab {...this.props}/>
                                    </Tab>
                                    <Tab eventKey="obligation-sections" title="Obligation Sections">
                                        <ObligationSectionsTab objectName="obligation" objectId={id} objectReferenceId={referenceId} {...this.props}/>
                                    </Tab>
                                    <Tab eventKey="control-libraries" title="Control Libraries">
                                        <ControlLibrariesTab objectName="obligation" objectId={id} objectReferenceId={referenceId} {...this.props}/>
                                    </Tab>
                                    <Tab eventKey="crosswalks" title="Crosswalks">
                                        <CrosswalksTab objectName="obligation" objectId={id} objectReferenceId={referenceId} {...this.props}/>
                                    </Tab>
                                    <Tab eventKey="notes" title="Notes">
                                        <NotesTab objectName="obligation" objectId={id} objectReferenceId={referenceId} {...this.props}/>
                                    </Tab>
                                    <Tab eventKey="attachments" title="Attachments">
                                        <AttachmentTab objectName="obligation" objectId={id} objectReferenceId={referenceId} {...this.props} />
                                    </Tab>
                                    <Tab eventKey="comments" title="Comments">
                                        <CommentTab objectName="obligation" objectId={id} {...this.props}/>
                                    </Tab>
                                    <Tab eventKey="history" title="History">
                                        <HistoryTab objectName="obligation" objectId={id} {...this.props}/>
                                    </Tab>
                                </Tabs>
                            </Col>
                        </Row>
                    </section>
                </ReportWrapper>
            </div>
        )
    }
}

const mapStateToProps = (state) =>{
    return({
        obligationDetail:state.grcLibrary.obligationDetail
    })
}


export default pageWrapper(connect(mapStateToProps,actions)(ObligationDetailPage));
