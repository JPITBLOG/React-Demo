import React, {Component} from 'react';
import {Col, Row, Tab, Tabs} from "react-bootstrap";
import ObligationsTab from "./obligation/ObligationsTab";
import ControlLibrariesTab from "./controlLibrary/ControlLibrariesTab";
import pageWrapper, {PAGE_TYPE_LIST} from "../../core/pageWrapper";
import withEventBus from "../../core/withEventBus";
import PageUtil from "../../../util/PageUtil";

import './GrcLibraryPage.css';
import {OBLIGATION_VIEW_CHANGED} from "../../../events/types";
import ObligationSectionsTab from "./obligationSection/ObligationSectionsTab";
import CrosswalksTab from "./crosswalk/CrosswalksTab";
import {connect} from "react-redux";
import * as actions from "../../../actions";

class GrcLibraryPage extends Component{

    constructor(props) {
        super(props);
        this.state={
            listViewMode: false,
            activeTab:"obligations",
            tabs:[
                {
                    eventKey:"obligations",
                    title:"Obligations",
                    component:<ObligationsTab {...this.props}/>
                },
                {
                    eventKey:"obligation-sections",
                    title:"Obligation Sections",
                    component:<ObligationSectionsTab {...this.props}/>
                },
                {
                    eventKey:"control-libraries",
                    title:"Control Libraries",
                    component: <ControlLibrariesTab {...this.props}/>
                },
                {
                    eventKey:"crosswalks",
                    title:"Crosswalks",
                    component:<CrosswalksTab {...this.props}/>
                }
            ]
        }
        this.onTabSelectHandler = this.onTabSelectHandler.bind(this);
        this.toggleListViewMode = this.toggleListViewMode.bind(this);
    }

    componentDidMount() {
        this.selectTabByUrl();
        this.props.getObligationFilter();
        this.props.getObligationData();
        this.props.getObligationSectionsData();
        this.props.getControlsData();
        this.props.getCrosswalksData();
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        this.props.resetObligation();
        this.props.resetObligationSection();
        if (this.props.match.params !== prevProps.match.params) {
            this.selectTabByUrl();

        }
    }

    selectTabByUrl(){
        const pageUtil = new PageUtil();
        const { tab } = this.props.match.params;
        const {tabs} = this.state;
        const selectedTab = tabs.filter((e) => e.eventKey===tab);

        if(selectedTab.length>0){
            const breadcrumb = {"title":"GRC Library","label":selectedTab[0].title,"init":true};
            const pageDescription = pageUtil.generatePageDescriptionRequest(PAGE_TYPE_LIST, selectedTab[0].title)
            const event = pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
            this.setState({activeTab:tab});
        }else{
            const breadcrumb = {"title":"GRC Library","label":"Obligation","init":true};
            const pageDescription = pageUtil.generatePageDescriptionRequest(PAGE_TYPE_LIST, selectedTab[0].title)
            const event = pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }
    }

    onTabSelectHandler(tabName,event){
        this.setState({activeTab:tabName});
        if(tabName==="obligations"){
            this.props.history.push("/grc-library");
        }else{
            this.props.history.push("/grc-library/"+tabName);
        }
    }

    toggleListViewMode(){
        this.setState({listViewMode:!this.state.listViewMode});
        this.props.eventBus.dispatch(OBLIGATION_VIEW_CHANGED,this.state.listViewMode);
    }

    render() {
        const {tabs} = this.state;
        return(<section id="content-wrap" className="right-content-wrap">
            <div className="inner-content">
                <Row className="tab-wrap, grc-content">
                    <Col lg={12}>
                        <Tabs mountOnEnter={true} unmountOnExit={true} activeKey={this.state.activeTab} onSelect={this.onTabSelectHandler}>
                            {tabs.map((tab,index)=>{
                                return(<Tab key={`grclibrary-tab-${index}`} eventKey={tab.eventKey} title={tab.title}>
                                    {tab.component}
                                </Tab>)
                            })}
                        </Tabs>
                    </Col>
                </Row>
            </div>
        </section>)
    }
}

export default withEventBus(pageWrapper(connect(null,actions)(GrcLibraryPage)));
