import React, { Component } from 'react';
import * as actions from "../../../../actions"
import { connect } from "react-redux";

import withEventBus from "../../../core/withEventBus";
import AttachmentsIcon from "../../../core/icon/AttachmentsIcon";
import UUIDUtil from '../../../../util/UUIDUtil';
import PaginationUtil from "../../../../util/PaginationUtil";
import ObjectUtil from "../../../../util/ObjectUtil";
import PropTypes from "prop-types";
import TopActionMenu from "../../../core/TopActionMenu";
import { confirmAlert } from "react-confirm-alert";
import ConfirmWindow from "../../../core/ConfirmWindow";
import ExportUtil from "../../../../util/ExportUtil";
import ReactToPrint from "react-to-print";
import ReportWrapper from "../../../core/reportWrapper";
import StringUtil from "../../../../util/StringUtil";
import DataTableIDLink from "../../../core/DataTable/DataTableIDLink";
import DataTable from "../../../core/DataTable";
import DateUtil from '../../../../util/DateUtil';
import DataTableUtil from "../../../../util/DataTableUtil";
import SearchOnTypeV2 from "../../../core/SearchOnTypeV2";

import _ from 'lodash';

class NotesTab extends Component {

    static propTypes = {
        objectId: PropTypes.number,
        objectName: PropTypes.string
    }

    static defaultProps = {
        objectName: "",
        objectId: 0
    }


    state = {
        selectedItems: [],
        prevSelectedItems: [],
        tableViewName: UUIDUtil.v4(),
        objectHash: "",
        pagination: PaginationUtil.generatePaginationRequest(0, 50),
        lastPagination: "",
        sortDirection: PaginationUtil.initSortColumns(14),
        displayColumns: PaginationUtil.initDisplayColumns(14, [0, 1, 3, 5, 13]),
        filterList: PaginationUtil.initFilterLists(14),
        filters: [],
        lastFilters: [],
        editMode: false,
        searchOnTypeValue: "",
        searchLoading: false,
        isPrinting: false
    }

    constructor(props) {
        super(props);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onFilterChangeHandler = this.onFilterChangeHandler.bind(this);
        this.onResetFiltersHandler = this.onResetFiltersHandler.bind(this);
        this.updateFilter = this.updateFilter.bind(this);
        this.onSelectedHandler = this.onSelectedHandler.bind(this);
        this.onClearSelected = this.onClearSelected.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onExportHandler = this.onExportHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
    }

    componentDidMount() {
        this.loadTopMenuItems();
        const {objectName,objectId} = this.props;
        if(objectName && objectId){
            const state = this.state;
            state.objectHash = ObjectUtil.hash(objectName,objectId);
            this.setState(state);
            this.props.getNoteTableFilters(state.objectHash);
        }else{
            this.props.getNoteTableFilters();
        }
    }

    loadTopMenuItems() {

        const { selectedItems } = this.state;
        const isSectionEnabled = selectedItems.length < 1;
        const deleteLabel = isSectionEnabled ? "Delete" : `Delete (${selectedItems.length} selected)`;

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Add New" icon="plus" onClick={this.onAddClickHandler} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label={deleteLabel} icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload" icon="upload" onClick={(e) => console.log(e)} />
        ], false);

    }

    onDeleteHandler() {

        const { deleteNotes } = this.props;
        const { selectedItems } = this.state;
        const self = this;

        const deleteRecord = () => {
            const idsToDelete = self.state.selectedItems.map((item) => item.referenceId);
            deleteNotes(idsToDelete, (data, err) => {
                if (!err) {
                    self.onClearSelected();
                    self.executeSearch();
                }
            })
        }

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow selectedItems={selectedItems.length} onClose={onClose} onAction={deleteRecord}/>
        });

    }

    onExportHandler() {
        const { items } = this.props.notesData;
        const { selectedItems } = this.state;
        ExportUtil.generateCsv(this.getColumns(), (selectedItems.length > 0 ? selectedItems : items), "notes");
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        const { prevSelectedItems, selectedItems, filters, lastFilters, pagination, lastPagination } = this.state;

        if (prevSelectedItems.length !== selectedItems.length) {
            this.loadTopMenuItems();
            this.setState({ prevSelectedItems: ObjectUtil.clone(selectedItems) });
        }

        // Add to support DataTable
        if (!_.isEqual(filters, lastFilters)) {
            this.setState({ lastFilters: ObjectUtil.clone(filters) });
            this.executeSearch();
        }

        // Add to support DataTable
        if (!_.isEqual(pagination, lastPagination)) {
            this.setState({ lastPagination: ObjectUtil.clone(pagination) });
            this.executeSearch();
        }
    }

    getColumns() {

        return [
            {
                label: "HiddenRefId",
                name: "referenceId",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "ID",
                name: "internalId",
                options: {
                    filter: false,
                    sort: true,
                    display: true,
                    customBodyRender: (value, tableMeta) =>
                        <DataTableIDLink
                             value={value}
                             tableMeta={tableMeta}
                             uri="/grc-library/notes"
                        />
                }
            },
            {
                label: "Title",
                name: "title",
                options: {
                    sort: true,
                    display: true,
                    filter: false
                }
            },
            {
                label: "Description",
                name: "content",
                options: {
                    sort: true,
                    display: false,
                    filter: false,
                    customBodyRender: (value) => StringUtil.ellipse(value, 150)
                }
            },
            {
                label: "Attachment",
                name: "totalAttachments",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                    customBodyRender: (value, tableMeta) => <AttachmentsIcon value={value} tableMeta={tableMeta} columnIdx ={5}/>
                }
            },
            {
                label: "Attachments",
                name: "attachments",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "Owner",
                name: "ownerName",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.owners)
                }
            },
            {
                label: "Created Date",
                name: "createdAt",
                options: {
                    filter: true,
                    sort: true,
                    display: false,
                    customBodyRender: (value) => DateUtil.format(value),
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdDates)
                }
            },
            {
                label: "Created By",
                name: "createdBy",
                options: {
                    filter: true,
                    sort: true,
                    display: false,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdBys)
                }
            },
            {
                label: "Last Modified Date",
                name: "updatedAt",
                options: {
                    filter: true,
                    sort: true,
                    display: true,
                    customBodyRender: (value) => DateUtil.format(value),
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedDates)
                }
            },
            {
                label: "Last Modified By",
                name: "updatedBy",
                options: {
                    sort: true,
                    display: true,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedBys)
                }
            }
        ]
    }

    onSearchTypeHandler(event) {
        this.updateFilter(event);
    }

    executeSearch() {
        const { pagination,filters } = this.state;
        this.setState({ searchLoading: true });

        PaginationUtil.prepareFilters(filters, "objectHash", ObjectUtil.hash(this.props.objectName,this.props.objectId));
        const activeFilters = PaginationUtil.getActiveFilters(filters);

        this.props.getNotesData(activeFilters, pagination, () => this.setState({ searchLoading: false }));
    }

    updateFilter(selectedFilter) {
        const state = this.state;
        let filterUpdated = false;
        state.filters.forEach((filter, index) => {
            if (filter.name === selectedFilter.name) {
                state.filters[index].value = selectedFilter.value;
                filterUpdated = true;
            }
        });
        if (!filterUpdated) {
            state.filters.push(selectedFilter);
        }
        this.setState(state);
    }

    onFilterChangeHandler(event) {
        if (PaginationUtil.isFilterChanged(event, this.state)) {
            this.updateFilter(event);
            this.executeSearch();
        }
    }

    onResetFiltersHandler(event) {
        const { pagination, objectHash } = this.state;
        this.setState({ filters: [objectHash] });
        this.props.getNotesData(objectHash, pagination);
    }

    onSelectedHandler(item) {
        this.setState({ selectedItems: item });
    }

    onClearSelected() {
        this.setState({ selectedItems: [] });
    }

    onAddClickHandler(event) {
        this.props.history.push('/grc-library/notes/new/' + this.state.objectHash);
    }

    render() {
        const { searchOnTypeValue, searchLoading, isPrinting } = this.state

        return (
            <div className="notes-tab">
                <div className="single-content active">

                    <div className="filter-form">
                        <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler} />
                    </div>

                    <ReactToPrint
                        trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                        content={() => this.tableRef}
                        onBeforeGetContent={() => this.setState({ isPrinting: true })}
                        onAfterPrint={() => this.setState({ isPrinting: false })}
                    />

                    <ReportWrapper entityName="Note" ref={el => (this.tableRef = el)} className="tab-container">
                        <DataTable
                            page={this.props.notesData}
                            loading={searchLoading}
                            columns={this.getColumns()}
                            isPrinting={isPrinting}
                            onPaginationChange={(e) => this.setState({ pagination: e })}
                            onFilterChange={(e) => this.setState({ filters: e })}
                            onSelected={this.onSelectedHandler}
                            title="Notes" />
                    </ReportWrapper>
                </div>
            </div>);
    }
}

function mapStateToProps(state) {
    return {
        obligationDetail: state.grcLibrary.obligationDetail,
        notesData: state.grcLibrary.notesData,
        tableFilters: state.grcLibrary.noteTableFilters
    }
}

export default withEventBus(connect(mapStateToProps, actions)(NotesTab));