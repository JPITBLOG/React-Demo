import React from "react";
import { Card, Col, Row } from "react-bootstrap";
import { connect, useSelector } from "react-redux";
import EntityInfoWidget from "../../../../core/EntityInfoWidget";
import ComponentUtil from "../../../../../util/ComponentUtil";
import * as actions from "../../../../../actions/";
import AttachmentsWidget from "../../../../core/AttachmentsWidget";

const NotesDetailTab = (props) => {

    const notesDetail = useSelector(state => state.grcLibrary.notesDetail);
    const { title, createdAt, updatedAt, ownerName, attachments } = notesDetail;

    return (<div className="detail-page-container">
        <Row>
            <Col lg={8} className="left-col">
                <div className="content-widget">
                    <Card className="card-section">
                        <Card.Header>Notes</Card.Header>
                        <Card.Body>
                            <section>
                                <Card.Title>
                                    Title
                            </Card.Title>
                                <Card.Text>
                                    <span>{title}</span>
                                </Card.Text>
                            </section>
                            <Card.Title>Description</Card.Title>
                            <Card.Text dangerouslySetInnerHTML={ComponentUtil.createMarkup(notesDetail.content)}></Card.Text>
                        </Card.Body>
                    </Card>
                </div>
            </Col>
            <Col lg={4} className="right-col">
                <EntityInfoWidget createdAt={createdAt} updatedAt={updatedAt} ownerName={ownerName} />
                <AttachmentsWidget attachments={attachments} />
            </Col>
        </Row>
    </div>)
}

export default connect(null, actions)(NotesDetailTab);