import React, { Component, createRef } from "react";
import { Card, Form } from "react-bootstrap";
import { SAVE_NOTES_FORM, VALIDATE_NOTES_FORM } from "../../../../../events/types";
import FormEditor from "../../../../core/FormEditor";


class NotesSavePageForm extends Component {

    static defaultProps = {
        data: {
            id: 0
        },
        onChange: () => null
    }

    state = {
        formData: {
            id: 0,
            content: "",
            objectId: 0,
            objectName: "",
            referenceId: "",
            title: ""
        },
        invalidFields: []
    }

    constructor(props) {
        super(props);
        this.onFormChangeHandler = this.onFormChangeHandler.bind(this);
        this.onFormControlChange = this.onFormControlChange.bind(this);
        this.onEditorChangeHandler = this.onEditorChangeHandler.bind(this);
        this.onBlurFormControlHandler = this.onBlurFormControlHandler.bind(this);
        this.onSaveFormListener = this.onSaveFormListener.bind(this);
        this.formRef = createRef();
    }

    onFormChangeHandler(event) {
        this.props.onChange(event);
    }

    onFormControlChange(event) {
        const { formData } = this.state;
        const { id, value } = event.target;
        formData[id] = value;

        this.setState({ formData });
        this.onFormChangeHandler(formData);

        event.preventDefault();
    }

    onEditorChangeHandler = (content, editor) => {
        const formData = this.state.formData;
        formData.content = content;
        this.setState({ formData });
        this.onFormChangeHandler(formData);
    }

    componentDidMount() {
        if (this.props.data.id && this.props.data.id !== 0) {
            this.setState({ formData: this.props.data });
        }
        window.addEventListener(VALIDATE_NOTES_FORM, this.onSaveFormListener);
    }

    onSaveFormListener(event) {
        const state = this.state;

        if (this.formRef && this.formRef.current) {
            const isValid = this.formRef.current.checkValidity()
            this.props.onInvalidate(!isValid);

            if (!isValid) {
                state.invalidFields = [];
                event.detail.forEach((fieldName) => {
                    if (state.formData[fieldName] !== undefined && state.formData[fieldName] === "") {
                        state.invalidFields.push(fieldName);
                    }
                })
                this.setState(state);
            } else {
                window.dispatchEvent(new Event(SAVE_NOTES_FORM));
            }
        }

    }

    componentWillUnmount(): void {
        window.removeEventListener(VALIDATE_NOTES_FORM, this.onSaveFormListener);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.data !== this.props.data) {
            this.setState({ formData: this.props.data });
        }
    }

    onBlurFormControlHandler(event) {
        const state = this.state;
        const target = event.currentTarget;
        if (target.required) {
            if (target.value.length === 0) {
                if (!state.invalidFields.includes(target.id)) {
                    state.invalidFields.push(target.id);
                }
            } else {
                if (state.invalidFields.includes(target.id)) {
                    const filteredList = state.invalidFields.filter(value => value !== target.id);
                    state.invalidFields = filteredList;
                }
            }
        }
        this.setState(state);
    }

    render() {
        const { title, content } = this.state.formData;
        return (<Card>
            <Card.Header>Notes</Card.Header>
            <Card.Body>
                <Form onSubmit={(e) => e.preventDefault()} ref={this.formRef}>
                    <Form.Group>
                        <Form.Label>Title*</Form.Label>
                        <Form.Control required type="text"
                            placeholder="eg. FFIEC UBPR" id="title"
                            defaultValue={title}
                            onChange={this.onFormControlChange}
                            onBlur={this.onBlurFormControlHandler}
                            isInvalid={this.state.invalidFields.includes("title")}
                        />
                        <Form.Control.Feedback type="invalid">
                            Please provide a title.
                        </Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group>
                        <Form.Label>Description*</Form.Label>
                        <FormEditor
                            isInvalid={this.state.invalidFields.includes("content")}
                            initialValue={content}
                            onEditorChange={this.onEditorChangeHandler} />
                        <Form.Control.Feedback type="invalid">
                            Please provide a content.
                        </Form.Control.Feedback>
                    </Form.Group>
                </Form>
            </Card.Body>
        </Card>);
    }

}

export default (NotesSavePageForm)