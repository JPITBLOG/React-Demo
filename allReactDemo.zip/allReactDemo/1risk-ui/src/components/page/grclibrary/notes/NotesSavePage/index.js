import React, {Component} from 'react';
import ActionOverlay from "../../../../core/ActionOverlay";
import {Button, Card, Col, Row} from "react-bootstrap";
import IconButton from "../../../../core/button/IconButton";
import pageWrapper, {PAGE_TYPE_ADD, PAGE_TYPE_EDIT} from "../../../../core/pageWrapper";
import PageUtil from "../../../../../util/PageUtil";
import {connect} from "react-redux";
import * as actions from '../../../../../actions/';
import FileUploadDropzone from "../../../../core/FileUploadDropzone";
import NotesSavePageForm from "./NotesSavePageForm";
import {SAVE_NOTES_FORM, VALIDATE_NOTES_FORM} from "../../../../../events/types";
import '../Notes.css';
import ObjectUtil from "../../../../../util/ObjectUtil";
import AttachedFileList from "../../../../core/AttachedFileList";

class NotesSavePage extends Component {

    state = {
        objectHash:"",
        notesDetail: {},
        requiredFields: ["title", "content"],
        docUrl: [],
        uploadInProgress: false,
        lastSavedId: "",
        attachmentsToSave: [],
        attachmentsToDelete: [],
        savedReferenceId:"",
        objectReferenceId:"",
        uploadCompleted:false
    }

    componentDidMount() {

        this.props.resetSaveNotes();

        this.pageUtil = new PageUtil(this.props);
        if (this.pageUtil.exists("id") && this.pageUtil.get("id") !== undefined) {
            const notesId = this.pageUtil.get("id");
            this.props.getNotesById(notesId, (data, err) => console.log(data));
            const breadcrumb = { "title": "Grc Library", "label": "Edit", "init": false };
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_EDIT, "Notes")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        } else {
            const breadcrumb = { "title": "Grc Library", "label": "Add New", "init": false };
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_ADD, "Notes")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }
        if(this.pageUtil.exists("objectHash")){
            const state = this.state;
            state.objectHash = this.pageUtil.get("objectHash");
            const objectInfo = ObjectUtil.parseHash(state.objectHash);
            state.notesDetail = {
                id:0,
                objectHash:state.objectHash,
                objectId: objectInfo.id,
                objectName: objectInfo.name
            };
            this.setState(state);
        }
        window.addEventListener(SAVE_NOTES_FORM, this.onSaveHandler);
    }

    componentWillUnmount() {
        window.removeEventListener(SAVE_NOTES_FORM, this.onSaveHandler);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        if(this.state.uploadCompleted){
            this.props.history.goBack();
        }

        if (prevProps.notesDetail !== this.props.notesDetail) {

            const state = this.state;

            const { internalId } = this.props.notesDetail;
            const breadcrumb = { "title": "Notes", "label": `${internalId}`, "init": false };
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb)
            this.props.onPageLoad(event);

            state.notesDetail = this.props.notesDetail;
            if(state.notesDetail.attachments.length>0){
                state.attachmentsToSave = state.notesDetail.attachments;
            }
            this.setState(state);

        }

    }

    constructor(props) {
        super(props);
        this.onCancelHandler = this.onCancelHandler.bind(this);
        this.onFileLoadHandler = this.onFileLoadHandler.bind(this);
        this.onFileClearHandler = this.onFileClearHandler.bind(this);
        this.onMainFormChange = this.onMainFormChange.bind(this);
        this.onClickSaveHandler = this.onClickSaveHandler.bind(this);
        this.onSaveHandler = this.onSaveHandler.bind(this);
    }

    onSaveHandler() {
        this.props.resetSaveNotes();
        const { notesDetail,attachmentsToSave} = this.state;
        this.props.saveNotes(notesDetail, (data, err) => {

            if(!err){
                this.setState({savedReferenceId:data})
            }

            if(attachmentsToSave.length>0){
                this.onAfterSaveHandler(data);
            }else{
                if (data && !err) {
                    this.props.history.goBack();
                }
                if(err){
                    this.props.sendErrorMsg(`Error on save note`);
                }
            }
        });
    }

    onAfterSaveHandler(noteReferenceId){
        this.setState({uploadInProgress:true});
        const { attachmentsToSave,attachmentsToDelete} = this.state;
        if(noteReferenceId){
            this.props.getNotesById(noteReferenceId,(data,err)=>{
               if(!err){
                   const {id}=data;
                   const needToSave = attachmentsToSave.filter((attachment)=>attachment.referenceId===undefined);
                   if(needToSave.length>0){
                       needToSave.forEach((attachment,idx)=>{
                           attachment.objectHash = ObjectUtil.hash("note",id);
                           attachment.path = "/notes";
                       });
                       this.props.uploadAttachments(needToSave,(data,err)=>{
                           if(!err){
                               if(attachmentsToDelete.length===0){
                                   this.setState({uploadCompleted:true});
                               }
                           }else{
                               this.props.sendErrorMsg(`Error on save attachments`);
                           }
                       });
                   }
                   const attachmentDeleteIds= attachmentsToDelete.map((attachment) => attachment.referenceId);
                   if(attachmentDeleteIds.length>0){
                       this.props.deleteAttachments(attachmentDeleteIds,(data,err)=>{
                           if(!err){
                               this.setState({uploadCompleted:true});
                           }
                       });
                   }
               }else{
                   this.props.sendErrorMsg(`Error on load notes: ${noteReferenceId}`);
               }
            });
        }

    }

    onCancelHandler(event) {
        this.props.history.goBack();
        event.preventDefault();
    }

    onClickSaveHandler(event) {
        window.dispatchEvent(new CustomEvent(VALIDATE_NOTES_FORM, { detail: this.state.requiredFields }));
        event.preventDefault();
    }

    onFileLoadHandler(event) {

        const {attachmentsToSave} = this.state;
        attachmentsToSave.push(event);
        this.setState(attachmentsToSave);

    }

    onFileClearHandler(event) {
        const state = this.state;
        const {item} = event;
        if(event.item.referenceId){
            state.attachmentsToDelete.push(event.item);
        }
        state.attachmentsToSave = state.attachmentsToSave.filter((attachment)=> {
            return attachment.name!== item.name && attachment.size !== item.size;
        });
        this.setState(state);
    }

    onMainFormChange(event) {
        const state = this.state;
        state.notesDetail = Object.assign(state.notesDetail, event);
        this.setState(state);
    }

    render() {
        const { notesDetail, uploadInProgress, attachmentsToSave } = this.state;
        return (<div className="save-container">
            <ActionOverlay visible={true}>
                <ActionOverlay.Actions>
                    <IconButton onClick={this.onClickSaveHandler} icon="check">Save</IconButton>
                    <Button onClick={this.onCancelHandler} variant="secondary">Cancel</Button>
                </ActionOverlay.Actions>
            </ActionOverlay>

            <Row>
                <Col lg={8} className="left-container">
                    <NotesSavePageForm onInvalidate={(e) => this.setState({ invalid: e })} onChange={this.onMainFormChange} data={notesDetail} />
                </Col>
                <Col lg={4} className="right-container">
                    <Card className="attachment-container">
                        <Card.Header>Attachment</Card.Header>
                        <Card.Body>
                            <FileUploadDropzone
                                isMultiple={true}
                                loading={uploadInProgress}
                                onLoad={this.onFileLoadHandler}
                                onClear={this.onFileLoadHandler}                               
                            />
                            {attachmentsToSave.length>0 && <section>
                                <Card.Title>Files</Card.Title>
                                <AttachedFileList attachments={attachmentsToSave} onDelete={this.onFileClearHandler}/>
                            </section>}
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

        </div>)
    }
}

const mapStateToProps = (state) => {
    return ({
        notesDetail: state.grcLibrary.notesDetail,
    })
}

export default pageWrapper(connect(mapStateToProps, actions)(NotesSavePage))