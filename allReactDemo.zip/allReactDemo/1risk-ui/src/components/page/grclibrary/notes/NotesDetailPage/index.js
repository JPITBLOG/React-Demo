import React, { Component } from "react";
import pageWrapper,{PAGE_TYPE_VIEW} from "../../../../core/pageWrapper";
import * as actions from "../../../../../actions"
import { connect } from "react-redux";
import PageUtil from "../../../../../util/PageUtil";
import BrowserUtil from "../../../../../util/BrowserUtil";
import NotesDetailTab from "./NotesDetailTab";
import TopActionMenu from "../../../../core/TopActionMenu";
import ReactToPrint from "react-to-print";
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import
import ConfirmWindow from "../../../../core/ConfirmWindow";
import ReportWrapper from "../../../../core/reportWrapper";

class NotesDetailPage extends Component {

    state = {
        notesDetail: {}
    }

    constructor(props) {
        super(props);
        this.populatePage = this.populatePage.bind(this);
        this.populateHeader = this.populateHeader.bind(this);
        this.onEditClickHandler = this.onEditClickHandler.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
    }

    componentDidMount() {
        BrowserUtil.scrollToTop();
        this.populatePage();
        this.loadTopMenuItems();
    }

    populatePage() {
        this.pageUtil = new PageUtil(this.props);
        if (this.pageUtil.exists("id")) {
            const notesId = this.pageUtil.get("id");
            this.props.getNotesById(notesId, (response, err) => {
                if (err) {
                    this.props.history.push("/grc-library/notes")
                }
            });
        }
    }

    loadTopMenuItems() {

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Edit" icon="edit" onClick={this.onEditClickHandler} />,
            <TopActionMenu.ButtonMenuItem label="Delete" icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print Screen" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuItem disabled label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload Template" icon="upload" onClick={(e) => console.log(e)} />
        ], false);

    }

    onEditClickHandler(event) {
        const notesDetail = this.props.notesDetail;
        this.props.history.push(`/grc-library/notes/edit/${notesDetail?.referenceId}`);
        event.preventDefault();
    }

    onDeleteHandler() {
        const { deleteNote, history } = this.props;

        const deleteRecord = () => {
            deleteNote(this.pageUtil.get("id"), (data, err) => {
                if (!err) {
                    history.goBack();
                }
            })
        }

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow onClose={onClose} onAction={deleteRecord} />
        });

    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        if (prevProps.location !== this.props.location) {
            this.props.resetSaveNotes();
            this.populatePage();
        }

        if (prevProps.notesDetail !== this.props.notesDetail && this.props.notesDetail !== this.state.notesDetail) {
            this.populateHeader();
            this.setState({ notesDetail: this.props.notesDetail });
        }
    }

    populateHeader(init = false) {
        const { internalId } = this.props.notesDetail;
        const breadcrumb = { "title": "Grc Library", "label": `${internalId}`, "init": init };        
        const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_VIEW, "Notes")
        const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
        this.props.onPageLoad(event);
    }

    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.contentRef}
                />
                <ReportWrapper entityName="Note" ref={el => (this.contentRef = el)}>
                    <section id="content-wrap" className="right-content-wrap">
                        <NotesDetailTab />
                    </section>
                </ReportWrapper>
            </div>)
    }
}

const mapStateToProps = (state) => {
    return ({
        notesDetail: state.grcLibrary.notesDetail,
        savedNotes: state.grcLibrary.savedNotes
    })
}


export default pageWrapper(connect(mapStateToProps, actions)(NotesDetailPage));