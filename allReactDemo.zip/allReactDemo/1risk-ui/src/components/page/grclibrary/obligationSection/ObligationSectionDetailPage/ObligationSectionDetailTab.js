import React from "react";
import {Card, Col, Row} from "react-bootstrap";
import {connect, useSelector} from "react-redux";
import EntityInfoWidget from "../../../../core/EntityInfoWidget";
import ComponentUtil from "../../../../../util/ComponentUtil";
import AttributesContainer from "../../../../core/AttributesContainer";
import EntityUtil from "../../../../../util/EntityUtil";
import * as actions from "../../../../../actions";

const ObligationSectionDetailTab = (props) =>{

    const obligationSectionDetail = useSelector(state => state.grcLibrary.obligationSectionDetail);
    const {createdAt,updatedAt,ownerName} = obligationSectionDetail;

    const getAttributes = ()=>{

        if(obligationSectionDetail.id===undefined){
            return [];
        }

        const entity = new EntityUtil(obligationSectionDetail);

        const attrList=[
            {
                title:"Obligation Name",
                content:{
                    label:entity.getString("obligationName"),
                    url:"/grc-library/obligations/"+entity.getString("obligationReferenceId")
                },
                type:"link"
            },
            {
                title:"Content Source",
                content:entity.getString("contentSource"),
            },
            {
                title:"Control Library",
                content:entity.getNumber("totalControls"),
            }
        ];
        return attrList;
    }

    return(<div className="detail-page-container">
        <Row>
            <Col lg={8} className="left-col">
                <Card className="card-section">
                    <Card.Body>
                        <Card.Title>Description</Card.Title>
                        <Card.Text dangerouslySetInnerHTML={ComponentUtil.createMarkup(obligationSectionDetail.description)}></Card.Text>
                    </Card.Body>
                </Card>
            </Col>
            <Col lg={4} className="right-col">
                <EntityInfoWidget createdAt={createdAt} updatedAt={updatedAt} ownerName={ownerName}/>
                <AttributesContainer attributes={getAttributes()}/>
            </Col>
        </Row>
    </div>)
}

export default connect(null,actions)(ObligationSectionDetailTab);