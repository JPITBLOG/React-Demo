import React from "react";
import NakedSelector from "../../../../core/NakedSelector";

const ControlListSort = ({onSelect=(e)=>console.log(e)}) =>{

    const sortByOptions = [
        {
            label: "Control Name",
            children:[
                {
                    label: "A-Z",
                    value: "ControlName-ASC"

                },
                {
                    label: "Z-A",
                    value: "ControlName-DESC"
                }
            ]
        },
        {
            label: "Content Source",
            children:[
                {
                    label: "A-Z",
                    value: "ContentSource-ASC"

                },
                {
                    label: "Z-A",
                    value: "ContentSource-ASC"
                }
            ]
        }
    ]

    return(<NakedSelector alignRight onSelect={onSelect} options={sortByOptions} placeholder="Control Name (A-Z)"/>)

}

export default (ControlListSort);
