import React, {Component} from 'react';
import {Collapse} from "react-bootstrap";
import {connect} from "react-redux";
import uuidv4 from 'uuid/v4';

import * as controlViewActions from '../../../../../../actions/ControlListViewActions';

import CollapseIcon from "../../../../../core/CollapseIcon";
import ControlListItemLabel from "../ControlListItemLabel";
import CheckboxIcon from "../../../../../core/CheckBoxIcon";
import ControlItemChips from "../ControlItemChips";
import MappedControlItems from "../MappedControlItems";

class ControlListItem extends Component{

    static defaultProps={
        item:{
            icon:"university",
            label:"Generic Label"
        },
        selected: false,
        onTagClick:(e)=>console.log(e)
    }

    constructor(props) {
        super(props);
        this.state={
            open:false,
            name:uuidv4(),
            selected:false,
            baseUrl: "/grc-library/control-libraries/"
        }

        this.toggleCollapseItem = this.toggleCollapseItem.bind(this);
        this.onTagClickHandler = this.onTagClickHandler.bind(this);

    }

    static getDerivedStateFromProps(props,state) {
        if(props.name){
            state.name=props.name;
        }
        if(props.selected){
            state.selected=props.selected;
        }
        if(props.data){
            if(!props.data.id){
                state.open = props.data.expanded;
            }
            if(props.data.id === state.name){
                state.open = props.data.expanded;
            }
        }
        return state;
    }

    isExpanded(){
        if(this.props.data){
            if(this.props.data.id){
                if( this.props.data.id === this.state.name){
                    return this.props.data.expanded;
                }
            }else{
                return this.props.data.expanded;
            }
        }else{
            return false;
        }
    }

    toggleCollapseItem(event){

        const {open} = this.state;
        this.props.controlViewItemCollapse(!open,this.state.name)
        this.setState({open:!this.state.open})
        event.preventDefault();

    }

    onTagClickHandler(event){
        this.props.onTagClick(event);
    }

    render() {
        const {item,selected,onCheckBoxClick} = this.props;
        return(<div className="single-item">
            <div className="item-head">
                <div onClick={onCheckBoxClick} className="custom-control custom-checkbox">
                    <CheckboxIcon selected={selected}/>
                </div>
                <ControlListItemLabel url={`${this.state.baseUrl}${item.id}`} custom={item.custom} label={item.label}/>
                <ControlItemChips item={item} onTagClick={this.onTagClickHandler}/>
                <span className="item-expandable">
                    <CollapseIcon onClick={this.toggleCollapseItem} expanded={this.isExpanded()}/>
                </span>
            </div>
            <Collapse in={this.isExpanded()}>
                <div className="item-content">
                    <p>{item.description}</p>
                    <MappedControlItems items={item.mapped} onTagClick={this.onTagClickHandler}/>
                </div>
            </Collapse>
        </div>);
    }
}

const mapStateToProps = (state)=>{
    return({
        data:state.controlView.data
    })
};

export default connect(mapStateToProps,controlViewActions)(ControlListItem)