import React, {Component} from 'react';
import * as actions from "../../../../actions"
import {connect} from "react-redux";

import './ControlLibrariesTab.css';
import withEventBus from "../../../core/withEventBus";
import ControlLibraryIcon from "../../../core/icon/ControlLibraryIcon";
import UUIDUtil from '../../../../util/UUIDUtil';
import PaginationUtil from "../../../../util/PaginationUtil";
import TabUtil from "../../../../util/TabUtil";
import PropTypes from "prop-types";

import ReactToPrint from "react-to-print";
import ReportWrapper from "../../../core/reportWrapper";
import ConfirmWindow from "../../../core/ConfirmWindow";
import {confirmAlert} from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css';
import TopActionMenu from "../../../core/TopActionMenu";
import ExportUtil from "../../../../util/ExportUtil";
import ObjectUtil from "../../../../util/ObjectUtil"; // Import css
import DataTableUtil from "../../../../util/DataTableUtil";
import DateUtil from "../../../../util/DateUtil";
import StringUtil from "../../../../util/StringUtil";
import DataTableIDLink from "../../../core/DataTable/DataTableIDLink";
import DataTable from "../../../core/DataTable";
import SearchOnTypeV2 from "../../../core/SearchOnTypeV2";
import BulkFormWindow from "../../../core/BulkFormWindow";
import DataTableDescriptionField from "../../../core/DataTable/DataTableDescriptionField";

class ControlLibrariesTab extends Component {

    static propTypes = {
        objectId: PropTypes.number,
        objectName: PropTypes.string,
        objectReferenceId: PropTypes.string
    }

    static defaultProps = {
        objectId: 0,
        objectName: "",
        objectReferenceId: ""
    }

    state = {
        selectedItems: [],
        prevSelectedItems: [],
        tableViewName: UUIDUtil.v4(),
        objectHash: "",
        objectName: "",
        objectId: 0,
        pagination: PaginationUtil.generatePaginationRequest(0, 50),
        lastPagination: "",
        filters: [],
        lastFilters: [],
        editMode: false,
        searchOnTypeValue: "",
        searchLoading: false,
        isPrinting: false,
        bulkOptions: {
            show: false,
            type: "tag",
            fieldName: "tags",
            fieldLabel: "Tags"
        }
    }

    constructor(props) {
        super(props);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onFilterChangeHandler = this.onFilterChangeHandler.bind(this);
        this.onResetFiltersHandler = this.onResetFiltersHandler.bind(this);
        this.updateFilter = this.updateFilter.bind(this);
        this.onSelectedHandler = this.onSelectedHandler.bind(this);
        this.onClearSelected = this.onClearSelected.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onExportHandler = this.onExportHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.onBulkChangeHandler = this.onBulkChangeHandler.bind(this);
        this.onBulkCloseHandler = this.onBulkCloseHandler.bind(this);
        this.onBulkActionHandler = this.onBulkActionHandler.bind(this);
        this.tabUtil = new TabUtil(this);
    }

    componentDidMount() {
        this.props.getControlTableFilters();
        this.tabUtil.loadSubTabFilter();
        this.loadTopMenuItems();

        const { objectName, objectReferenceId } = this.props;
        if (objectReferenceId !== "" && objectName !== "") {
            const state = this.state;
            state.objectHash = ObjectUtil.hashRef(objectName, objectReferenceId);
            this.setState(state);
        }
    }


    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.objectId !== this.props.objectId) {
            this.tabUtil.loadSubTabFilter();
        }

        if (prevProps.obligationSectionDetail !== this.props.obligationSectionDetail) {
            const { id, referenceId } = this.props.obligationSectionDetail;
            const state = this.state;
            state.objectHash = ObjectUtil.hashRef(this.props.objectName, referenceId);
            state.objectId = id;
            this.setState(state);
        }

        if (prevProps.obligationDetail !== this.props.obligationDetail) {
            const { id, referenceId } = this.props.obligationDetail;
            const state = this.state;
            state.objectHash = ObjectUtil.hashRef(this.props.objectName, referenceId);
            state.objectId = id;
            this.setState(state);
        }

        const { prevSelectedItems, selectedItems } = this.state;

        if (prevSelectedItems.length !== selectedItems.length) {
            this.loadTopMenuItems();
            this.setState({ prevSelectedItems: ObjectUtil.clone(selectedItems) });
        }

        const self = this;
        PaginationUtil.searchWithFilter(this.state, state => {
            self.setState(state);
            self.executeSearch()
        });

    }

    loadTopMenuItems() {

        const { selectedItems } = this.state;
        const isSectionEnabled = selectedItems.length < 1;
        const deleteLabel = isSectionEnabled ? "Delete" : `Delete (${selectedItems.length} selected)`;

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Add New" icon="plus" onClick={this.onAddClickHandler} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label={deleteLabel} icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuSeparator />,
            <TopActionMenu.ButtonMenuItem label="Bulk Operations" isTitle={true} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label="Change Type" icon="edit" onClick={() => this.onBulkChangeHandler("custom")} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label="Change Tags" icon="edit" onClick={() => this.onBulkChangeHandler("tags")} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label="Change Owner" icon="edit" onClick={() => this.onBulkChangeHandler("ownerId")} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload" icon="upload" onClick={(e) => console.log(e)} />
        ], false);

    }

    onBulkChangeHandler(type) {

        const { bulkOptions } = this.state;

        switch (type) {
            case "tags":
                bulkOptions.fieldLabel = "Tags";
                bulkOptions.type = "tag";
                break;
            case "ownerId":
                bulkOptions.fieldLabel = "Owner";
                bulkOptions.type = "userSelect";
                break;
            case "custom":
                bulkOptions.fieldLabel = "Type";
                bulkOptions.type = "bool";
                bulkOptions.options = [
                    {
                        label: <div><ControlLibraryIcon/> Institution Control</div>,
                        value: false
                    },
                    {
                        label: <div><ControlLibraryIcon custom/> Custom Control</div>,
                        value: true
                    }
                ];
                break;
            default:
                bulkOptions.type = "input";
        }

        bulkOptions.show = true;
        bulkOptions.fieldName = type;

        this.setState({ bulkOptions });
    }

    onBulkCloseHandler() {
        const { bulkOptions } = this.state;
        bulkOptions.show = false;
        this.setState({ bulkOptions });
    }

    onBulkActionHandler(event) {

        const { selectedItems, bulkOptions } = this.state;

        let entityValues = [event.value];
        if (Array.isArray(event.value)) {
            entityValues = event.value.map((item) => item.value);
        }

        const formData = {
            entityName: "control-library",
            fieldName: event.target.name,
            entityIds: selectedItems.map((item) => item.id),
            entityValues: entityValues,
            type: bulkOptions.type,
            replace: event?.replace
        }

        const internalIds = selectedItems.map((selectedItem) => selectedItem.internalId);

        this.props.bulkUpdateRecords(formData, (data, err) => {
            if (!err) {
                this.executeSearch();
                this.props.getControlTableFilters();
                this.props.setSystemMessage("success", `Record ${internalIds.join(",")}, change ${bulkOptions.fieldLabel} saved`)
            }
        })
    }

    onDeleteHandler() {

        const { deleteControlLibraries } = this.props;
        const { selectedItems } = this.state;
        const self = this;

        const deleteRecord = () => {
            const idsToDelete = self.state.selectedItems.map((item) => item.referenceId);
            deleteControlLibraries(idsToDelete, (data, err) => {
                if (!err) {
                    self.onClearSelected();
                    self.executeSearch();
                }
            })
        }

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow selectedItems={selectedItems.length} onClose={onClose} onAction={deleteRecord} />
        });

    }

    onExportHandler() {
        const { items } = this.props.controlsPage;
        const { selectedItems } = this.state;
        ExportUtil.generateCsv(this.getColumns(), (selectedItems.length > 0 ? selectedItems : items), "control-library");
    }

    getColumns() {
        const isOpenTab = (this.props.objectId !== 0 && this.props.objectId !== undefined);
        return [
            {
                label: "HiddenRefId",
                name: "referenceId",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "ID",
                name: "internalId",
                options: {
                    filter: false,
                    sort: true,
                    display: true,
                    customBodyRender: (value, tableMeta) =>
                        <DataTableIDLink newTab={isOpenTab}
                            value={value}
                            tableMeta={tableMeta}
                            uri="/grc-library/control-libraries"
                        />
                }
            },
            {
                label: "Control Name",
                name: "name",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                    customBodyRender: (value, tableMeta) => <ControlLibraryIcon customIdx={3} value={value} tableMeta={tableMeta} />

                },
            },
            {
                label: "Custom Control",
                name: "customControl",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "Description",
                name: "description",
                options: {
                    sort: true,
                    display: false,
                    filter: false,
                    customBodyRender: (value) => <DataTableDescriptionField value={value}/>
                }
            },
            {
                label: "Content Source",
                name: "contentSource",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                },
            },
            {
                label: "Obligation",
                name: "obligationName",
                options: {
                    sort: true,
                    display: true,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.obligationNames)
                },
            },
            {
                label: "Obligation Section",
                name: "obligationSectionName",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.obligationSectionNames)
                },
            },
            {
                label: "Crosswalks",
                name: "totalCrosswalks",
                options: {
                    sort: true,
                    display: true,
                    filter: false
                }
            },
            {
                label: "Tags",
                name: "tags",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    customBodyRender: (value) => StringUtil.join(value, ", "),
                    filterOptions: this.props.tableFilters?.tags?.map((item) => item.label)
                }
            },
            {
                label: "Owner",
                name: "ownerName",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.owners)
                }
            },
            {
                label: "Created Date",
                name: "createdAt",
                options: {
                    filter: true,
                    sort: true,
                    display: false,
                    customBodyRender: (value) => DateUtil.format(value),
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdDates)
                }
            },
            {
                label: "Created By",
                name: "createdBy",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdBys)
                }
            },
            {
                label: "Last Modified Date",
                name: "updatedAt",
                options: {
                    filter: true,
                    sort: true,
                    display: true,
                    customBodyRender: (value) => DateUtil.format(value),
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedDates)
                }
            },
            {
                label: "Last Modified By",
                name: "updatedBy",
                options: {
                    sort: true,
                    display: true,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedBys)
                }
            }
        ]

    }

    onSearchTypeHandler(event) {
        this.updateFilter(event);
    }

    executeSearch() {
        this.setState({ searchLoading: true });

        const { filters, pagination } = this.state;

        PaginationUtil.prepareFilters(filters, this.props.objectName, this.props.objectId);
        const activeFilters = PaginationUtil.getActiveFilters(filters);

        this.props.getControlsData(activeFilters, pagination, () => this.setState({ searchLoading: false }));
    }

    updateFilter(selectedFilter) {
        const state = this.state;
        let filterUpdated = false;
        state.filters.forEach((filter, index) => {
            if (filter.name === selectedFilter.name) {
                state.filters[index].value = selectedFilter.value;
                filterUpdated = true;
            }
        });
        if (!filterUpdated) {
            state.filters.push(selectedFilter);
        }
        this.setState(state);
    }

    onFilterChangeHandler(event) {
        if (PaginationUtil.isFilterChanged(event, this.state)) {
            this.updateFilter(event);
            this.executeSearch();
        }
    }

    onResetFiltersHandler(event) {
        this.setState({ filters: [] });
        this.executeSearch();
    }

    onSelectedHandler(item) {
        this.setState({ selectedItems: item });
    }

    onClearSelected() {
        this.setState({ selectedItems: [] });
    }

    onAddClickHandler(event) {

        let addNewUrl = "/grc-library/control-libraries/new";
        if (this.state.objectHash) {
            addNewUrl += "/" + this.state.objectHash;
        }

        this.props.history.push(addNewUrl);

    }

    render() {
        const { searchOnTypeValue, searchLoading, isPrinting, bulkOptions, selectedItems } = this.state;

        return (
            <div className="controls-tab">
                <BulkFormWindow
                    selectedItems={selectedItems}
                    entityName="control-library"
                    onClose={this.onBulkCloseHandler}
                    onAction={this.onBulkActionHandler}
                    {...bulkOptions}
                />
                <div className="single-content active">

                    <div className="filter-form">
                        <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler} />
                    </div>

                    <ReactToPrint
                        trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                        content={() => this.tableRef}
                        onBeforeGetContent={() => this.setState({ isPrinting: true })}
                        onAfterPrint={() => this.setState({ isPrinting: false })}
                    />

                    <ReportWrapper entityName="Control Library" ref={el => (this.tableRef = el)} className="tab-container">
                        <DataTable
                            page={this.props.controlsPage}
                            loading={searchLoading}
                            columns={this.getColumns()}
                            isPrinting={isPrinting}
                            onPaginationChange={(e) => this.setState({ pagination: e })}
                            onFilterChange={(e) => this.setState({ filters: e })}
                            onSelected={this.onSelectedHandler}
                            title="Control Libraries" />
                    </ReportWrapper>
                </div>
            </div>);
    }
}

function mapStateToProps(state) {
    return {
        controlsPage: state.grcLibrary.controlsPage,
        obligationDetail: state.grcLibrary.obligationDetail,
        obligationSectionDetail: state.grcLibrary.obligationSectionDetail,
        tableFilters: state.grcLibrary.controlLibraryTableFilters
    }
}

export default withEventBus(connect(mapStateToProps, actions)(ControlLibrariesTab));