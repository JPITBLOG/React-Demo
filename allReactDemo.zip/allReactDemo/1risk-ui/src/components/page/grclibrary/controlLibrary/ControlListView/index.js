import React, {Component} from 'react';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import ControlListItem from "./itemrender/ControlListItem";
import {faMinusSquare, faPlusSquare} from "@fortawesome/free-regular-svg-icons";
import {connect} from "react-redux";
import {Col, Row} from 'react-bootstrap'

import * as controlViewActions from '../../../../../actions/ControlListViewActions';

import './ControlListView.css';
import ControlListSort from "./ControlListSort";

class ControlListView extends Component{

    static defaultProps={
        controls:{
            items:[],
            totalPages:0
        },
        onTagClick:(e)=>console.log(e)
    }

    constructor(props) {
        super(props);
        this.state= {
            selectedItems: []
        }

        this.onExpandAllHandler=this.onExpandAllHandler.bind(this);
        this.onCollapseAllHandler = this.onCollapseAllHandler.bind(this);
        this.onCheckBoxItemClickHandler = this.onCheckBoxItemClickHandler.bind(this);
        this.onSelectSortBy = this.onSelectSortBy.bind(this);
        this.onTagClickHandler = this.onTagClickHandler.bind(this);
    }

    onExpandAllHandler(event){
        this.props.controlViewCollapse(true);
        event.preventDefault();
    }

    onCollapseAllHandler(event){
        this.props.controlViewCollapse(false);
        event.preventDefault();
    }

    onCheckBoxItemClickHandler(event,item){

        const state = this.state;
        if(!state.selectedItems.includes(item.id)){
            state.selectedItems.push(item.id);
        }else{
            state.selectedItems=state.selectedItems.filter(function(value){
                return value !== item.id;
            });
        }

        this.setState(state);

    }

    isSelected(item){

        if(this.state.selectedItems.includes(item.id)){
            return true;
        }

        return false;

    }

    onSelectSortBy(value){
        console.log(value);
    }

    onTagClickHandler(e){
        this.props.onTagClick(e);
    }

    render() {
        const {items, totalSize} = this.props.controls;
        return (
            <div className="controls-list-view">
                <div className="controls-filter-content">
                    <Row className="controls-filter-content-top">
                        <Col md={6}>
                            <span className="total-item-number">{totalSize} Controls</span>
                        </Col>
                        <Col md={6} className="d-flex justify-content-end grid-actions">
                            {!this.props.controlViewExpanded && <span onClick={this.onExpandAllHandler} className="item-expand">
                                <FontAwesomeIcon fixedWidth icon={faPlusSquare}/> Expand all
                            </span>}
                            {this.props.controlViewExpanded && <span onClick={this.onCollapseAllHandler} className="item-collapse">
                                <FontAwesomeIcon fixedWidth icon={faMinusSquare}/> Collapse all
                            </span>}
                            <ControlListSort onSelect={this.onSelectSortBy}/>
                        </Col>
                    </Row>
                    <div className="controls-filter-items">
                        {items.map((item,index)=>{
                            return(
                                <ControlListItem
                                    key={index}
                                    item={item}
                                    selected={this.isSelected(item)}
                                    onTagClick={this.onTagClickHandler}
                                    onCheckBoxClick={
                                        (e)=>this.onCheckBoxItemClickHandler(e,item)
                                    }
                                />);
                        })}
                    </div>
                </div>
            </div>
        );
    }

}

const mapStateToProps = (state)=>{
    return({
        controlViewExpanded:state.controlView.data.expanded,
    })
};

export default connect(mapStateToProps,controlViewActions)(ControlListView)