import React, {Component} from "react";
import ActionOverlay from "../../../../core/ActionOverlay";
import IconButton from "../../../../core/button/IconButton";
import {Button, Col, Row} from "react-bootstrap";
import ControlLibrarySavePageForm from "./ControlLibrarySavePageForm";
import {SAVE_CONTROL_LIBRARY_FORM, VALIDATE_CONTROL_LIBRARY_FORM} from "../../../../../events/types";
import PageUtil from "../../../../../util/PageUtil";
import pageWrapper, {PAGE_TYPE_ADD, PAGE_TYPE_EDIT} from "../../../../core/pageWrapper";
import {connect} from "react-redux";
import * as actions from '../../../../../actions/';
import ArrayUtil from "../../../../../util/ArrayUtil";
import ControlLibraryAttributesForm from "./ControlLibraryAttributesForm";
import ObjectUtil from "../../../../../util/ObjectUtil";

class ControlLibrarySavePage extends Component {

    state = {
        controlDetail: {
            id: 0
        },
        requiredFields: ["name", "obligationId", "obligationSectionId", "description", "contentSource"]
    }

    constructor(props) {
        super(props);      
        this.onClickSaveHandler = this.onClickSaveHandler.bind(this);
        this.onCancelHandler = this.onCancelHandler.bind(this);
        this.onSaveHandler = this.onSaveHandler.bind(this);
        this.onMainFormChange = this.onMainFormChange.bind(this);
        this.onTagsChangeHandler = this.onTagsChangeHandler.bind(this);
    }

    componentDidMount() {
        this.props.resetSaveControlLibrary();
        this.pageUtil = new PageUtil(this.props);

        if (this.pageUtil.exists("id") && this.pageUtil.get("id") !== undefined) {
            const { controlDetail } = this.props;
            if (controlDetail.id === undefined) {
                const controlDetailId = this.pageUtil.get("id");
                this.props.getControlById(controlDetailId,(controlLibrary,err)=>{
                    if(err){
                        this.props.sendErrorMsg(`Control Library id: ${controlDetailId} not found!` );
                        this.props.history.goBack();
                    }

                });
            } else {
                this.setState({ controlDetail: this.props.controlDetail });
            }
            const breadcrumb = {"title":"Grc Library","label":"Edit","init":false};
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_EDIT, "Control Library")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)        
            this.props.onPageLoad(event);
        } else {
            const breadcrumb = { "title": "Grc Library", "label": "Add New", "init": false };
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_ADD, "Control Library")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)            
            this.props.onPageLoad(event);
        }

        if(this.pageUtil.exists("objectHash")){
            const state = this.state;
            state.objectHash = this.pageUtil.get("objectHash");
            const objectInfo = ObjectUtil.parseHashRef(state.objectHash);
            if(objectInfo.name==="obligation"){
                this.props.getObligationById(objectInfo.id);
            }
            if(objectInfo.name==="obligation-section"){
                this.props.getObligationSectionsById(objectInfo.id);
            }
            this.setState(state);
        }

        window.addEventListener(SAVE_CONTROL_LIBRARY_FORM, this.onSaveHandler);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.controlDetail !== this.props.controlDetail) {
            const state = this.state;

            const { internalId } = this.props.controlDetail;
            const breadcrumb = { "title": "Grc Library", "label": `${internalId}`, "init": false };
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb)
            this.props.onPageLoad(event);

            state.controlDetail = this.props.controlDetail;
            this.setState(state);

        }

        if (prevProps.obligations !== this.props.obligations) {
            const state = this.state;

            const { obligations } = this.props;
            state.obligationOptions = obligations.items.map((ob) => {
                return {
                    label: ob.obligationName,
                    value: ob.id
                }
            });
            this.setState(state);

        }

        if (prevProps.savedControlLibrary !== this.props.savedControlLibrary) {
            // console.log('saved Control library---', this.props.savedControlLibrary);
            if (this.props.savedControlLibrary !== "") {
                const breadcrumb = { "title": "Grc Library", "label": "Control Library", "init": true }
                const event = this.pageUtil.generatePageLoadRequest(breadcrumb)            
                this.props.onPageLoad(event);
                this.props.history.push(`/grc-library/control-libraries/${this.props.savedControlLibrary}`);
            }
        }
    }

    componentWillUnmount() {
        window.removeEventListener(SAVE_CONTROL_LIBRARY_FORM, this.onSaveHandler);
    }

    onSaveHandler(event) {
        this.props.resetSaveControlLibrary();
        const { controlDetail } = this.state;

        this.props.saveControlLibrary(controlDetail, (data, err) => {
            if (data && !err) {
                this.props.onPageLoad({ "title": "Control-Library", "label": "Control Library", "init": true });
                if(this.state.objectHash){
                    this.props.history.goBack();
                }else{
                    this.props.history.push(`/grc-library/control-libraries/${data}`);
                }

            }
        });

        this.props.resetObligation();
        this.props.resetObligationSection();
    }

    onTagsChangeHandler(event) {
        if (!event.value) {
            console.log("invalidEvent");
            return;
        }
        const state = this.state;
        const resultList = ArrayUtil.parseToStringCollection(event.value);
        state.controlDetail[event.fieldName] = resultList;
        this.setState(state);
    }

    onClickSaveHandler(event) {
        window.dispatchEvent(new CustomEvent(VALIDATE_CONTROL_LIBRARY_FORM, { detail: this.state.requiredFields }));
        event.preventDefault();
    }

    onCancelHandler(event) {
        if(this.props.obligationDetail.id){
            this.props.history.push("/grc-library/obligations/" + this.props.obligationDetail.referenceId + "/control-libraries");
        }
        else if(this.props.obligationSectionDetail.id){
            // console.log(this.props.obligationSectionDetail.referenceId)
            this.props.history.push("/grc-library/obligation-sections/" + this.props.obligationSectionDetail.referenceId + "/control-libraries");
        }
        else{
            if (this.pageUtil.exists("id") && this.pageUtil.get("id") !== undefined) {
                this.props.history.push("/grc-library/control-libraries/" + this.pageUtil.get("id"));
            } else {
                this.props.history.push("/grc-library/control-libraries");
            }
        }
        this.props.resetObligation();
        this.props.resetObligationSection();
        event.preventDefault();
    }

    onMainFormChange(event) {
        const state = this.state;
        state.controlDetail = Object.assign(state.controlDetail, event);
        this.setState(state);
    }

    render() {
        const { controlDetail } = this.state;
        return (<div className="save-container">

            <ActionOverlay visible={true}>
                <ActionOverlay.Actions>
                    <IconButton onClick={this.onClickSaveHandler} icon="check">Save</IconButton>
                    <Button onClick={this.onCancelHandler} variant="secondary">Cancel</Button>
                </ActionOverlay.Actions>
            </ActionOverlay>

            <Row>
                <Col lg={9} className="left-container">
                    <ControlLibrarySavePageForm
                        onInvalidate={(e) => this.setState({ invalid: e })}
                        onChange={this.onMainFormChange}
                        data={controlDetail} />
                </Col>
                <Col lg={3} className="right-container">
                    <ControlLibraryAttributesForm data={controlDetail} onChange={this.onTagsChangeHandler} />
                </Col>
            </Row>

        </div>)
    }
}

const mapStateToProps = (state) => {
    return ({
        obligationDetail:state.grcLibrary.obligationDetail,
        controlDetail: state.grcLibrary.controlDetail,
        obligationSectionDetail:state.grcLibrary.obligationSectionDetail
    })
}


export default pageWrapper(connect(mapStateToProps, actions)(ControlLibrarySavePage));