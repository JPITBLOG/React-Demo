import React, {Component, createRef} from "react";
import {Card, Form} from "react-bootstrap";
import ControlLibraryIcon from "../../../../core/icon/ControlLibraryIcon";
import RadioGroup from "../../../../core/RadioGroup";
import {connect} from "react-redux";
import * as actions from '../../../../../actions/';
import {VALIDATE_CONTROL_LIBRARY_FORM, SAVE_CONTROL_LIBRARY_FORM} from "../../../../../events/types";
import FormSelector from "../../../../core/FormSelector";
import FormEditor from "../../../../core/FormEditor";
import ArrayUtil from "../../../../../util/ArrayUtil";
import FormValue from "../../../../core/FormValue";

class ControlLibrarySavePageForm extends Component{

    static defaultProps={
        onChange:()=>null
    }

    state={
        lastObligationId:0,
        lastObligationSectionId:0,
        formData:{
            id:0,
            name: "",
            customControl: false,
            contentSource: "",
            description: "",
            obligationId: 0,
            obligationSectionId: 0,
            tags:[]
        },
        invalidFields:[],
        obligations:[],
        obligationSections:[],
        customOptions:[
            {
                label: <div><ControlLibraryIcon/> Institution Control</div>,
                value: false
            },
            {
                label: <div><ControlLibraryIcon custom/> Custom Control</div>,
                value: true
            }
        ],
        optionTags:[]
    }

    constructor(props) {
        super(props);
        this.onFormControlChange = this.onFormControlChange.bind(this);
        this.onBlurFormControlHandler = this.onBlurFormControlHandler.bind(this);
        this.onEditorChangeHandler = this.onEditorChangeHandler.bind(this);
        this.onFormChangeHandler = this.onFormChangeHandler.bind(this);
        this.onSelectorChangeHandler = this.onSelectorChangeHandler.bind(this);
        this.onTagCreatedHandler = this.onTagCreatedHandler.bind(this);
        this.onSaveFormListener = this.onSaveFormListener.bind(this);
        this.formRef = createRef();
    }

    componentDidMount(event){
        if(this.props.obligationDetail.id && this.props.obligationDetail.id!==0){
            this.props.getObligationSectionFilter(this.props.obligationDetail.id);
        }
        if(this.props.data.id && this.props.data.id !==0){
            this.setState({formData:this.props.data});
        }
        if(this.props.obligationsFilterData.length === 0){
            this.props.getObligationFilter();
        }else{
            this.setState({obligations:this.props.obligationsFilterData});
        }
        window.addEventListener(VALIDATE_CONTROL_LIBRARY_FORM,this.onSaveFormListener);
    }

    componentWillUnmount(){
        window.removeEventListener(VALIDATE_CONTROL_LIBRARY_FORM,this.onSaveFormListener);
    }

    componentDidUpdate(prevProps, prevState, snapshot){

        if(prevProps.obligationsFilterData!==this.props.obligationsFilterData){
            this.setState({obligations:this.props.obligationsFilterData});
        }

        if(prevProps.obligationSectionsData!==this.props.obligationSectionsData){
            this.setState({obligationSections:this.props.obligationSectionsData});
        }

        if(prevProps.entityTagsData!==this.props.entityTagsData){
            const {entityTagsData} = this.props;
            const data = entityTagsData.map((item)=>{
                return {label:item.value,value:item.value}
            });
            this.setState({optionTags:data});
        }

        if(prevProps.data !== this.props.data){
            const state = this.state;
            const {obligationId,obligationSectionId} = this.props.data;
            state.lastObligationId=obligationId;
            state.lastObligationSectionId=obligationSectionId;
            const obligationDataId=this.props.data.obligationId;
            this.props.getObligationSectionFilter("" +obligationDataId)
            this.setState({formData:this.props.data});
        }

        if(prevProps.obligationDetail!==this.props.obligationDetail){
            const {id}=this.props.obligationDetail;
            const {formData} = this.state;
            formData.obligationId = id;
            this.setState({formData});
        }

        // Need better investigation

        const {obligationId,obligationSectionId} = this.state.formData;
        const {lastObligationId,lastObligationSectionId} = this.state;

        if(obligationId===undefined && lastObligationId!==0){
            const {formData} = this.state;
            formData.obligationId=lastObligationId;
            this.setState({formData})
        }

        if(obligationSectionId===undefined && lastObligationSectionId!==0){
            const {formData} = this.state;
            formData.obligationSectionId = lastObligationSectionId;
            this.setState({formData})
        }


        if(prevProps.obligationSectionDetail!==this.props.obligationSectionDetail){

            const {id,obligationId}=this.props.obligationSectionDetail;
            const {formData} = this.state;

            formData.obligationSectionId = id;
            formData.obligationId = obligationId;
            this.setState({formData});

        }

    }

    onSaveFormListener(event){

        const state = this.state;

        if(this.formRef && this.formRef.current){
            const { obligationId, obligationSectionId } = this.state.formData;
            const isValid = this.formRef.current.checkValidity() && obligationId !== 0;
            this.props.onInvalidate(!isValid);

            if(!isValid){
                state.invalidFields=[];
                if (obligationId === 0) {
                    state.invalidFields.push('obligationId');
                }
                if(obligationSectionId === 0) {
                    state.invalidFields.push('obligationSectionId');
                }
                event.detail.forEach((fieldName)=>{
                    if(state.formData[fieldName] !== undefined && state.formData[fieldName] === ""){
                        state.invalidFields.push(fieldName);
                    }
                })
                this.setState(state);
            }else{
                window.dispatchEvent(new Event(SAVE_CONTROL_LIBRARY_FORM));
            }
        }

    }

    onFormControlChange(event,fieldName){

        const state = this.state;

        let formValue = event?.target?.value;

        switch (fieldName) {
            case "obligationId":
                if(state.formData.obligationId!==event.value){
                    this.props.getObligationSectionFilter(event.value);
                }
                formValue = event.value;
                state.lastObligationId=formValue;
                break;
            case "obligationSectionId":
                formValue = event.value;
                state.lastObligationSectionId=formValue;
                break;
            case "customControl":
                formValue = event;
                break;
            default:
                fieldName = event?.target?.name;
                break;
        }

        state.formData[fieldName]= formValue;
        this.setState(state);
        this.onFormChangeHandler(state.formData);

        if(event?.preventDefault){
            event.preventDefault();
        }
    }

    onBlurFormControlHandler(event){
        const state = this.state;

        const target = event.currentTarget;
        if(target.required){
            if(target.value.length===0){
                if(!state.invalidFields.includes(target.id)){
                    state.invalidFields.push(target.id);
                }
            }else{
                if(state.invalidFields.includes(target.id)){
                    const filteredList = state.invalidFields.filter(value => value !== target.id);
                    state.invalidFields = filteredList;
                }
            }
        }

        this.setState(state);
    }

    onEditorChangeHandler(content, editor){
        const formData = this.state.formData;
        formData.description=content;
        this.setState({formData});
        this.onFormChangeHandler(formData);
    }

    onFormChangeHandler(event){
        this.props.onChange(event);
    }

    onTagCreatedHandler(event){
        const fieldName = event.id.split("-")[0];
        const tagRequest={
            entityName:"control-library",
            fieldName:fieldName,
            value:event.value
        }
        this.props.saveEntityTag(tagRequest);
    }

    onSelectorChangeHandler(event){
        const {formData} = this.state;
        formData.tags=event.value;
        this.setState({formData});
    }

    render(){
        const {name,customControl,contentSource,description,obligationId, obligationSectionId} = this.state.formData;
        const {customOptions,obligations,obligationSections} = this.state;
        const { obligationsFilterData, obligationSectionsData, obligationDetail,obligationSectionDetail} = this.props;

        return(  <Card>
                    <Card.Header>Add Control Library</Card.Header>
                    <Card.Body>
                        <Form onSubmit={(e)=>e.preventDefault()} ref={this.formRef}>
                            <Form.Group>
                                <Form.Label>Control Name*</Form.Label>
                                <Form.Control required type="text"
                                              placeholder="eg. FFIEC UBPR" id="name"
                                              name="name"
                                              defaultValue={name}
                                              onChange={this.onFormControlChange}
                                              onBlur={this.onBlurFormControlHandler}
                                              isInvalid={this.state.invalidFields.includes("name")}
                                />
                                <Form.Control.Feedback type="invalid">
                                    Please provide a name.
                                </Form.Control.Feedback>
                            </Form.Group>
                            <Form.Group>
                                <Form.Label>Type</Form.Label>
                                <RadioGroup
                                    inline
                                    defaultValue={customControl}
                                    options={customOptions}
                                    onChange={(e)=>this.onFormControlChange(e,"customControl")}
                                />
                            </Form.Group>
                            <Form.Group>
                                <Form.Label>Obligation*</Form.Label><br/>
                                {obligationDetail.id || obligationSectionDetail.id ?
                                    <FormValue>{obligationDetail.obligationName}{obligationSectionDetail.obligationName}</FormValue> :
                                    <FormSelector
                                        isInvalid={this.state.invalidFields.includes("obligationId")}
                                        name="obligationId"
                                        value={ArrayUtil.getItemByValue(obligationsFilterData,"value",obligationId)}
                                        classNamePrefix="select"
                                        isSearchable="true"
                                        options={obligations}
                                        onChange={(e)=>this.onFormControlChange(e,"obligationId")}
                                    />}
                                <Form.Control.Feedback type="invalid">
                                    Please provide an obligation.
                                </Form.Control.Feedback>
                            </Form.Group>
                            <Form.Group>
                                <Form.Label>Obligation Section*</Form.Label><br/>
                                {obligationSectionDetail.id ?
                                <FormValue>{obligationSectionDetail.name}</FormValue> :
                                <FormSelector
                                    id="editor"
                                    isInvalid={this.state.invalidFields.includes("obligationSectionId")}
                                    name="obligationSectionId"
                                    value={ArrayUtil.getItemByValue(obligationSectionsData,"value",obligationSectionId)}
                                    classNamePrefix="select"
                                    isSearchable="true"
                                    options={obligationSections}
                                    onChange={(e)=>this.onFormControlChange(e,"obligationSectionId")}
                                />}
                                <Form.Control.Feedback type="invalid">
                                    Please provide an obligation section.
                                </Form.Control.Feedback>
                            </Form.Group>
                              <Form.Group>
                                <Form.Label>Content Source*</Form.Label>
                                <Form.Control required type="text"
                                              placeholder="eg. FFIEC UBPR" id="contentSource"
                                              name="contentSource"
                                              defaultValue={contentSource}
                                              onChange={this.onFormControlChange}
                                              onBlur={this.onBlurFormControlHandler}
                                              isInvalid={this.state.invalidFields.includes("contentSource")}
                                />
                                <Form.Control.Feedback type="invalid">
                                    Please provide a Content Source.
                                </Form.Control.Feedback>
                            </Form.Group>
                            <Form.Group>
                                <Form.Label>Description*</Form.Label>
                                <FormEditor
                                    isInvalid={this.state.invalidFields.includes("description")}
                                    initialValue={description}
                                    onEditorChange={this.onEditorChangeHandler}/>
                                <Form.Control.Feedback type="invalid">
                                    Please provide a description.
                                </Form.Control.Feedback>
                            </Form.Group>
                        </Form>
                    </Card.Body>
                </Card>                    
            );
    }
}

const mapStateToProps = (state) =>{
    return({
        obligationsFilterData: state.searchFilter.obligationsFilterData,
        obligationSectionsData: state.searchFilter.obligationSectionsData,
        entityTagsData:state.searchFilter.entityTagsData,
        obligationDetail: state.grcLibrary.obligationDetail,
        obligationSectionDetail:state.grcLibrary.obligationSectionDetail
    })
}

export default connect(mapStateToProps,actions)(ControlLibrarySavePageForm);