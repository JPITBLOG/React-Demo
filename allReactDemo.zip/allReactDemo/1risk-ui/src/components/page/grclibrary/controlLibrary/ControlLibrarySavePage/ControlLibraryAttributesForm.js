import React, {Component} from "react";
import {Card, Form} from "react-bootstrap";
import FormTagSelector from "../../../../core/FormTagSelector";
import * as actions from "../../../../../actions/"
import {connect} from "react-redux";
import ArrayUtil from "../../../../../util/ArrayUtil";

class ControlLibraryAttributesForm extends Component {

    static defaultProps = {
        data: {
            id: 0
        },
        onChange: () => null
    }

    state = {
        tagsOptions: [],
        selectedTags: [],
        data: {
            id: 0
        }
    }

    constructor(props) {
        super(props);
        this.onSelectorChangeHandler = this.onSelectorChangeHandler.bind(this);
        this.onTagCreatedHandler = this.onTagCreatedHandler.bind(this);
    }

    componentDidMount() {
        this.props.getEntityTags("control-library", "tags");
    }

    componentDidUpdate(prevProps, prevState, snapshot) {

        if (prevProps.data !== this.props.data) {

            const { tags } = this.props.data;

            const state = this.state;
            state.data = this.props.data;

            state.selectedTags = ArrayUtil.parseToDropdownCollection(tags);
            this.setState(state);
        }

        if (prevProps.savedTagData !== this.props.savedTagData) {

            let { tags } = this.props.data;
            const state = this.state;

            const { fieldName, value } = this.props.savedTagData;
            switch (fieldName) {
                case "tags":
                    tags = ArrayUtil.addToCollection(tags, value);
                    state.selectedTags = ArrayUtil.parseToDropdownCollection(tags);
                    this.props.onChange({
                        fieldName: "tags",
                        value: this.state.selectedTags
                    })
                    break;
                default:
                    break;
            }

            this.setState(state);
        }

        if (prevProps.entityTagsData !== this.props.entityTagsData) {

            const state = this.state;

            const { entityTagsData } = this.props;
            const data = entityTagsData.map((item) => {
                return { label: item.value, value: item.value }
            });
            if (data.length > 0) {
                const fieldName = entityTagsData[0].fieldName;
                switch (fieldName) {
                    case "tags":
                        state.tagsOptions = data;
                        break;
                    default:
                        break;
                }
            }
            this.setState(state);
        }
    }

    onSelectorChangeHandler(event) {
        const fieldName = event.target.name;
        const state = this.state;
        state[`selectedTags`] = event.value;
        this.setState(state);
        this.props.onChange({
            fieldName: fieldName,
            value: event.value
        })
    }

    onTagCreatedHandler(event) {  
        const fieldName = event.id.split("-")[0];
        const tagRequest = {
            entityName: "control-library",
            fieldName: fieldName,
            value: event.value
        }
        this.props.saveEntityTag(tagRequest);
    }

    render() {
        const { tagsOptions, selectedTags } = this.state;
        return (
                <Card>
                    <Card.Header>Attribute</Card.Header>
                    <Card.Body>
                        <Form>
                            <Form.Group>
                                <Form.Label>Tags</Form.Label>
                            <FormTagSelector
                                name="tags"
                                options={tagsOptions}
                                onChange={this.onSelectorChangeHandler}
                                value={selectedTags}
                            />
                            </Form.Group>
                        </Form>
                    </Card.Body>
                </Card>
        );
    }
}

const mapStateToProps = (state) => {
    return ({
        entityTagsData: state.searchFilter.entityTagsData,
        savedTagData: state.searchFilter.savedTagData
    })
}

export default connect(mapStateToProps, actions)(ControlLibraryAttributesForm);
