import React, { Component } from 'react';
import { Col, Row, Tab, Tabs } from 'react-bootstrap';
import { connect } from 'react-redux'
import * as actions from '../../../../../actions';
import pageWrapper,{PAGE_TYPE_VIEW} from "../../../../core/pageWrapper";
import BrowserUtil from "../../../../../util/BrowserUtil";
import BreadcrumbUtil from "../../../../../util/BreadcrumbUtil";
import DetailPageHeader from "../../../../core/DetailPageHeader";
import ControlLibraryIcon from "../../../../core/icon/ControlLibraryIcon";
import CrosswalksTab from "../../crosswalk/CrosswalksTab";
import ControlLibraryDetailTab from "./ControlLibraryDetailTab";
import NotesTab from '../../notes/NotesTab';
import AttachmentTab from "../../../attachments/AttachmentTab";
import TopActionMenu from "../../../../core/TopActionMenu";
import PageUtil from "../../../../../util/PageUtil";
import {confirmAlert} from "react-confirm-alert";
import ConfirmWindow from "../../../../core/ConfirmWindow";
import ReactToPrint from "react-to-print";
import ReportWrapper from "../../../../core/reportWrapper";
import StringUtil from "../../../../../util/StringUtil";
import CommentTab from "../../../comment/CommentTab";
import HistoryTab from "../../../history/HistoryTab";

class ControlLibraryDetailsPage extends Component {

    state = {
        activeTab: "details",
        tabs: [
            "details",
            "crosswalks",
            "notes",
            "attachments",
            "comments",
            "history"
        ],
        controlDetail: {}
    }

    constructor(props) {
        super(props);
        this.populatePage = this.populatePage.bind(this);
        this.getObjectId = this.getObjectId.bind(this);
        this.onTabSelectHandler = this.onTabSelectHandler.bind(this);
        this.onCancelHandler = this.onCancelHandler.bind(this)
        this.onEditClickHandler = this.onEditClickHandler.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
    }

    getObjectId() {
        return this.props.controlDetail?.id
    }

    onTabSelectHandler(tabName) {
        this.setState({ activeTab: tabName });

        const url = `/grc-library/control-libraries/` + this.props.controlDetail.referenceId;

        if (tabName === "details") {
            this.props.history.push(url);
            this.loadTopMenuItems();
        } else {
            this.props.history.push(url + "/" + tabName);
        }
    }

    componentDidMount() {

        this.selectTabByUrl();
        BrowserUtil.scrollToTop();
        this.populatePage();
        this.loadTopMenuItems();
    }

    loadTopMenuItems() {

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Edit" icon="edit" onClick={this.onEditClickHandler} />,
            <TopActionMenu.ButtonMenuItem label="Delete" icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print Screen" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuItem disabled label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload Template" icon="upload" onClick={(e) => console.log(e)} />
        ], false);

    }

    populatePage() {
        this.pageUtil = new PageUtil(this.props);
        if (this.pageUtil.exists("id")) {
            const controlLibraryId = this.pageUtil.get("id");
            this.props.getControlById(controlLibraryId, (response, err) => {
                if (err) {
                    this.props.history.push("/grc-library/control-libraries");
                }
            });
        }
    }

    onDeleteHandler() {
        const { deleteControlLibrary, history } = this.props;

        const deleteRecord = () => {
            deleteControlLibrary(this.pageUtil.get("id"), (data, err) => {
                if (!err) {
                    history.push("/grc-library/control-libraries");
                }
            })
        }

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow onClose={onClose} onAction={deleteRecord} />
        });

    }

    selectTabByUrl() {
        const { tab } = this.props.match.params;
        const { tabs } = this.state;
        const selectedTab = tabs.filter((e) => e === tab);

        if(selectedTab.length>0){
            this.setState({activeTab:tab});
        }

        this.populateHeader(true);
    }


    componentDidUpdate(prevProps: Readonly<P>, prevState: Readonly<S>, snapshot: SS): void {
        if (prevProps.controlDetail !== this.props.controlDetail) {
            this.populateHeader(true);
        }

        if (this.props.match.params !== prevProps.match.params) {
            this.selectTabByUrl();
        }
    }

    populateHeader(init = false) {
        this.pageUtil = new PageUtil()
        const {internalId,referenceId} = this.props.controlDetail;
        const {activeTab} = this.state;
        if(internalId){
            let breadcrumb = BreadcrumbUtil.createRequest("Grc Library",internalId,true);
            if(activeTab!=="details"){
                const prev = breadcrumb;
                prev.uri = `/grc-library/control-libraries/${referenceId}`;
                breadcrumb = BreadcrumbUtil.createRequest("Grc Library",StringUtil.toTitleCase(activeTab),false,prev);
            } 
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_VIEW, "Control Library")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)                   
            this.props.onPageLoad(event);
        }

    }

    // setHeader(controlLibrary) {
    //
    //     const actionButtonList = [];
    //     actionButtonList.push(
    //         <Button className="bookmark-action" key={1} onClick={(e) => console.log(e)}>
    //             <FontAwesomeIcon icon={faPlus} /> Add to My Bookmarks
    //         </Button>);
    //
    //     const headerDetails = {
    //         title: controlLibrary.label,
    //         description: `${controlLibrary.contentSource} - ${controlLibrary.category}`,
    //         icon: <FontAwesomeIcon icon={faUniversity} />,
    //         actionButtons: actionButtonList,
    //         type: "controls-header"
    //     }
    //     this.props.populateDetailHeader(headerDetails);
    // }

    onEditClickHandler = (event) => {
        const {controlDetail} = this.props;
        this.props.history.push(`/grc-library/control-libraries/edit/${controlDetail?.referenceId}`);
        event.preventDefault();
    }

    onCancelHandler = (event) => {
        const redirectUrl = "/grc-library/control-libraries";
        this.props.history.push(redirectUrl);
        event.preventDefault();
    }

    render() {
        const { id,referenceId,contentSource, name, customControl } = this.props.controlDetail;
        const infoHeader = <span><b>Content Source</b> {contentSource}</span>;
        return (
            <div>
                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.contentRef}
                />
                <ReportWrapper entityName="Control Library" ref={el => (this.contentRef = el)}>
                    <section id="content-wrap" className="right-content-wrap">

                        <DetailPageHeader info={infoHeader} name={name} icon={<ControlLibraryIcon custom={customControl} />} />
                        <Row className="tab-wrap">
                            <Col lg={12}>
                                <Tabs mountOnEnter={true} unmountOnExit={true} activeKey={this.state.activeTab} onSelect={this.onTabSelectHandler}>
                                    <Tab eventKey="details" title="Details">
                                        <ControlLibraryDetailTab {...this.props} />
                                    </Tab>
                                    <Tab eventKey="crosswalks" title="Crosswalks">
                                        <CrosswalksTab objectName="control-library" objectId={id} objectReferenceId={referenceId} {...this.props} />
                                    </Tab>
                                    <Tab eventKey="notes" title="Notes">
                                        <NotesTab objectName="control-library" objectId={id} objectReferenceId={referenceId} {...this.props} />
                                    </Tab>
                                    <Tab eventKey="attachments" title="Attachments">
                                        <AttachmentTab objectName="control-library" objectId={id} objectReferenceId={referenceId} {...this.props} />
                                    </Tab>
                                    <Tab eventKey="comments" title="Comments">
                                        <CommentTab objectName="control-library" objectId={id} {...this.props}/>
                                    </Tab>
                                    <Tab eventKey="history" title="History">
                                        <HistoryTab objectName="control-library" objectId={id} {...this.props}/>
                                    </Tab>
                                </Tabs>
                            </Col>
                        </Row>
                    </section>
                </ReportWrapper>
            </div>);
    }
}

const mapStateToProps = (state) => {
    return ({
        controlDetail: state.grcLibrary.controlDetail,
        savedControlLibrary: state.grcLibrary.savedControlLibrary
    })
}

export default pageWrapper(connect(mapStateToProps, actions)(ControlLibraryDetailsPage));
