import React from 'react';
import MappedControlItem from "./itemrender/MappedControlItem";

function MappedControlItems({items=[], onTagClick=(e)=>console.log(e)}){

    if(items.length>0){
        return(<div>
            <div>
                <h5>Mapped Controls ({items.length})</h5>
                <ul className="content-items">
                    {items.map((item,index) =>{
                        return(<MappedControlItem key={index} item={item} onTagClick={onTagClick}/>)
                    })}
                </ul>
            </div>
        </div>);
    }

    return null;

}

export default (MappedControlItems)