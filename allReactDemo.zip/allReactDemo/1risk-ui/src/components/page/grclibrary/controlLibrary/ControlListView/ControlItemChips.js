import React from 'react'
import ControlItemChip from "./chip/ControlItemChip";
import MapControlItemChip from "./chip/MapControlItemChip";

function ControlItemChips({item={},light=false,onTagClick=(e)=>console.log(e)}){
    if(light){
        return(<div className="tages">
            <MapControlItemChip label={item.contentSource}/>
            {item.mapped.length >0 && <MapControlItemChip label={`${item.mapped.length} Mapped`}/>}
            {item.tags.map((tag,index)=>{
                return(<MapControlItemChip onClick={()=>onTagClick(tag)} key={`tag-chip-${index}`} label={tag}/>)
            })}
        </div>)
    }
    return(<div className="tages">
        <ControlItemChip label={item.contentSource}/>
        {item.mapped.length >0 && <ControlItemChip label={`${item.mapped.length} Mapped`}/>}
        {item.tags.map((tag,index)=>{
            return(<ControlItemChip onClick={()=>onTagClick(tag)} key={`tag-chip-${index}`} label={tag}/>)
        })}
    </div>)
}

export default (ControlItemChips)