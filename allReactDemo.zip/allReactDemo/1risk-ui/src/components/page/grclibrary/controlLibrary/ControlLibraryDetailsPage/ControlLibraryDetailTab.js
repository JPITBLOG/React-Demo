import React from 'react';
import { Card, Col, Row } from "react-bootstrap";
import EntityInfoWidget from "../../../../core/EntityInfoWidget";
import AttributesContainer from "../../../../core/AttributesContainer";
import EntityUtil from "../../../../../util/EntityUtil";
import { useSelector } from "react-redux";
import ReadMoreText from "../../../../core/ReadMoreText";
import NavUnderlineLink from '../../../../core/NavUnderlineLink';

const ControlLibraryDetailTab = (props) => {

    const controlDetail = useSelector(state => state.grcLibrary.controlDetail);

    const getAttributes = () => {

        if (controlDetail.id === undefined) {
            return [];
        }

        const entity = new EntityUtil(controlDetail);

        const attributes = [
            {
                title: "Tags",
                content: entity.getArray("tags"),
                type: "chip"
            }
        ];

        return attributes;
    }

    const { description, createdAt, updatedAt, ownerName, internalId, obligationName, obligationSectionName, contentSource, obligationReferenceId, obligationSectionReferenceId } = controlDetail;

    return (<div className="detail-page-container">
        <Row>
            <Col lg={8} className="left-col">
                <div className="content-widget">
                    <Card className="card-section">
                        <Card.Body>
                            <Card.Title>Description</Card.Title>
                            <ReadMoreText text={description} minHeight={'170px'} />

                            <div className="control-library-obligation-attribute">
                                <section className="control-library-section">
                                    <Card.Title>
                                        Obligation
                                </Card.Title>
                                    <Card.Text>
                                        <NavUnderlineLink target="_blank" to={`/grc-library/obligations/${obligationReferenceId}`}>{obligationName}</NavUnderlineLink>
                                    </Card.Text>
                                </section>
                                <section className="control-library-section">
                                    <Card.Title>
                                        Content Source
                                </Card.Title>
                                    <Card.Text>{contentSource}</Card.Text>
                                </section>
                            </div>
                            <section>
                                <Card.Title>
                                    Obligation Section
                                </Card.Title>
                                <Card.Text>
                                    <NavUnderlineLink target="_blank" to={`/grc-library/obligation-sections/${obligationSectionReferenceId}`}>{obligationSectionName}</NavUnderlineLink>
                                </Card.Text>
                            </section>
                        </Card.Body>
                    </Card>
                </div>
            </Col>
            <Col lg={4} className="right-col">
                <EntityInfoWidget createdAt={createdAt} updatedAt={updatedAt} ownerName={ownerName} recordId={internalId} />
                <AttributesContainer attributes={getAttributes()} />
            </Col>
        </Row>
    </div>);

}

export default (ControlLibraryDetailTab);