import React from 'react'
import ControlListItemLabel from "../ControlListItemLabel";
import ControlItemChips from "../ControlItemChips";

function MappedControlItem({item={},onTagClick=(e)=>console.log(e)}){

    const baseUrl="/grc-library/control-libraries/";

    return(<li>
        <ControlListItemLabel url={`${baseUrl}${item.id}`} custom={item.custom} label={item.label}/>
        <ControlItemChips item={item} light={true} onTagClick={onTagClick}/>
        <p>{item.description}</p>
    </li>);
}

export default (MappedControlItem);