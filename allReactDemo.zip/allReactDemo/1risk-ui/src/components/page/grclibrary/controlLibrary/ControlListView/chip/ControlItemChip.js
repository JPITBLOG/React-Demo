import withStyles from "@material-ui/core/styles/withStyles";
import {Chip} from "@material-ui/core";

const ControlItemChip = withStyles({
    root: {
        backgroundColor:"##F5F5F5",
        background: "#F5F5F5 0% 0% no-repeat padding-box",
        borderRadius: "5px",
        opacity: "1",
        padding: "5px",
        fontFamily: "Lato, sans-serif",
        marginRight: "10px"
    },
    deleteIcon:{
        color: "#494A4C"
    },
    label:{
        textAlign: "left",
        font: "14px/17px Lato",
        letterSpacing: "0",
        color: "#494A4C",
        opacity: "1"
    }
})(Chip);

export default (ControlItemChip)