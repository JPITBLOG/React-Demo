import React from 'react';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faUniversity,faLeaf} from "@fortawesome/free-solid-svg-icons";
import {NavLink} from "react-router-dom";

function ControlListItemLabel(props){
    return(
        <h4>
            <NavLink to={props.url}>
                <FontAwesomeIcon fixedWidth icon={props.custom ? faLeaf:faUniversity}/>&nbsp;&nbsp;
                {props.label}
            </NavLink>
        </h4>
    );
}

export default (ControlListItemLabel);