import React from "react";
import {Col, Row} from "react-bootstrap";
import {connect, useSelector} from "react-redux";
import EntityInfoWidget from "../../../../core/EntityInfoWidget";
import AttributesContainer from "../../../../core/AttributesContainer";
import EntityUtil from "../../../../../util/EntityUtil";
import * as actions from "../../../../../actions";
import CrosswalkContentWidget from "../CrosswalkContentWidget";

const CrosswalkDetailTab = () => {

    const crosswalkDetail = useSelector(state => state.grcLibrary.crosswalkDetail)
    const { createdAt, updatedAt, ownerName } = crosswalkDetail;


    const getAttributes = () => {

        if (crosswalkDetail.id === undefined) {
            return [];
        }

        const entity = new EntityUtil(crosswalkDetail);

        const attributes = [
            {
                title: "Tags",
                content: entity.getArray("tags"),
                type: "chip"
            }
        ];
        return attributes;
    }

    return (<div className="detail-page-container">
        <Row>
            <Col lg={8} className="left-col">
                <CrosswalkContentWidget controlLibrary={crosswalkDetail.controlLibrary}/>
                <CrosswalkContentWidget controlLibrary={crosswalkDetail.relatedControlLibrary} related/>
            </Col>
            <Col lg={4} className="right-col">
                <EntityInfoWidget createdAt={createdAt} updatedAt={updatedAt} ownerName={ownerName} />
                <AttributesContainer attributes={getAttributes()} />
            </Col>
        </Row>
    </div>)
}

export default connect(null, actions)(CrosswalkDetailTab);