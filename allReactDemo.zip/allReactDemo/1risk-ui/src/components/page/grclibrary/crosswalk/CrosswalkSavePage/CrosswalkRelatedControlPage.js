import React, { Component } from 'react';
import * as actions from "../../../../../actions"
import { connect } from "react-redux";
import withEventBus from "../../../../core/withEventBus";
import TableView, { RESET_SELECTED_ITEMS } from "../../../../core/TableView";
import CrosswalkSearchTab from "../CrosswalkSearchTab";
import UUIDUtil from '../../../../../util/UUIDUtil';
import ActionOverlay from '../../../../core/ActionOverlay';
import { Button } from "react-bootstrap";
import PaginationUtil from "../../../../../util/PaginationUtil";
import IconButton from "../../../../core/button/IconButton";
import ControlLibraryIcon from "../../../../core/icon/ControlLibraryIcon";
import PropTypes from "prop-types";

class CrosswalkRelatedControlPage extends Component {

    static propTypes = {
        objectId: PropTypes.number,
        objectName: PropTypes.string,
        objectReferenceId: PropTypes.string
    }

    static defaultProps = {
        objectId: 0,
        objectName: "",
        objectReferenceId: ""
    }

    componentDidMount() {
        this.executeSearch();
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if(prevProps.objectId!==this.props.objectId){
            console.log(this.props.objectId);
            this.executeSearch();
        }
    }

    constructor(props) {
        super(props);
        this.state = {
            pagination: null,
            selectedItems: [],
            tableViewName: UUIDUtil.v4(),
            filters: PaginationUtil.initFilters(["obligation", "tag", "type", "status", "owner"]),
            obligationId: 0
        }
        this.onTableViewChangeHandler = this.onTableViewChangeHandler.bind(this);
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onFilterChangeHandler = this.onFilterChangeHandler.bind(this);
        this.onResetFiltersHandler = this.onResetFiltersHandler.bind(this);
        this.updateFilter = this.updateFilter.bind(this);
        this.onClearSelected = this.onClearSelected.bind(this);
    }

    getColumns() {
        const columns = [
            {
                name: "ID",
                fieldName: "internalId",
                url: "/grc-library/control-libraries/{referenceId}"
            },
            {
                name: "Control Library",
                fieldName: "name",
                icon: {
                    trueIcon: <ControlLibraryIcon custom />,
                    falseIcon: <ControlLibraryIcon />,
                    fieldName: "customControl"
                },
                contentType: "iconLabel"
            },
            {
                name: "Content Source",
                fieldName: "contentSource",
            },
            {
                name: "Related Control Library",
                fieldName: "contentSource",
            },
            {
                name: "Related Content Source",
                fieldName: "obligationName",
            }
        ]
        return columns;
    }

    onTableViewChangeHandler(event) {
        const state = this.state;
        state.pagination = event;
        this.setState(state);
        this.executeSearch()
    }

    onSearchTypeHandler(event) {
        this.updateFilter(event);
        this.executeSearch();
    }

    executeSearch() {

        const { filters, pagination } = this.state;

        PaginationUtil.prepareFilters(filters);
        const activeFilters = PaginationUtil.getActiveFilters(filters);

        console.log(activeFilters);

        if (activeFilters.length > 0) {
            this.props.getControlsData(activeFilters, pagination);
        } else {
            this.props.getControlsData(null, pagination);
        }
    }

    updateFilter(selectedFilter) {
        const state = this.state;
        let filterUpdated = false;
        state.filters.forEach((filter, index) => {
            if (filter.name === selectedFilter.name) {
                state.filters[index].value = selectedFilter.value;
                filterUpdated = true;
            }
        });
        if (!filterUpdated) {
            state.filters.push(selectedFilter);
        }
        this.setState(state);
    }

    onFilterChangeHandler(event) {
        if (PaginationUtil.isFilterChanged(event, this.state)) {
            this.updateFilter(event);
            this.executeSearch();
        }
    }

    onResetFiltersHandler(event) {
        const { pagination } = this.state;
        this.setState({ filters: [] });
        this.props.getControlsData(null, pagination);
    }

    onClearSelected() {
        this.setState({ selectedItems: [] });
        this.props.eventBus.dispatch(RESET_SELECTED_ITEMS, { name: this.state.tableViewName })
    }

    render() {
        console.log(this.props);
        const { items, totalRecords } = this.props.controlsPage;
        const { selectedItems, tableViewName } = this.state;
        const { selectedControl, onSelect } = this.props;
        
        let itemList = [];
        itemList = items.filter((item) => {
            return selectedControl && selectedControl[0].referenceId !== item.referenceId
        });

        return (
            <div className="controls-tab" ref={this.myRef}>
                <div id="Controls" className="single-content active">

                    <ActionOverlay visible={true}>
                        <ActionOverlay.Actions>
                            <IconButton onClick={this.props.onSave} icon="plus">Add Crosswalk</IconButton>
                            <Button onClick={this.props.onCancelHandler} variant="secondary">Cancel</Button>
                        </ActionOverlay.Actions>
                    </ActionOverlay>

                    <ActionOverlay.SecondaryActions>
                        <div className="selected-info">{selectedItems && selectedItems.length} selected</div>
                        <Button variant="link" onClick={this.onClearSelected}>Clear All</Button>
                    </ActionOverlay.SecondaryActions>

                    <CrosswalkSearchTab showObligationFilter={this.state.obligationId === 0}
                        onFilterChange={this.onFilterChangeHandler}
                        onSearchType={this.onSearchTypeHandler}
                        onResetFilters={this.onResetFiltersHandler}
                        showButton={false}
                    />
                    <TableView
                        name={tableViewName}
                        className="control-library-table"
                        totalItems={totalRecords}
                        items={itemList}
                        columns={this.getColumns()}
                        onPageChange={this.onTableViewChangeHandler}
                        onOrderChange={this.onTableViewChangeHandler}
                        onSelectItem={onSelect}
                        actions={[]}
                        selectedControlId={selectedControl}
                    />
                </div>
            </div>);
    }
}

function mapStateToProps(state) {
    return {
        controlsPage: state.grcLibrary.controlsPage
    }
}

export default withEventBus(connect(mapStateToProps, actions)(CrosswalkRelatedControlPage));