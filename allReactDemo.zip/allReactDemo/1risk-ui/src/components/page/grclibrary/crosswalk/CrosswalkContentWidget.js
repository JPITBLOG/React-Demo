import React from "react";
import {Card} from "react-bootstrap";
import ControlLibraryIcon from "../../../core/icon/ControlLibraryIcon";
import ReadMoreText from "../../../core/ReadMoreText";
import NavUnderlineLink from "../../../core/NavUnderlineLink";

const CrosswalkContentWidget = ({controlLibrary, related=false}) => {

    const headerText = related ? "Related Control Library" : "Control Library";

    if(controlLibrary=== undefined){
        controlLibrary={
            referenceId:"",
            internalId:"",
            customControl:false,
            name: "",
            contentSource: ""
        }
    }


    const {referenceId,internalId,customControl,name,contentSource,obligationName,description,obligationReferenceId,obligationSectionReferenceId,obligationSectionName} = controlLibrary;

    return(<div className="content-widget">
        <Card>
            <Card.Header>{headerText}</Card.Header>
            <Card.Body>
                <div className="crosswald-obligation-description">
                    <section className="crosswalk-section">
                        <Card.Title>ID</Card.Title>
                        <Card.Text>
                            <NavUnderlineLink target="_blank" to={`/grc-library/control-libraries/${referenceId}`}>{internalId}</NavUnderlineLink>
                        </Card.Text>
                    </section>
                    <section className="crosswalk-section">
                        <Card.Title>
                            Content Source
                    </Card.Title>
                        <Card.Text>{contentSource}</Card.Text>
                    </section>
                </div>
                <section>
                    <Card.Title>Control Name</Card.Title>
                    <Card.Text>
                        <span><ControlLibraryIcon custom={customControl}/></span>  
                        <span>{name}</span>
                    </Card.Text>
                </section>
                <section>
                    <Card.Title>
                        Description
                    </Card.Title>
                    <div>
                        <ReadMoreText text={description} minHeight={'87px'}/>
                    </div>
                </section>
                <div className="crosswald-obligation-description">
                    <section className="crosswalk-section">
                        <Card.Title>
                            Obligation
                        </Card.Title>
                        <Card.Text>
                            <NavUnderlineLink target="_blank" to={`/grc-library/obligations/${obligationReferenceId}`}>{obligationName}</NavUnderlineLink>
                        </Card.Text>
                    </section>
                    <section className="crosswalk-section">
                        <Card.Title>
                            Obligation Section
                    </Card.Title>
                        <Card.Text>
                            <NavUnderlineLink target="_blank" to={`/grc-library/obligation-sections/${obligationSectionReferenceId}`}>{obligationSectionName}</NavUnderlineLink>
                        </Card.Text>
                    </section>
                </div>
            </Card.Body>
        </Card>
    </div>);
}

export default (CrosswalkContentWidget);