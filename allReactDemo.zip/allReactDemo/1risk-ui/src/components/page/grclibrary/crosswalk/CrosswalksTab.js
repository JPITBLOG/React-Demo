import React, { Component } from 'react';
import * as actions from "../../../../actions"
import { connect } from "react-redux";

import './CrosswalksTab.css';
import UUIDUtil from '../../../../util/UUIDUtil';
import PaginationUtil from "../../../../util/PaginationUtil";
import ControlLibraryIcon from "../../../core/icon/ControlLibraryIcon";
import PropTypes from "prop-types";
import TabUtil from "../../../../util/TabUtil";
import TopActionMenu from "../../../core/TopActionMenu";
import ObjectUtil from "../../../../util/ObjectUtil";
import ExportUtil from "../../../../util/ExportUtil";
import ReactToPrint from "react-to-print";
import ReportWrapper from "../../../core/reportWrapper";
import ConfirmWindow from "../../../core/ConfirmWindow";

import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css

import DataTableUtil from "../../../../util/DataTableUtil";
import DateUtil from "../../../../util/DateUtil";
import StringUtil from "../../../../util/StringUtil";
import DataTableIDLink from "../../../core/DataTable/DataTableIDLink";
import DataTable from "../../../core/DataTable";
import SearchOnTypeV2 from "../../../core/SearchOnTypeV2";
import DataTableDescriptionField from "../../../core/DataTable/DataTableDescriptionField";

class CrosswalksTab extends Component {

    static defaultProps = {
        objectId: 0,
        objectName: "",
    }

    static propTypes = {
        objectId: PropTypes.number,
        objectName: PropTypes.string
    }

    constructor(props) {
        super(props);
        this.state = {
            tableViewName: UUIDUtil.v4(),
            selectedItems: [],
            prevSelectedItems: [],
            obligationId: 0,
            objectHash: "",
            pagination: PaginationUtil.generatePaginationRequest(0, 50),
            lastPagination: "",
            filters: [],
            lastFilters: [],
            editMode: false,
            searchOnTypeValue: "",
            searchLoading: false,
            isPrinting: false,
        }
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onFilterChangeHandler = this.onFilterChangeHandler.bind(this);
        this.onResetFiltersHandler = this.onResetFiltersHandler.bind(this);
        this.updateFilter = this.updateFilter.bind(this);
        this.onSelectedHandler = this.onSelectedHandler.bind(this);
        this.onClearSelected = this.onClearSelected.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onExportHandler = this.onExportHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.tabUtil = new TabUtil(this);

    }

    componentDidMount() {
        this.props.getCrosswalkTableFilters();
        this.tabUtil.loadSubTabFilter();
        this.loadTopMenuItems();
        const { objectName, objectReferenceId } = this.props;
        if (objectReferenceId !== "" && objectName !== "") {
            const state = this.state;
            state.objectHash = ObjectUtil.hashRef(objectName, objectReferenceId);
            this.setState(state);
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.objectId !== this.props.objectId) {
            this.tabUtil.loadSubTabFilter();
        }

        const { prevSelectedItems, selectedItems } = this.state;

        if (prevSelectedItems.length !== selectedItems.length) {
            this.loadTopMenuItems();
            this.setState({ prevSelectedItems: ObjectUtil.clone(selectedItems) });
        }

        const self = this;
        PaginationUtil.searchWithFilter(this.state,state=>{
            self.setState(state);
            self.executeSearch()
        });

    }
    getColumns() {

        const isOpenTab = (this.props.objectId !== 0 && this.props.objectId !== undefined);

        return [
            {
                label: "HiddenRefId",
                name: "referenceId",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "ID",
                name: "internalId",
                options: {
                    filter: false,
                    sort: true,
                    display: true,
                    customBodyRender: (value, tableMeta) =>
                        <DataTableIDLink newTab={isOpenTab}
                                         value={value}
                                         tableMeta={tableMeta}
                                         uri="/grc-library/crosswalks"
                        />
                }
            },
            {
                label: "Control Library",
                name: "controlLibrary.name",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                    customBodyRender: (value, tableMeta) => <ControlLibraryIcon customIdx={3} value={value} tableMeta={tableMeta} />
                }
            },
            {
                label: "Custom Control",
                name: "controlLibrary.customControl",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "Description",
                name: "controlLibrary.description",
                options: {
                    sort: true,
                    display: false,
                    filter: false,
                    customBodyRender: (value) => <DataTableDescriptionField value={value}/>
                }
            },
            {
                label: "Content Source",
                name: "controlLibrary.contentSource",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                },
            },
            {
                label: "Obligation",
                name: "controlLibrary.obligationName",
                options: {
                    sort: true,
                    display: true,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.obligationNames)
                },
            },
            {
                label: "Obligation Section",
                name: "controlLibrary.obligationSectionName",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.obligationSectionNames)
                },
            },
            {
                label: "Related Control Name",
                name: "relatedControlLibrary.name",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                    customBodyRender: (value, tableMeta) => <ControlLibraryIcon customIdx={9} value={value} tableMeta={tableMeta} />
                }
            },
            {
                label: "Related Custom Control",
                name: "relatedControlLibrary.customControl",
                filter: false,
                options: {
                    display: "excluded",
                    filter: false
                }
            },
            {
                label: "Related Description",
                name: "relatedControlLibrary.description",
                options: {
                    sort: true,
                    display: false,
                    filter: false,
                    customBodyRender: (value) => <DataTableDescriptionField value={value}/>
                }
            },
            {
                label: "Related Content Source",
                name: "relatedControlLibrary.contentSource",
                options: {
                    sort: true,
                    display: true,
                    filter: false,
                },
            },
            {
                label: "Related Obligation",
                name: "relatedControlLibrary.obligationName",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.relatedObligationNames)
                },
            },
            {
                label: "Related Obligation Section",
                name: "relatedControlLibrary.obligationSectionName",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.relatedObligationSectionNames)
                },
            },
            {
                label: "Tags",
                name: "tags",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    customBodyRender: (value) => StringUtil.join(value, ", "),
                    filterOptions: this.props.tableFilters?.tags?.map((item) => item.label)
                }
            },
            {
                label: "Owner",
                name: "ownerName",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.owners)
                }
            },
            {
                label: "Created Date",
                name: "createdAt",
                options: {
                    filter: true,
                    sort: true,
                    display: false,
                    customBodyRender: (value) => DateUtil.format(value),
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdDates)
                }
            },
            {
                label: "Created By",
                name: "createdBy",
                options: {
                    filter: true,
                    sort: true,
                    display: false,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.createdBys)
                }
            },
            {
                label: "Last Modified Date",
                name: "updatedAt",
                options: {
                    filter: true,
                    sort: true,
                    display: true,
                    customBodyRender: (value) => DateUtil.format(value),
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedDates)
                }
            },
            {
                label: "Last Modified By",
                name: "updatedBy",
                options: {
                    sort: true,
                    display: false,
                    filter: true,
                    filterType: "custom",
                    filterOptions: DataTableUtil.generateFilterOptions(this.props.tableFilters?.lastModifiedBys)
                }
            }
        ]
    }

    loadTopMenuItems() {

        const { selectedItems } = this.state;
        const isSectionEnabled = selectedItems.length < 1;
        const deleteLabel = isSectionEnabled ? "Delete" : `Delete (${selectedItems.length} selected)`;

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Add New" icon="plus" onClick={this.onAddClickHandler} />,
            <TopActionMenu.ButtonMenuItem disabled={isSectionEnabled} label={deleteLabel} icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload" icon="upload" onClick={(e) => console.log(e)} />
        ], false);

    }
    onDeleteHandler() {

        const { deleteCrosswalks } = this.props;
        const { selectedItems } = this.state;
        const self = this;

        const deleteRecord = () => {
            const idsToDelete = self.state.selectedItems.map((item) => item.referenceId);
            deleteCrosswalks(idsToDelete, (data, err) => {
                if (!err) {
                    self.onClearSelected();
                    self.executeSearch();
                }
            })
        }


        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow selectedItems={selectedItems.length} onClose={onClose} onAction={deleteRecord}/>
        });

    }

    onExportHandler() {
        const { items } = this.props.crosswalkPage;
        const { selectedItems } = this.state;
        ExportUtil.generateCsv(this.getColumns(), (selectedItems.length > 0 ? selectedItems : items), "crosswalk");
    }

    onSearchTypeHandler(event) {
        this.updateFilter(event);
    }

    executeSearch() {

        this.setState({ searchLoading: true });

        const { filters, pagination } = this.state;

        PaginationUtil.prepareFilters(filters, this.props.objectName, this.props.objectId);
        const activeFilters = PaginationUtil.getActiveFilters(filters);

        this.props.getCrosswalksData(activeFilters, pagination, () => this.setState({ searchLoading: false }));
    }

    updateFilter(selectedFilter) {
        const state = this.state;
        let filterUpdated = false;
        state.filters.forEach((filter, index) => {
            if (filter.name === selectedFilter.name) {
                state.filters[index].value = selectedFilter.value;
                filterUpdated = true;
            }
        });
        if (!filterUpdated) {
            state.filters.push(selectedFilter);
        }
        this.setState(state);
    }

    onFilterChangeHandler(event) {
        if (PaginationUtil.isFilterChanged(event, this.state)) {
            this.updateFilter(event);
            this.executeSearch();
        }
        this.props.resetSaveCrosswalk();
    }

    onResetFiltersHandler(event) {
        const { pagination } = this.state;
        this.setState({ filters: [] });
        this.props.getCrosswalksData(null, pagination);
    }

    onSelectedHandler(item) {
        this.setState({ selectedItems: item });
    }

    onClearSelected() {
        this.setState({ selectedItems: [] });
    }

    onAddClickHandler() {

        let addNewUrl = "/grc-library/crosswalks/new";
        if (this.state.objectHash) {
            addNewUrl += "/" + this.state.objectHash;
        }

        this.props.history.push(addNewUrl);

    }

    render() {
        const { searchOnTypeValue, searchLoading, isPrinting } = this.state

        return (<div className="crosswalk-tab">
            <div className="single-content active">

                <div className="filter-form">
                    <SearchOnTypeV2 defaultValue={searchOnTypeValue} onChange={this.onSearchTypeHandler} />
                </div>

                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.tableRef}
                    onBeforeGetContent={() => this.setState({ isPrinting: true })}
                    onAfterPrint={() => this.setState({ isPrinting: false })}
                />

                <ReportWrapper entityName="Crosswalk" ref={el => (this.tableRef = el)} className="tab-container">
                    <DataTable
                        page={this.props.crosswalkPage}
                        loading={searchLoading}
                        columns={this.getColumns()}
                        isPrinting={isPrinting}
                        onPaginationChange={(e) => this.setState({ pagination: e })}
                        onFilterChange={(e) => this.setState({ filters: e })}
                        onSelected={this.onSelectedHandler}
                        title="Crosswalks" />
                </ReportWrapper>
            </div>
        </div>)
    }
}

const mapStateToProps = (state) => {
    return ({
        crosswalkPage: state.grcLibrary.crosswalkPage,
        obligationDetail: state.grcLibrary.obligationDetail,
        controlDetail: state.grcLibrary.controlDetail,
        savedCrosswalk: state.grcLibrary.savedCrosswalk,
        tableFilters: state.grcLibrary.crosswalkTableFilters
    })
}

export default connect(mapStateToProps, actions)(CrosswalksTab);
