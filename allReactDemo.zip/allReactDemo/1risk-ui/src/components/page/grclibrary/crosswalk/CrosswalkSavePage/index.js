import React, { Component } from "react";
import pageWrapper,{PAGE_TYPE_ADD} from "../../../../core/pageWrapper";
import * as actions from "../../../../../actions"
import { connect } from "react-redux";
import { Col, Row, Tab, Tabs } from "react-bootstrap";
import CrosswalkControlLibraryPage from "./CrosswalkControlLibraryPage";
import CrosswalkRelatedControlPage from "./CrosswalkRelatedControlPage";
import BrowserUtil from "../../../../../util/BrowserUtil";
import BreadcrumbUtil from "../../../../../util/BreadcrumbUtil";
import Alert from 'react-bootstrap/Alert'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faExclamationCircle } from "@fortawesome/free-solid-svg-icons";

import '../CrosswalksTab.css';
import PageUtil from "../../../../../util/PageUtil";
import ObjectUtil from "../../../../../util/ObjectUtil";
class CrosswalkSavePage extends Component {

    state = {
        activeTab: "crosswalks-control-library",
        crosswalkDetail: {},
        selectedControlId: [],
        selectedRelatedIds: [],
        alertMessage: " Select control library to map and click Next",
        objectName:"",
        objectId:0,
        objectHash:""
    };

    constructor(props) {
        super(props);
        this.onSelectControlIdHandler = this.onSelectControlIdHandler.bind(this);
        this.onSelectRelatedIdHandler = this.onSelectRelatedIdHandler.bind(this);
        this.onNextClickHandler = this.onNextClickHandler.bind(this);
        this.onSaveClickHandler = this.onSaveClickHandler.bind(this);
        this.onCancelHandler = this.onCancelHandler.bind(this);
    }

    componentDidMount() {

        const pageUtil = new PageUtil();
        this.props.getControlsData();
        BrowserUtil.scrollToTop();
        const breadcrumb = { "title": "Grc Library", "label": "Add New", "init": false };
        const pageDescription = pageUtil.generatePageDescriptionRequest(PAGE_TYPE_ADD, "Crosswalks")
        const event = pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
        this.props.onPageLoad(event);
        const state = this.state;
        this.setState(state);
        this.pageUtil = new PageUtil(this.props);

        if(this.pageUtil.exists("objectHash")){
            const state = this.state;
            state.objectHash = this.pageUtil.get("objectHash");
            const objectInfo = ObjectUtil.parseHashRef(state.objectHash);
            state.objectName = objectInfo.name;
            if(objectInfo.name==="obligation"){
                this.props.getObligationById(objectInfo.id);
            }
            if(objectInfo.name==="obligation-section"){
                this.props.getObligationSectionsById(objectInfo.id);
            }
            if(objectInfo.name==="control-library"){
                this.props.getControlById(objectInfo.id);
            }
            this.setState(state);
        }

        this.props.getControlLibraryType();
        this.props.getControlLibraryStatus();
        this.props.getUsersFilter();
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        const pageUtil = new PageUtil();
        if (prevProps.crosswalkDetail !== this.props.crosswalkDetail) {
            const { internalId } = this.props.crosswalkDetail;
            const breadcrumb = BreadcrumbUtil.createRequest("Crosswalks", internalId);
            const event = pageUtil.generatePageLoadRequest(breadcrumb)
            this.props.onPageLoad(event);
            this.setState({ crosswalkDetail: this.props.crosswalkDetail });
        }

        if(prevProps.controlDetail!==this.props.controlDetail){
            const {id,referenceId} = this.props.controlDetail;
            this.setState({objectId:this.props.controlDetail.id});
            if (id !== undefined) {
                this.setState({ selectedControlId: [this.props.controlDetail] });
                this.setState({
                    activeTab: 'crosswalks-related-control-library',
                    alertMessage: " Select one or more related control libraries and click Add Crosswalk "
                });
                this.setState({
                    objectId:id,
                    objectReferenceId: referenceId
                });
                this.props.history.push(`/grc-library/crosswalks/new/crosswalks-related-control-library`);
            }
        }

        if(prevProps.obligationDetail!==this.props.obligationDetail){
            this.setState({objectId:this.props.obligationDetail.id});
        }

        if(prevProps.obligationSectionDetail!==this.props.obligationSectionDetail){
            this.setState({objectId:this.props.obligationSectionDetail.id})
        }

    }

    onSelectControlIdHandler(selectedItem) {
        this.setState({ selectedControlId: selectedItem });
    }

    onSelectRelatedIdHandler(selectedItem) {
        this.setState({ selectedRelatedIds: selectedItem });
    }

    onNextClickHandler() {
        BrowserUtil.scrollToTop();
        this.setState({
            activeTab: 'crosswalks-related-control-library',
            alertMessage: " Select one or more related control libraries and click Add Crosswalk "
        });
        this.props.history.push(`/grc-library/crosswalks/new/crosswalks-related-control-library`);
    }

    onCancelHandler(event) {
        this.props.resetSaveControlDetail();
        this.props.history.push("/grc-library/crosswalks");
        event.preventDefault();
    }

    onSaveClickHandler() {
        this.props.resetSaveControlDetail();
        const { selectedControlId, selectedRelatedIds,objectHash } = this.state;
        const relatedId = [];
        selectedRelatedIds.map(relatedControl => {
            return relatedId.push(relatedControl.id)
        })
        const crosswalkData = {
            "controlLibraryId": selectedControlId[0].id,
            "referenceIds": relatedId,
            id: 0
        };
        this.props.saveCrosswalk(crosswalkData, (res) => {
            if (res) {
                if(objectHash){
                    this.props.history.go(-2);
                }else{
                    this.props.history.push('/grc-library/crosswalks');
                }

            }
            else {
                console.log("error");
            }
        })
    }

    render() {
        const { activeTab, alertMessage, selectedControlId,objectName,objectId, objectReferenceId } = this.state;
        return (<section id="content-wrap" className="right-content-wrap">
            <Row className="tab-wrap">
                <Col lg={12}>
                    <Alert className="custom-alert">
                        <FontAwesomeIcon color="#FE9023" icon={faExclamationCircle} />
                        {alertMessage}</Alert>
                    <Tabs mountOnEnter={true} unmountOnExit={true} activeKey={activeTab}>
                        <Tab key={`grclibrary-tab-${0}`} eventKey="crosswalks-control-library" title="Step 1: Control Libraries">
                            <CrosswalkControlLibraryPage
                                onSelect={this.onSelectControlIdHandler}
                                onNextHandler={this.onNextClickHandler}
                                onCancelHandler={this.onCancelHandler}
                                objectName={objectName} objectId={objectId} objectReferenceId={objectReferenceId}
                            />
                        </Tab>
                        <Tab disabled={selectedControlId.length===0} key={`grclibrary-tab-${1}`} eventKey="crosswalks-related-control-library" title="Step 2: Related Control Library">
                            <CrosswalkRelatedControlPage
                                onSelect={this.onSelectRelatedIdHandler}
                                selectedControl={selectedControlId}
                                onSave={this.onSaveClickHandler}
                                onCancelHandler={this.onCancelHandler}
                                objectName={objectName} objectId={objectId} objectReferenceId={objectReferenceId}
                            />
                        </Tab>
                    </Tabs>
                </Col>
            </Row>
        </section >)
    }
}

const mapStateToProps = (state) => {
    return ({
        obligationDetail: state.grcLibrary.obligationDetail,
        obligationSectionDetail:state.grcLibrary.obligationSectionDetail,
        crosswalkDetail: state.grcLibrary.crosswalkDetail,
        controlDetail: state.grcLibrary.controlDetail
    })
}


export default pageWrapper(connect(mapStateToProps, actions)(CrosswalkSavePage));