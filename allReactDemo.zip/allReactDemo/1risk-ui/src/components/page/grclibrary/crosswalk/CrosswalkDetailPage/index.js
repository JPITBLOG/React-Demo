import React, { Component } from "react";
import pageWrapper, { PAGE_TYPE_VIEW } from "../../../../core/pageWrapper";
import * as actions from "../../../../../actions"
import { connect } from "react-redux";
import DetailPageHeader from "../../../../core/DetailPageHeader";
import { Col, Row, Tab, Tabs } from "react-bootstrap";
import CrosswalkDetailTab from "./CrosswalkDetailTab";
import NotesTab from '../../notes/NotesTab';
import BrowserUtil from "../../../../../util/BrowserUtil";
import AttachmentTab from "../../../attachments/AttachmentTab";
import PageUtil from "../../../../../util/PageUtil";
import TopActionMenu from "../../../../core/TopActionMenu";
import { confirmAlert } from "react-confirm-alert";
import ConfirmWindow from "../../../../core/ConfirmWindow";
import ReactToPrint from "react-to-print";
import ReportWrapper from "../../../../core/reportWrapper";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faGripLines} from "@fortawesome/free-solid-svg-icons";
import BreadcrumbUtil from "../../../../../util/BreadcrumbUtil";
import StringUtil from "../../../../../util/StringUtil";
import CommentTab from "../../../comment/CommentTab";
import HistoryTab from "../../../history/HistoryTab";
class CrosswalkDetailPage extends Component {

    state = {
        activeTab: "details",
        tabs: [
            "details",
            "notes",
            "attachments",
            "comments",
            "history"
        ],
        crosswalkDetail: {}
    };

    constructor(props) {
        super(props);
        this.populatePage = this.populatePage.bind(this);
        this.populateHeader = this.populateHeader.bind(this);
        this.getObjectId = this.getObjectId.bind(this);
        this.onTabSelectHandler = this.onTabSelectHandler.bind(this);
        this.onCancelHandler = this.onCancelHandler.bind(this)
        this.onEditClickHandler = this.onEditClickHandler.bind(this);
        this.loadTopMenuItems = this.loadTopMenuItems.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
    }


    getObjectId() {
        return this.props.crosswalkDetail?.id
    }

    componentDidMount() {
        this.selectTabByUrl();
        BrowserUtil.scrollToTop();
        this.populatePage();
        this.loadTopMenuItems();

    }

    loadTopMenuItems() {

        this.props.onMenuActionLoad([
            <TopActionMenu.ButtonMenuItem label="Delete" icon="trash" onClick={this.onDeleteHandler} />,
            <TopActionMenu.ButtonMenuItem label="Print Screen" icon="print" onClick={() => this.printRef.click()} />,
            <TopActionMenu.ButtonMenuItem disabled label="Export" icon="download" onClick={this.onExportHandler} />,
            <TopActionMenu.ButtonMenuItem disabled label="Bulk Upload Template" icon="upload" onClick={(e) => console.log(e)} />
        ], false);

    }

    populatePage() {
        this.pageUtil = new PageUtil(this.props);
        if (this.pageUtil.exists("id")) {
            const crosswalkId = this.pageUtil.get("id");
            this.props.getCrosswalkById(crosswalkId, (response, err) => {
                if (err) {
                    this.props.history.push("/grc-library/crosswalks")
                }
            });
        }
    }

    populateHeader(init = false) {
        this.pageUtil = new PageUtil()
        const {internalId,referenceId} = this.props.crosswalkDetail;
        const {activeTab} = this.state;
        if(internalId){
            let breadcrumb = BreadcrumbUtil.createRequest("Crosswalks",internalId,true);
            if(activeTab!=="details"){
                const prev = breadcrumb;
                prev.uri = `/grc-library/crosswalks/${referenceId}`;
                breadcrumb = BreadcrumbUtil.createRequest("Crosswalks",StringUtil.toTitleCase(activeTab),false,prev);
            }            
            const pageDescription = this.pageUtil.generatePageDescriptionRequest(PAGE_TYPE_VIEW, "Crosswalks")
            const event = this.pageUtil.generatePageLoadRequest(breadcrumb, pageDescription)
            this.props.onPageLoad(event);
        }
    }


    onDeleteHandler() {
        const { deleteCrosswalk, history } = this.props;

        const deleteRecord = () => {
            deleteCrosswalk(this.pageUtil.get("id"), (data, err) => {
                if (!err) {
                    history.push("/grc-library/crosswalks");
                }
            })
        }

        confirmAlert({
            customUI: ({ onClose }) => <ConfirmWindow onClose={onClose} onAction={deleteRecord} />
        });

    }

    selectTabByUrl() {
        const { tab } = this.props.match.params;
        const { tabs } = this.state;
        const selectedTab = tabs.filter((e) => e === tab);

        if(selectedTab.length>0){
            this.setState({activeTab:tab});
        }

        this.populateHeader(true);
    }

    onTabSelectHandler(tabName) {
        this.setState({ activeTab: tabName });

        const url = `/grc-library/crosswalks/` + this.props.crosswalkDetail.referenceId;

        if (tabName === "details") {
            this.props.history.push(url);
            this.loadTopMenuItems();
        } else {
            this.props.history.push(url + "/" + tabName);
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.location !== this.props.location) {
            this.props.resetSaveCrosswalk();
            this.populatePage();
        }

        if (prevProps.crosswalkDetail !== this.props.crosswalkDetail && this.props.crosswalkDetail !== this.state.crosswalkDetail) {
            this.populateHeader(true);
            this.setState({ crosswalkDetail: this.props.crosswalkDetail });
        }

        if (this.props.match.params !== prevProps.match.params) {
            this.selectTabByUrl();
        }
    }

    onEditClickHandler = (event) => {
        const crosswalkDetail = this.props.crosswalkDetail
        this.props.history.push(`/grc-library/crosswalks/edit/${crosswalkDetail?.referenceId}`);
        event.preventDefault();
    }

    onCancelHandler = (event) => {
        const redirectUrl = "/grc-library/crosswalks";
        this.props.history.push(redirectUrl);
        event.preventDefault();
    }

    render() {
        const { controlLibrary, relatedControlLibrary, id, referenceId } = this.props.crosswalkDetail;
        const headerText = `Crosswalk for ${controlLibrary?.internalId}`
        const infoText = `Related Control Library ${relatedControlLibrary?.internalId}`
        return (
            <div>
                <ReactToPrint
                    trigger={() => <div ref={el => (this.printRef = el)} className="print-action" href="#">Print this out!</div>}
                    content={() => this.contentRef}
                />
                <ReportWrapper entityName="Crosswalk" ref={el => (this.contentRef = el)}>
                    <section id="content-wrap" className="right-content-wrap">
                        <DetailPageHeader info={infoText} name={headerText} icon={<FontAwesomeIcon fixedWidth icon={faGripLines}/>}/>
                        <Row className="tab-wrap">
                            <Col lg={12}>
                                <Tabs mountOnEnter={true} unmountOnExit={true} activeKey={this.state.activeTab} onSelect={this.onTabSelectHandler}>
                                    <Tab eventKey="details" title="Details">
                                        <CrosswalkDetailTab {...this.props} />
                                    </Tab>
                                    <Tab eventKey="notes" title="Notes">
                                        <NotesTab objectName="crosswalk" objectId={id} objectReferenceId={referenceId} {...this.props} />
                                    </Tab>
                                    <Tab eventKey="attachments" title="Attachments">
                                        <AttachmentTab objectName="crosswalk" objectId={id} {...this.props} />
                                    </Tab>
                                    <Tab eventKey="comments" title="Comments">
                                        <CommentTab objectName="crosswalk" objectId={id} {...this.props}/>
                                    </Tab>
                                    <Tab eventKey="history" title="History">
                                        <HistoryTab objectName="crosswalk" objectId={id} {...this.props}/>
                                    </Tab>
                                </Tabs>
                            </Col>
                        </Row>
                    </section>
                </ReportWrapper>
            </div>)
    }
}

const mapStateToProps = (state) => {
    return ({
        crosswalkDetail: state.grcLibrary.crosswalkDetail,
        savedCrosswalk: state.grcLibrary.savedCrosswalk
    })
}


export default pageWrapper(connect(mapStateToProps, actions)(CrosswalkDetailPage));