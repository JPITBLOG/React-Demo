import React, {Component} from 'react';
import UUIDUtil from "../../../../util/UUIDUtil";
import SearchOnType, {SEARCH_ON_TYPE_RESET} from "../../../core/SearchOnType";
import FilterChip from "../../../core/FilterChip";
import ClearIcon from "@material-ui/icons/Clear";
import {Button, Col, Row} from "react-bootstrap";
import withEventBus from "../../../core/withEventBus";
import {connect} from "react-redux";
import MultiSelectorDropDown from "../../../core/MultiSelectorDropDown";

class CrosswalkSearchTab extends Component{

    static defaultProps={
        showObligationFilter:true
    }

    constructor(props) {
        super(props);
        this.state={
            searchOnTypeName:UUIDUtil.v4(),
            selectedObligations:[],
            selectedTags:[],
            selectedTypes:[],
            selectedStatuses:[],
            selectedOwners:[],
            dropdownHeight:400
        }
        this.onSearchTypeHandler = this.onSearchTypeHandler.bind(this);
        this.onClickResetHandler = this.onClickResetHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.removeFromSelectedList = this.removeFromSelectedList.bind(this);
        this.onCloseFilterHandler = this.onCloseFilterHandler.bind(this);
        this.sendFilterChange = this.sendFilterChange.bind(this);
        this.onChangeSelectValue = this.onChangeSelectValue.bind(this);
    }

    onClickResetHandler(event){
        const state = this.state
        const collections = "selectedObligations,selectedTags,selectedTypes,selectedStatuses,selectedOwners".split(",");
        collections.forEach((name)=>{
            state[name]=[];
        });
        this.setState(state);
        this.props.onResetFilters();
        this.props.eventBus.dispatch(SEARCH_ON_TYPE_RESET,this.state.searchOnTypeName);
        event.preventDefault();
    }

    onChangeSelectValue(entity,value){
        switch (entity) {
            case "obligation":
                this.setState({ selectedObligations: value });
                break;
            case "tag":
                this.setState({ selectedTags: value });
                break;
            case "type":
                this.setState({ selectedTypes: value });
                break;
            case "status":
                this.setState({ selectedStatuses: value });
                break;
            case "owner":
                this.setState({ selectedOwners: value });
                break;
            default:
                break;
        }
    }

    onCloseFilterHandler(event){
        this.sendFilterChange(event);
    }

    sendFilterChange(event){

        const {selectedObligations,selectedTags,selectedTypes,selectedStatuses,selectedOwners} = this.state

        const response = {
            "name": event,
            "value": ""
        }

        switch (event) {
            case "obligation":
                response.value= JSON.stringify(selectedObligations.map((obligation)=>obligation.value));
                break;
            case "tag":{
                response.value=JSON.stringify(selectedTags);
                break;
            }
            case "type":{
                response.value= JSON.stringify(selectedTypes.map((type)=>type.value));
                break;
            }
            case "status":{
                response.value= JSON.stringify(selectedStatuses.map((type)=>type.value));
                break;
            }
            case "owner":{
                response.value= JSON.stringify(selectedOwners.map((type)=>type.value));
                break;
            }
            default:
                break;
        }
        this.props.onFilterChange(response);
    }


    renderChips(){
        let chipList=[];
        this.state.selectedObligations.forEach(value => {
            chipList.push(this.renderChip('obligation',value));
        });
        this.state.selectedTags.forEach(value => {
            chipList.push(this.renderChip('tag',value));
        });
        this.state.selectedTypes.forEach(value => {
            chipList.push(this.renderChip('type',value));
        });
        this.state.selectedStatuses.forEach(value => {
            chipList.push(this.renderChip('status',value));
        });
        this.state.selectedOwners.forEach(value => {
            chipList.push(this.renderChip('owner',value));
        });


        return chipList;
    }

    renderChip(type,data,labelKey="label",valueKey="value"){
        const chipId = `chip-${type}-${data[valueKey]}`;
        return (<FilterChip key={chipId} id={chipId}
                            label={data[labelKey]}
                            onDelete={this.onDeleteHandler} color="default"
                            deleteIcon={<ClearIcon/>}
        />);
    }

    onDeleteHandler(event){
        const itemId = event.currentTarget.parentNode.id.split("-");
        switch (itemId[1]) {
            case "obligation":
                this.removeFromSelectedList(itemId[1],"selectedObligations",itemId[2],"value")
                break;
            case "tag":
                this.removeFromSelectedList(itemId[1],"selectedTags",itemId[2],"value")
                break;
            case "type":
                this.removeFromSelectedList(itemId[1],"selectedTypes",itemId[2],"value")
                break;
            case "status":
                this.removeFromSelectedList(itemId[1],"selectedStatuses",itemId[2],"value")
                break;
            case "owner":
                this.removeFromSelectedList(itemId[1],"selectedOwners",itemId[2],"value")
                break;
            default:
                break;
        }
    }

    removeFromSelectedList(event,listName,idToDelete,valueKey){
        const state = this.state;
        state[listName]=state[listName].filter(function(item){
            return String(item[valueKey]) !== String(idToDelete);
        });
        this.setState(state);
        this.sendFilterChange(event);
    }

    onSearchTypeHandler(event){
        this.props.onSearchType(event);
    }

    render() {
        const {
            selectedObligations,
            selectedTags,
            selectedTypes,
            selectedStatuses,
            selectedOwners,
            searchOnTypeName
        } = this.state;
        const {showObligationFilter, showButton} = this.props;
        return(<div className="obligation-section-search"><div className="filter-form">
            <SearchOnType onChange={this.onSearchTypeHandler} name={searchOnTypeName} showButton={showButton} />
            <Row>
                {showObligationFilter && <Col lg={3} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedObligations}
                        options={this.props.obligationsFilterData}
                        onChange={(e)=>this.onChangeSelectValue("obligation",e)}
                        onClose={()=>this.onCloseFilterHandler("obligation")}
                        singularSelectedPlaceholder="%s Obligation selected"
                        manySelectedPlaceholder="%s Obligations selected"
                        placeholder="Filter by Obligations"
                    />
                </Col>}
                <Col lg={2} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedTags}
                        options={[]}
                        onChange={(e)=>this.onChangeSelectValue("tag",e)}
                        onClose={()=>this.onCloseFilterHandler("tag")}
                        singularSelectedPlaceholder="%s Tag selected"
                        manySelectedPlaceholder="%s Tags selected"
                        placeholder="Filter by Tags"
                    />
                </Col>
                <Col lg={2} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedTypes}
                        options={this.props.controlLibraryTypeFilterData}
                        onChange={(e)=>this.onChangeSelectValue("type",e)}
                        onClose={()=>this.onCloseFilterHandler("type")}
                        singularSelectedPlaceholder="%s Type selected"
                        manySelectedPlaceholder="%s Types selected"
                        placeholder="Filter by Types"
                    />
                </Col>
                <Col lg={2} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedStatuses}
                        options={this.props.controlLibraryStatusFilterData}
                        onChange={(e)=>this.onChangeSelectValue("status",e)}
                        onClose={()=>this.onCloseFilterHandler("status")}
                        singularSelectedPlaceholder="%s Status selected"
                        manySelectedPlaceholder="%s Statuses selected"
                        placeholder="Filter by Statuses"
                    />
                </Col>
                <Col lg={2} className="form-group filter-selection-col">
                    <MultiSelectorDropDown
                        value={selectedOwners}
                        options={this.props.usersFilterData}
                        onChange={(e)=>this.onChangeSelectValue("owner",e)}
                        onClose={()=>this.onCloseFilterHandler("owner")}
                        singularSelectedPlaceholder="%s Owner selected"
                        manySelectedPlaceholder="%s Owners selected"
                        placeholder="Filter by Owners"
                    />
                </Col>
                <Col lg={1} className="form-group filter-selection-col">
                    <Button variant="link" onClick={this.onClickResetHandler}>Clear all</Button>
                </Col>
            </Row>
            <div className="filters-option">
                {this.renderChips()}
            </div>
        </div></div>)
    }
}

const mapStateToProps = (state)=>{
    return({
        obligationsFilterData: state.searchFilter.obligationsFilterData,
        controlLibraryTypeFilterData: state.searchFilter.controlLibraryTypeFilterData,
        controlLibraryStatusFilterData: state.searchFilter.controlLibraryStatusFilterData,
        usersFilterData: state.searchFilter.usersFilterData
    });
}

export default withEventBus(connect(mapStateToProps,null)(CrosswalkSearchTab));
