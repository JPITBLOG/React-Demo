import React from 'react';
import GitUtil from "../../util/GitUtil";
import Row from "react-bootstrap/Row";

export default function VersionPage(){
    return(
        <div className="page404">
            <Row className="justify-content-center">
                {GitUtil.hash()}
            </Row>
            <Row className="justify-content-center">
                {GitUtil.branch()}
            </Row>
            <Row className="justify-content-center">
                {process.env.REACT_APP_ENV}
            </Row>
        </div>)
}