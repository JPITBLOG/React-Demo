import React, { Component } from 'react';
import SigninForm from "./form/SigninForm";
import queryString from 'query-string';
import SingleSignOn from "./SingleSignOnContainer";
import {connect} from "react-redux";
import * as actions from "../../../actions";
import {Image} from "react-bootstrap";

class SigninPage extends Component{

    constructor(props) {
        super(props);
        this.state={
            token:"",
            errorMessage:"",
        }
    }

    componentDidMount() {
        let params = queryString.parse(this.props.history.location.search)
        let state={};
        if(params["token"]){
            state["token"]=params.token;
        }
        this.setState(state);
    }

    render(){
        const {token} = this.state;
        return(
            <section className="loin-form-section">
                    <div className="login-main-wrapper">
                        <div className="form-wrapper">
                            {!token && <SigninForm history={this.props.history} errorMessage={this.props.errorMessage}/>}
                            {token && <SingleSignOn history={this.props.history}/>}
                        </div>
                    {!this.props.phoneFragment &&
                        <div className="logo-banner">
                            <Image src="/assets/img/background.png" />
                        </div>}
                    </div>
            </section>
        );
    }
};

function mapStateToProps(state){
    return {
        errorMessage: state.auth.errorMessage,
        phoneFragment: state.auth.phoneFragment
    };
}

export default connect(mapStateToProps,actions)(SigninPage)