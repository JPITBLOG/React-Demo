import React,{Component} from 'react';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faCheck, faTimes} from "@fortawesome/free-solid-svg-icons";

export default class CheckValidationIcon extends Component{

    static defaultProps={
        valid:false
    }

    constructor(props) {
        super(props);
        this.state={
            valid:props.valid,
            validStyle:{
                color:"#66a103",
                icon: faCheck,
            },
            invalidStyle:{
                color:"#FF0000",
                icon: faTimes
            }
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot){
        if(prevProps.valid!==this.props.valid){
            this.setState({valid:this.props.valid});
        }
    }

    getRenderStyle(){
        if(this.state.valid){
            return this.state.validStyle;
        }else {
            return this.state.invalidStyle;
        }
    }

    render() {
        return(<FontAwesomeIcon fixedWidth color={this.getRenderStyle().color} icon={this.getRenderStyle().icon}/>);
    }

}