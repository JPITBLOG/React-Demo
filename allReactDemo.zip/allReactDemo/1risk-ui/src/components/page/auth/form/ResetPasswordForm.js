import React,{Component} from 'react';
import * as actions from '../../../../actions';
import { connect } from 'react-redux';
import queryString from 'query-string';

import RegexUtil from "../../../../util/RegexUtil";
import ErrorInfoBox from "../../../core/ErrorInfoBox";
import CheckValidationIcon from "./CheckValidationIcon";
import * as MessageBundle from '../../../../bundle/MessageBundle'
import SpinningButton from "../../../core/button/SpinningButton";

const REGULAR_FIELD = "form-group";

class ResetPasswordForm extends Component{

    constructor(props) {
        super(props);
        this.state={
            token: "",
            isExpired: false,
            errorMessage:"",
            formData:{
                password:"",
                confirmPassword:""
            },
            formClass:{
                password:REGULAR_FIELD,
                confirmPassword:REGULAR_FIELD
            },
            errors:{
                oneLetter:false,
                oneNumber:false,
                tenCharsLong:false,
                passwordMatch:false
            },
            loading:false
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

    }

    handleChange(event){

        const {formData,errors} = this.state;
        const fieldValue=event.target.value;
        const fieldName=event.target.name;

        if(fieldName==="password"){
            errors.oneLetter=RegexUtil.atLeastOneLetter(fieldValue);
            errors.oneNumber=RegexUtil.atLeastOneNumber(fieldValue);
            errors.tenCharsLong=RegexUtil.atLeast10Chars(fieldValue);
        }

        if(fieldName==="confirmPassword"){
            errors.passwordMatch= formData.password === fieldValue;
        }

        formData[fieldName]=fieldValue;
        this.setState({formData:formData});
        event.preventDefault();
    }

    handleSubmit(event){
        const request={
            token:this.state.token,
            password: this.state.formData.password
        }
        if(this.validateForm()){
            this.setState({loading:true})
            this.props.resetPassword(request, (userInfo,err)=> {
                if (err) {
                    this.setState({loading: false})
                    const data = err.response.data;
                    if(data.includes("com.onerisk.tools.oneriskportalapi.exception.Reset")){
                        this.setState({errorMessage:"Link request expired. Request again"});
                    }else{
                        this.setState({errorMessage:"Error on reset password, please try again later"});
                    }
                }
                const request={
                    customerId:userInfo.customerId,
                    username:userInfo.username,
                    mfaCode:userInfo.mfaCode,
                    password:this.state.formData.password
                }
                this.props.signin(request, (err)=>{
                    this.setState({loading:false})
                    if(!err){
                        this.props.history.push('/');
                    }else{
                        this.setState({loading: false})
                        this.setState({errorMessage:err.message})
                    }
                });
            });
        }
        event.preventDefault();
    }

    componentDidMount() {
        let params = queryString.parse(this.props.history.location.search)
        let state={};
        if(params["token"]){
            state["token"]=params.token;
        }
        if(params["expired"]){
            state["isExpired"]=true;
        }
        this.setState(state);
    }

    validateForm(){

        const {formData, formClass, errors} = this.state;
        const fields = "password,confirmPassword".split(",");

        let validated = true;

        fields.forEach(fieldName => {
            this.toggleError(fieldName,!RegexUtil.validateEmpty(formData[fieldName]));
            if(formClass[fieldName].includes("error")){
                validated=false
            }
        });

        Object.keys(errors).forEach(key => {
            if(!errors[key]){
                validated=false;
            }
        });

        if(!validated){
            this.setState({errorMessage:MessageBundle.ERROR_VALIDATION_REQUIREMENTS})
        }

        return validated;

    }

    toggleError(fieldName,flag){
        const formClass = this.state.formClass;
        if(flag){
            formClass[fieldName] = REGULAR_FIELD + " error";
        }else{
            formClass[fieldName] = REGULAR_FIELD;
        }

        this.setState(formClass)
    }

    render() {

        const {errors,errorMessage,formData,formClass,loading, isExpired} = this.state

        return(
            <form onSubmit={this.handleSubmit} id="password-set-form">
                <div className="form-inner">
                    <div className="brand-wrapper">
                        <a href="/"><img src="assets/img/CyberOne-logo.png" alt="cyberone"/></a>
                    </div>
                    <div className="form-group reset-title">
                        <h2>SET PASSWORD</h2>
                        {isExpired && <p>Your password expired, please set a new one</p>}
                    </div>

                    <div className={formClass.password}>
                        <label htmlFor="password">Password</label>
                        <input type="password" className="form-control" id="password" name="password" onChange={this.handleChange} onBlur={this.handleChange} value={formData.password}/>
                        <ul className="fas-ul requerment-list">
                            <li className="fas-li latter-msg"><CheckValidationIcon valid={errors.oneLetter}/> Must have at least one letter</li>
                            <li className="fas-li number-msg"><CheckValidationIcon valid={errors.oneNumber}/> Must have at least one number</li>
                            <li className="fas-li length-msg"><CheckValidationIcon valid={errors.tenCharsLong}/> Must be at least 10 characters long</li>
                        </ul>
                    </div>

                    <div className={formClass.confirmPassword}>
                        <label htmlFor="confirm_password">Repeat Address</label>
                        <input type="password" autocomplete="off" className="form-control" id="confirm_password"
                               name="confirmPassword" onChange={this.handleChange} onBlur={this.handleChange} value={formData.confirmPassword}/>
                        <ul className="requerment-list">
                            <li className="matching-msg"><CheckValidationIcon valid={errors.passwordMatch}/> Repeated password must match</li>
                        </ul>
                    </div>

                    <ErrorInfoBox message={errorMessage} display={errorMessage} />

                    <SpinningButton loading={loading} type="submit">Save Password</SpinningButton>

                    <p className="form-footer-text">Need help? <a href="/">Visit our help center</a></p>
                </div>
            </form>
        )
    }
}

function mapStateToProps(state){
    return {username: state.auth.username};
}

export default connect(mapStateToProps,actions)(ResetPasswordForm)