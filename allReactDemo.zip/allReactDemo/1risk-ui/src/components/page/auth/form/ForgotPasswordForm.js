import React, {Component} from 'react';
import * as actions from '../../../../actions';
import {connect} from 'react-redux';
import * as MessageBundle from '../../../../bundle/MessageBundle'
import RegexUtil from "../../../../util/RegexUtil";
import ErrorInfoBox from "../../../core/ErrorInfoBox";
import SpinningButton from "../../../core/button/SpinningButton";

const REGULAR_FIELD = "form-group";

class ForgotPasswordForm extends Component{

    constructor(props) {
        super(props);
        this.state={
            errorMessage:"",
            formData:{
                username:""
            },
            formClass:{
                username:REGULAR_FIELD
            },
            loading:false
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

    }

    handleChange(event){

        let validated = RegexUtil.validateEmpty(event.target.value) && RegexUtil.validateEmail(event.target.value);
        this.toggleError(event.target.name,!validated);

        const formData = this.state.formData;
        formData[event.target.name]=event.target.value;
        this.setState(formData);

    }

    handleSubmit(event){
        if(this.validateForm()){
            this.setState({ loading:true})
            this.props.forgotPassword(this.state.formData, ()=>{
                this.setState({ loading:false})
                this.props.history.push('/forgot-password-success');
            });
        }
        event.preventDefault();
    }

    toggleError(fieldName,flag){
        const formClass = this.state.formClass;
        if(flag){
            formClass[fieldName] = REGULAR_FIELD + " error";
        }else{
            formClass[fieldName] = REGULAR_FIELD;
        }

        this.setState(formClass)
    }

    validateForm(){

        const {formData, formClass} = this.state;
        const fieldName = "username";

        let validated = true;

        this.toggleError(fieldName,!RegexUtil.validateEmpty(formData[fieldName]));
        if(formClass[fieldName].includes("error")){
            validated=false
        }


        if(!validated){
            this.setState({errorMessage:MessageBundle.VALIDATION_ERROR_MSG})
        }else{
            this.setState({errorMessage:""})
        }

        return validated;

    }

    render() {

        const {errorMessage,formData,formClass,loading} = this.state;

        return(
            <form onSubmit={this.handleSubmit} id="password-reset-form">
                <div className="form-inner">
                    <div className="brand-wrapper">
                        <a href="/"><img src="assets/img/CyberOne-logo.png" alt="cyberone" /></a>
                    </div>
                    <div className="form-group reset-title">
                        <h2>Password Reset</h2>
                        <p>Enter your account's email address and we'll send you a secure link to reset your password.</p>
                    </div>
                    <div className={formClass.username}>
                        <label htmlFor="email">Email Address</label>
                        <input type="text" className="form-control" id="email" name="username"
                               placeholder="your@email.com" value={formData.username} onChange={this.handleChange} onBlur={this.handleChange}/>
                    </div>

                    <ErrorInfoBox message={errorMessage} display={errorMessage}/>

                    <SpinningButton loading={loading} type="submit">Send Link</SpinningButton>

                    <p className="back-to-login"><a href="/signin">Back to sign in</a></p>
                    <p className="form-footer-text">Need help? <a href="/">Visit our help center</a></p>
                </div>
            </form>
        )
    }
}

function mapStateToProps(state){
    return {username: state.auth.username};
}

export default connect(mapStateToProps,actions)(ForgotPasswordForm)