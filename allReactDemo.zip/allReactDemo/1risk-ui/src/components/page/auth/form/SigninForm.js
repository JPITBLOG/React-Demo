import React, {Component} from 'react';
import * as actions from '../../../../actions';
import * as MessageBundle from '../../../../bundle/MessageBundle'
import {connect} from 'react-redux';
import {NavLink} from "react-router-dom";
import RegexUtil from "../../../../util/RegexUtil";

import {faEye, faSignInAlt} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import ErrorInfoBox from "../../../core/ErrorInfoBox";
import SpinningButton from "../../../core/button/SpinningButton";

const FORM_USERNAME = "username";
const FORM_MFA_CODE = "mfaCode";

const REGULAR_FIELD = "form-group";

const GOOGLE_PROVIDER = "google";
const MICROSOFT_PROVIDER = "office";

class SigninForm extends Component{

    constructor(props) {
        super(props);
        this.state = {
            sso:{
                google: process.env.REACT_APP_SSO_URL+GOOGLE_PROVIDER,
                microsoft: process.env.REACT_APP_SSO_URL+MICROSOFT_PROVIDER
            },
            showMfa:false,
            errorMessage:"",
            rememberMe: false,
            formData:{
                username:"",
                password:"",
                mfaCode: ""
            },
            formClass:{
                username: REGULAR_FIELD,
                password: REGULAR_FIELD,
                mfaCode: REGULAR_FIELD
            },
            passwordFieldType:"password",
            loading:false
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.togglePasswordField = this.togglePasswordField.bind(this);
        this.handleMfaSubmit = this.handleMfaSubmit.bind(this);
        this.sendMfaCodeAction = this.sendMfaCodeAction.bind(this);
    }

    componentDidUpdate(prevProps, prevState, snapshot){
        if(prevProps.errorMessage!==this.props.errorMessage){
            this.setState({errorMessage:this.props.errorMessage});
        }
    }

    handleChange(event) {

        let validated = RegexUtil.validateEmpty(event.target.value);

        switch (event.target.name) {
            case FORM_USERNAME:
                if(!RegexUtil.validateEmail(event.target.value)){
                    validated=false;
                }
                break;
            case FORM_MFA_CODE:
                event.target.value=event.target.value.replace(/\D/,'')
                if(!RegexUtil.atLeast6Chars(event.target.value)){
                    validated=false;
                }
                break;
            default:
                break;
        }

        const formData = this.state.formData;
        formData[event.target.name]=event.target.value;

        this.setState(formData);

        this.toggleError(event.target.name,!validated)

    }

    toggleError(fieldName,flag){
        const formClass = this.state.formClass;
        if(flag){
            formClass[fieldName] = REGULAR_FIELD + " error";
        }else{
            formClass[fieldName] = REGULAR_FIELD;
        }

        this.setState(formClass)
    }

    togglePasswordField(){
        if(this.state.passwordFieldType==="password"){
            this.setState({passwordFieldType:"text"})
        }else{
            this.setState({passwordFieldType:"password"})
        }
    }

    validateForm(){

        const {formData, formClass} = this.state;
        const fields = "username,password".split(",");

        let validated = true;

        fields.forEach(fieldName => {
            this.toggleError(fieldName,!RegexUtil.validateEmpty(formData[fieldName]));
            if(formClass[fieldName].includes("error")){
                validated=false
            }
        });

        if(!validated){
            this.setState({errorMessage:MessageBundle.VALIDATION_ERROR_MSG})
        }

        return validated;

    }

    handleSubmit(event) {
        if(this.validateForm()){
            this.setState({loading:true})
            this.props.sendMfaCode(this.state.formData,(err)=>{
                this.setState({loading:false})
                if(!err){
                    this.setState({errorMessage:""})
                    this.setState({showMfa:true});
                }else{
                    this.setState({errorMessage:MessageBundle.ERROR_LOGIN_MESSAGE})
                }
            });

        }
        event.preventDefault();
    }

    handleMfaSubmit(event){
        const {formData} = this.state;
        if(RegexUtil.validateEmpty(formData.mfaCode) && RegexUtil.atLeast6Chars(formData.mfaCode)){
            this.setState({loading:true})
            this.props.validateMfaCode(formData,(err)=>{
                this.setState({loading:false})
                if(!err){
                    this.sendForm();
                }else{
                    this.setState({errorMessage:MessageBundle.ERROR_VALIDATION_MFA})
                }
            })
        }else{
            this.setState({errorMessage:MessageBundle.VALIDATION_ERROR_MSG})
        }
        event.preventDefault();
    }

    sendMfaCodeAction(event){
        this.setState({loading:true})
        this.props.sendMfaCode(this.state.formData,(err)=>{
            this.setState({loading:false})
            if(err){
                this.setState({errorMessage:MessageBundle.ERROR_LOGIN_MESSAGE})
            }
        });
        event.preventDefault();
    }

    sendForm(){
        this.setState({
            errorMessage:"",
            loading:true
        })
        this.props.signin(this.state.formData, (err)=>{
            this.setState({loading:false})
            if(!err){
                this.props.history.push('/');
            }else{
                if(err.isExpired){
                    this.props.history.push('/reset-password?expired=true&token='+err.resetToken);
                }
                else{
                    this.setState({
                        errorMessage:err.message,
                        showMfa:false
                    })
                }
            }
        });
    }

    render() {
        const {formData, formClass, errorMessage, passwordFieldType, loading, showMfa, sso } = this.state
        if(!showMfa) {
            return (
                <form onSubmit={this.handleSubmit} id="login-form">
                    <div className="form-inner">
                        <div className="brand-wrapper">
                            <a href="/"><img src="assets/img/CyberOne-logo.png" alt="cyberone"/></a>
                        </div>

                        <div className={formClass.username}>
                            <label htmlFor="username">Username</label>
                            <input type="text" className="form-control" id="username" name="username"
                                   onBlur={this.handleChange} onChange={this.handleChange} value={formData.username}/>
                        </div>

                        <div className={formClass.password}>
                            <label htmlFor="password">Password</label>
                            <a href="/forgot-password" className="forget-password-link">Forget password?</a>
                            <div className="input-with-icon">
                                <input type={passwordFieldType} className="form-control" id="password" name="password"
                                       onBlur={this.handleChange} onChange={this.handleChange}
                                       value={formData.password}/>
                                <span className="icon" onClick={this.togglePasswordField}><FontAwesomeIcon
                                    icon={faEye}/></span>
                            </div>
                        </div>

                        {this.state.rememberMe &&
                        <div className="form-group form-check">
                            <input type="checkbox" className="form-check-input" id="remember" name="remember"/>
                            <label className="form-check-label" htmlFor="remember">Remember this device</label>
                        </div>
                        }

                        <ErrorInfoBox message={errorMessage} display={errorMessage}/>

                        <SpinningButton loading={loading} type="submit" icon={faSignInAlt}>Log In</SpinningButton>

                        <div className="social-login-title">
                            <h6>or sign in with</h6>
                        </div>
                        <div className="social-login-providers">
                            <a href={sso.google} className="provider"><img src="assets/img/google-logo.png" width="18px"
                                                                  alt="google"/> Google</a>
                            {/*<a href={sso.microsoft} className="provider"><img src="assets/img/ms-logo.png" width="15px"*/}
                            {/*                                      alt="Microsoft"/> Microsoft</a>*/}
                        </div>
                        <p className="form-footer-text"><a href="https://www.cb1security.com/registration2">Register for New Account</a></p>
                        <p className="form-footer-text">Need help? <a href="https://train.cyberonerisk.com/">Visit our
                            help center</a></p>
                    </div>
                </form>
            );
        }else{
            return(
                <form onSubmit={this.handleMfaSubmit}  id="password-reset-form">
                    <div className="form-inner">
                        <div className="brand-wrapper">
                            <a href="/"><img src="assets/img/CyberOne-logo.png" alt="cyberone"/></a>
                        </div>
                        <div className="form-group reset-title">
                            <h2>Two-Factor authentication</h2>
                            <p>Enter the 6-digit code sent to your device.</p>
                        </div>

                        <div className={formClass.mfaCode}>
                            <label htmlFor="email">Enter code</label>
                            <input type="text" className="form-control" id="mfa-code" name="mfaCode"
                                   placeholder="6-digit code" value={formData.mfaCode} onChange={this.handleChange} onBlur={this.handleChange} autoComplete="off"/>
                        </div>

                        <ErrorInfoBox message={errorMessage} display={errorMessage}/>

                        <SpinningButton loading={loading} type="submit">Validate</SpinningButton>

                        <p className="resend-code align-content-center">
                            <NavLink to="/" onClick={this.sendMfaCodeAction}>Send a new code</NavLink>. &nbsp;
                            <span className="info-banner">Some service providers may apply text and data charges.</span>
                        </p>
                        <p className="form-footer-text">Need help? <a href="/">Visit our help center</a></p>
                    </div>
                </form>
            );
        }
    }
}

function mapStateToProps(state){
    return {
        errorMessage: state.auth.errorMessage,
        phoneFragment: state.auth.phoneFragment
    };
}

export default connect(mapStateToProps,actions)(SigninForm)