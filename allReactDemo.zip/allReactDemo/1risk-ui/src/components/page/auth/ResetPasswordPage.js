import React,{Component} from "react";
import ResetPasswordForm from "./form/ResetPasswordForm";

class ResetPasswordPage extends Component{
    componentDidMount(){
        localStorage.removeItem('token');
    }

    render() {
        return(
            <section className="loin-form-section">
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="form-wrapper password-reset">
                            <ResetPasswordForm history={this.props.history}/>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}

export default (ResetPasswordPage)
