import React,{Component} from 'react';
import queryString from 'query-string';
import * as actions from '../../../actions';
import { connect } from 'react-redux';

import './SingleSingOnContainer.css';

class SingleSignOnContainer extends Component{
    constructor(props) {
        super(props);
        this.state={
            loading:false,
            token:""
        }
    }

    componentDidMount() {
        let params = queryString.parse(this.props.history.location.search)
        let state={};
        if(params["token"]){
            state["token"]=params.token;
        }
        this.setState(state);
        if(state.token){
            this.props.sso(state.token,()=> {
                this.props.history.push('/');
            })
        }
    }

    render() {
        return(<div>
            <svg className="spinningLoader" xmlns="http://www.w3.org/2000/svg" width="232.5" height="235" viewBox="0 0 232.5 235">
                <g id="Spinner" transform="translate(-547.185 -60.725)">
                    <path id="ellipse" d="M112.5,0A112.5,112.5,0,1,1,0,112.5,112.5,112.5,0,0,1,112.5,0Z" transform="translate(549.685 65.724)" fill="none" stroke="#1f9eff" strokeLinecap="round" strokeWidth="5"/>
                    <path id="line" d="M112.5,0a112.5,112.5,0,0,1,0,225" transform="translate(549.685 65.725)" fill="none" stroke="#1f9eff" strokeLinecap="square" strokeWidth="10"/>
                </g>
            </svg>
        </div>)
    }

}

function mapStateToProps(state){
    return {
        errorMessage: state.auth.errorMessage
    };
}

export default connect(mapStateToProps,actions)(SingleSignOnContainer)