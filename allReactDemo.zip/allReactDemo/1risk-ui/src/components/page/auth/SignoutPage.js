import React, { Component } from 'react';
import * as actions from '../../../actions';
import {connect} from "react-redux";

class SignoutPage extends Component{

    componentDidMount() {
        this.props.signout(()=>{
            this.props.history.push("/signin");
        });
    }

    render() {
        return(<div>&nbsp;</div>)
    }
}

function mapStateToProps(state){
    return {errorMessage: state.auth.errorMessage};
}

export default connect(mapStateToProps,actions)(SignoutPage)