import React, {Component} from 'react';
import {connect} from 'react-redux';
import * as actions from '../../../actions';

class ForgotPasswordSuccessPage extends Component {

    componentDidMount() {
        this.props.getResetUsername();
    }

    render() {
        return (
            <section className="loin-form-section">
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="form-wrapper success">
                            <div className="form-inner">
                                <div className="brand-wrapper">
                                    <a href="/"><img src="assets/img/CyberOne-logo.png" alt="cyberone" /></a>
                                </div>
                                <div className="form-group reset-title success">
                                    <h2><i className="fas fa-check"></i> Password reset link sent!</h2>
                                    <p>If an account exists, a password reset link was sent to <strong>{this.props.username}</strong>.</p>
                                    <p>If you don’t see it in a couple minutes, check your spam folder. It was sent from <a href="mailto:support@1risk.io">support@1risk.io</a>
                                        If you’re still having issues, contact us.</p>
                                </div>

                                <a href="../signin" className="btn btn-primary">Back to sign-in</a>

                                <p className="form-footer-text">Need help? <a href="/">Visit our help center</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
}
function mapStateToProps(state) {
    return { username: state.auth.username };
}
export default connect(mapStateToProps, actions)(ForgotPasswordSuccessPage);