import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as actions from '../../../actions';
import ForgotPasswordForm from "./form/ForgotPasswordForm";

class ForgotPasswordPage extends Component {

    render() {
        return (
            <section className="loin-form-section">
                    <div className="container">
                        <div className="row justify-content-center">
                            <div className="form-wrapper password-reset">
                                <ForgotPasswordForm history={this.props.history}/>
                            </div>
                        </div>
                    </div>
            </section>
        );
    }
}
function mapStateToProps(state) {
    return { errorMessage: state.auth.errorMessage };
}
export default connect(mapStateToProps, actions)(ForgotPasswordPage);