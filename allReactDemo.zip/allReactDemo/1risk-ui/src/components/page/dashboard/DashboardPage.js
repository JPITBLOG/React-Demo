import React, {Component} from 'react';
import pageWrapper from '../../core/pageWrapper'
import * as actions from '../../../actions';
import {connect} from "react-redux";
import ApplicationLauncher from "./ApplicationLauncher/";
import TopContentBanner from "../../core/TopContentBanner";
import BottomContentBanner from "../../core/BottomContentBanner";

class DashboardPage extends Component{

    componentDidMount() {
        this.props.onPageLoad({"title":"Dashboard","label":"Dashboard","init":true}, "Dashboard");
        if(this.props.auth){
            this.props.getDashboardData()
        }
    }

    render(){
        return(
            <section id="content-wrap" className="right-content-wrap">
                <TopContentBanner/>
                <ApplicationLauncher items={this.props.items}/>
                <BottomContentBanner/>
            </section>
        );
    }
};

function mapStateToProps(state){
    return {
        items: state.dashboard.data,
        auth: state.auth.authenticated
    };
}

export default pageWrapper(connect(mapStateToProps,actions)(DashboardPage));
