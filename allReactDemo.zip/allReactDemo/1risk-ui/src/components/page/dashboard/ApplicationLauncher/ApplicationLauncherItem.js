import React, {Component} from 'react';
import {Col} from 'react-bootstrap';
import {NavLink} from "react-router-dom";
import ComponentUtil from "../../../../util/ComponentUtil";

class ApplicationLauncherItem extends Component{

    static defaultProps={
        icon:"",
        title:"",
        description:"",
        url:"",
        enabled:true
    }

    render(){
        const {icon, title, description, enabled, url} = this.props
        return(
            <Col lg={6} className={enabled ? '': 'disabledMenu'}>
                <div className="info-box">
                    <div className="info-box-icon">
                        <img src={icon} alt={title}/>
                    </div>
                    <div className="info-box-content">
                        <div className="info-content-left">
                            <h4>{title}</h4>
                            <p dangerouslySetInnerHTML={ComponentUtil.createMarkup(description)}></p>
                        </div>
                        {enabled && <div className="info-content-right">
                            <NavLink to={url} className="btn btn-warning"><span>Open</span></NavLink>
                        </div>}
                    </div>
                </div>
            </Col>)
    }
}

export default (ApplicationLauncherItem)