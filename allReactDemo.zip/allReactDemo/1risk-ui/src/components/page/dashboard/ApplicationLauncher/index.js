import React,{Component} from 'react'
import ApplicationLauncherItem from "./ApplicationLauncherItem";
import {Row} from 'react-bootstrap';

import './ApplicationLauncher.css';

class ApplicationLauncher extends Component{

    static defaultProps={
        items:[]
    }

    constructor(props) {
        super(props);
        this.state= {
            items: []
        }

        this.onItemClickHandler = this.onItemClickHandler.bind(this);

    }

    componentDidUpdate(prevProps, prevState, snapshot){
        if(prevProps.items!==this.props.items){
            this.setState({items:this.props.items});
        }
    }

    onItemClickHandler(event,item){
        this.props.history.push(item.url);
        event.preventDefault();
    }

    render() {
        const {items} = this.state;
        return(<div className="inner-content">
            <div className="app-launcher">
                <Row>
                    {items.map((item,index)=>{
                        return(<ApplicationLauncherItem
                            key={index}
                            icon={item.icon}
                            title={item.title}
                            description={item.description}
                            url={item.url}
                            enabled={item.enabled}
                        />)
                    })}
                </Row>
            </div>
        </div>)
    }
}

export default (ApplicationLauncher)