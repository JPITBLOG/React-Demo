import React, {Component} from "react";
import DefaultItemChip from "../DefaultItemChip";

import "./RecordDetailWidget.css";
import ReadMoreText from "../ReadMoreText";

class RecordDetailWidget extends Component{

    constructor(props) {
        super(props);
        this.state={
            tags : ["Industry-tag","Sector-tag","Important-tag","Technical-term",
                "Another-medium-tag","Another-very-very-long-long-tag","Small-tag","Technical-term",
                "Another-medium-tag","Small-tag"]
        }
    }

    render() {
        const {tags} = this.state;
        return(<div className="widget-control">
            <div className="sub-info risk-info">
                <h3>CONTROL DESCRIPTION</h3>
                <ReadMoreText>
                    <p>Configure wireless access on client machines that do have an essential wireless business
                        purpose, to allow access only to authorized wireless networks and to restrict access to
                        other wireless networks. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam
                        et lectus ipsum. Curabitur ultrices nulla id molestie bibendum.</p>
                </ReadMoreText>
            </div>
            <div className="head">
                <h3>OBLIGATION</h3>
                <div className="brand">
                    <img src="/assets/img/e46f889d37e3dce923a270cd69893b35@2x.png" alt=""/>
                    <h4>CIS Controls v7.0</h4>
                </div>
            </div>
            <div className="sub-info">
                <h3>obligation section</h3>
                <p>Wireless Access Control</p>
            </div>
            <div className="sub-info">
                <h3>content source</h3>
                <p>CIS v7.0 C15 (15.5)</p>
            </div>
            <div className="sub-info">
                <h3>TAGS</h3>
                <div className="tags">
                    {tags.map((tagItem,index)=>{
                        return(<DefaultItemChip className="chip-tag" key={index} label={tagItem}/>);
                    })}
                </div>
            </div>
            <div className="sub-info risk-info">
                <h3>RISK</h3>
                <p>Risk description here. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam et
                    lectus ipsum.</p>
            </div>
            <div className="sub-info guidance-info">
                <h3>GUIDANCE</h3>
                <p>Configure wireless access on client machines that do have an essential wireless business
                    purpose, to allow access only to authorized wireless networks and to restrict access to
                    other wireless networks. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam
                    et lectus ipsum. Curabitur ultrices nulla id molestie bibendum.</p>
            </div>
        </div>)
    }
}

export default (RecordDetailWidget)