import React, {useEffect, useState} from 'react';
import {Alert} from "react-bootstrap";

const CustomAlert = ({children,variant="dark",isVisible=true,onClose=()=>null,...restProps})=>{

    const [visible,setVisible] = useState(isVisible);

    useEffect(()=>{
        setVisible(isVisible);
    },[isVisible])

    const onCloseHandler = (event)=>{
        if(restProps.dismissible){
            setVisible(!visible);
            onClose();
        }
    }

    if(visible){
        return(
            <div className="custom-alert">
                <Alert variant={variant} {...restProps} onClose={onCloseHandler}>
                    {children}
                </Alert>
            </div>
        )
    }

    return null;

}

export default (CustomAlert);