import React, {Component} from "react";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faChevronLeft} from "@fortawesome/free-solid-svg-icons";
import {withRouter} from "react-router";

import './MenuToggleButton.css';
import withEventBus from "../withEventBus";
import {WINDOW_FULLSCREEN, WINDOW_RESIZED} from "../../../events/types";

class MenuToggleButton extends Component{

    static defaultProps={
        onToggle:()=>null
    }

    constructor(props) {
        super(props);
        this.state={
            isToggle:false,
            isMobile:false,
            lastLocation: ""
        }
        this.onClickHandler = this.onClickHandler.bind(this);
        this.onWindowResizeHandler = this.onWindowResizeHandler.bind(this);
    }

    componentDidMount(){
        this.props.eventBus.addEventListener(WINDOW_RESIZED,this.onWindowResizeHandler);
    }

    onWindowResizeHandler(event){
        if(event.mobile && !this.state.isMobile){
            const state = this.state;
            state.isToggle = true;
            state.isMobile=true;
            this.setState(state);
            this.props.eventBus.dispatch(WINDOW_FULLSCREEN,state.isToggle);
        }
    }

    onClickHandler(){
        const state = this.state;
        state.isToggle = !state.isToggle;
        this.setState(state);
        this.props.onToggle(state.isToggle);
        this.props.eventBus.dispatch(WINDOW_FULLSCREEN,state.isToggle);
    }

    componentDidUpdate(prevProps, prevState, snapshot): void {
        if(prevProps.isToggle !== this.props.isToggle){
            this.setState({isToggle:this.props.isToggle});
        }
    }

    render(){
        return(
            <div onClick={this.onClickHandler} className="toggle-arrow">
                <FontAwesomeIcon icon={faChevronLeft}/>
            </div>


        )
    }
}

export default withRouter(withEventBus(MenuToggleButton));