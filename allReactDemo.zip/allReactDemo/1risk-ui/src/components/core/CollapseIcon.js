import React from 'react'
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faAngleDown, faAngleRight} from "@fortawesome/free-solid-svg-icons";

function CollapseIcon({onClick=(e)=>console.log(e),expanded=false}){
    return(
        <FontAwesomeIcon style={{cursor:"pointer"}} fixedWidth onClick={onClick} icon={expanded ? faAngleDown: faAngleRight}/>
    );
}

export default (CollapseIcon);