import React from 'react';
import {faLeaf, faUniversity} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import Label from "../Label";

const ControlLibraryIcon = ({value='',tableMeta='', customIdx=3,custom=false,...restProps}) =>{
    if(tableMeta!==''){
        const {rowData} = tableMeta;
        custom=rowData[customIdx]
    }
    return (<React.Fragment>
        <FontAwesomeIcon fixedWidth size="lg" icon={custom ? faLeaf : faUniversity} />
        <Label>{value}</Label>
    </React.Fragment>)
}

export default ControlLibraryIcon;