import React from 'react';
import { faPaperclip } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import AttachTooltip from "../../core/AttachItemTooltip";

const AttachmentsIcon = ({ value = "", tableMeta = "", customIdx = 5 }) => {
    const items = [], icon = <FontAwesomeIcon icon={faPaperclip} />
    let mainContent = "";

    if (tableMeta !== '') {
        const { rowData } = tableMeta;
        rowData[customIdx] && rowData[customIdx].map((item) => items.push(`${item.name} \n`));
    }

    if (items.length > 0) {
        mainContent = (<AttachTooltip title={items} placement="top">
            <div>{value} {icon}</div>
        </AttachTooltip>)
    } else {
        mainContent = (<React.Fragment>
            <div>{value} {icon}</div>
        </React.Fragment>)
    }

    return (
        <React.Fragment>
            {mainContent}
        </React.Fragment>
    )
}

export default AttachmentsIcon;