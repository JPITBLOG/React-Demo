import React from 'react';
import { faExternalLinkAlt } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const ExternalLinkIcon = (props) => {
    return (<FontAwesomeIcon icon={faExternalLinkAlt} style={{ height: '12px', width: '28px' }} />)
}

export default ExternalLinkIcon;