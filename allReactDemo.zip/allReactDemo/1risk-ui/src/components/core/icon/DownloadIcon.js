import React from "react";
import {useDispatch} from 'react-redux';
import {getDownloadAttachment} from '../../../actions/';
import {faDownload} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import styled from 'styled-components';

const IconElement = styled((props)=> <FontAwesomeIcon {...props} />)`
    cursor: pointer;
`;

const DownloadIcon = ({ referenceId }) => {

    const dispatch = useDispatch();

    const onClick = () => {
        dispatch(getDownloadAttachment(referenceId, (attachmentRes, err) => {
            if (!err) {

                const urlParts = attachmentRes.split("/");
                const fileName = urlParts[4].split("?")[0];

                const a = document.createElement('a');

                a.href = attachmentRes;
                a.download = fileName;
                a.click();

            }
        }));
    }

    return (<IconElement icon={faDownload} onClick={onClick} />)
}


export default (DownloadIcon); 