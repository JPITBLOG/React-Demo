import React from "react";
import styled from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import FileUtil from "../../util/FileUtil";

const TimesIcon = styled((props)=> <FontAwesomeIcon fixedWidth {...props} icon={faTimesCircle} />)`
    margin-left: 5px;
    cursor: pointer;
`;

const AttachmentList = styled('ul')`
    font-size: 14px;
    font-family: inherit;
    list-style-type: none;
    padding: 0px;
`;

const AttachmentListItem = styled('li')`
    padding-left: 10px;
`;

const AttachedFileList = ({attachments=[],onDelete=()=>null,...restProps}) =>{

    const onDeleteHandler = (event,index)=>{
        onDelete({
            idx: index,
            item : attachments[index]
        })
        event.preventDefault();
    }

    if(attachments.length===0){
        return null;
    }

    return(
        <AttachmentList {...restProps}>
            {attachments.map((attachment,index)=>{
                return(<AttachmentListItem key={`attachment-item-${index}`}>
                    {attachment.name} ({FileUtil.formatBytes(attachment.size)})
                    <TimesIcon onClick={(e)=>onDeleteHandler(e,index)}/>
                </AttachmentListItem>);
            })}
        </AttachmentList>
    );

}

export default (AttachedFileList);