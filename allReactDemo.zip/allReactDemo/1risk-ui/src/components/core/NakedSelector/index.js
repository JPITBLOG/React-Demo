import React, {useState} from 'react';
import {Dropdown} from "react-bootstrap";

import './NakedSelector.css';

const NakedSelector = (props) =>{

    const {options,onSelect,placeholder,alignRight} = props;

    const initialItemSelected = placeholder ? placeholder : options[0].label;

    const [selected,setSelected] = useState(initialItemSelected);

    const onClick = (event) => {
        const selectedParentLabel = event.currentTarget.dataset.parentlabel;
        const selectedValue = event.currentTarget.dataset.value;
        const selectedLabel = event.currentTarget.dataset.label;

        if(selectedParentLabel){
            console.log(selectedParentLabel);
            setSelected(`${selectedParentLabel} (${selectedLabel})`);
        }else{
            setSelected(selectedLabel);
        }

        onSelect(selectedValue);

        event.preventDefault();
    };

    return(
        <div className="naked-select">
            <Dropdown>
                <Dropdown.Toggle>
                    <span className="label">{selected}</span>
                </Dropdown.Toggle>
                <Dropdown.Menu alignRight={alignRight}>
                    {options.map((item,index)=>{
                        if(item.children){
                            const renderItems = [];
                            renderItems.push(<Dropdown.Header key={`main-${index}`}>{item.label}</Dropdown.Header>);
                            item.children.forEach((childItem,childIndex)=>{
                                renderItems.push(
                                    <Dropdown.Item
                                        data-parentlabel={item.label}
                                        data-value={childItem.value}
                                        data-label={childItem.label}
                                        key={`parent-${childIndex}`}
                                        onClick={onClick}>{childItem.label}
                                    </Dropdown.Item>)
                            })
                            return(renderItems);
                        }else{
                            return(
                                <Dropdown.Item
                                    data-value={item.value}
                                    data-label={item.label}
                                    key={index}
                                    onClick={onClick}>{item.label}
                                </Dropdown.Item>)
                        }
                    })}
                </Dropdown.Menu>
            </Dropdown>
        </div>
    )
}

export default NakedSelector;