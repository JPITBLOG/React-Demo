// @flow
import React, {Component} from 'react';
import findByType from "../../../util/findByType";

import './actionOverlay.css';

const SecondaryActions = () => null;
SecondaryActions.displayName="SecondaryActions";

const Actions = () => null;
Actions.displayName="Actions";

class ActionOverlay extends Component{

    static SecondaryActions: Function;
    static Actions: Function;

    renderSecondaryActions(){
        const { children } = this.props;
        const secondaryActions = findByType(children, SecondaryActions);
        if (!secondaryActions) {
            return null;
        }
        return <div className='content'>{secondaryActions.props.children}</div>;
    }

    renderActions(){
        const { children } = this.props;
        const actions = findByType(children, Actions);
        if (!actions) {
            return null;
        }
        return <div className='content right'>{actions.props.children}</div>;
    }

    render() {
        const {visible} = this.props;
        return(<div className="action-overlay">
            <div className='view' style={{transform: visible ? 'translateY(0)' : 'translateY(80px)'}}>
                <div className='background' />
                <div className='wrapper'>
                    {this.renderSecondaryActions()}
                    {this.renderActions()}
                </div>
            </div>
        </div>)
    }
}

ActionOverlay.Actions = Actions;
ActionOverlay.SecondaryActions = SecondaryActions;

export default (ActionOverlay);