import React, {Component} from 'react'
import CustomAlert from "./CustomAlert";
import ExternalLink from "./ExternalLink";

class TopContentBanner extends Component{

    static defaultProps={
        visible:true
    }

    constructor(props) {
        super(props);
        this.state={
            visible:props.visible
        }
        this.onClickHandler = this.onClickHandler.bind(this);
    }

    onClickHandler(event){
        this.setState({visible:!this.state.visible})
        event.preventDefault();
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if(prevState.visible !== this.props.visible){
            this.setState({visible:this.props.visible})
        }
    }

    render(){
        return(
            <CustomAlert dismissible>
                Learn about the platform features and capabilities at <ExternalLink tab to="https://train.cyberonerisk.com">C1Train Portal</ExternalLink>
            </CustomAlert>
        )
    }

}

export default (TopContentBanner);

