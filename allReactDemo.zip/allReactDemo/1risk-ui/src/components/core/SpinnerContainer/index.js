import React from "react";

import './SpinnerContainer.css';
import {Spinner} from "react-bootstrap";
import PropTypes from 'prop-types';

const SpinnerContainer = ({visible=false})=>{
    if(visible){
        return(<div className="spinner-container">
            <div className="viewport">
                <Spinner className="spinner" animation="border"/>
            </div>
        </div>)
    }
    return null;
}

SpinnerContainer.propTypes={
    visible:PropTypes.bool
}

export default SpinnerContainer;