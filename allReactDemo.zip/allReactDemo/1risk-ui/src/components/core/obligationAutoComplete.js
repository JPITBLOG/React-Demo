import React from 'react';
import useAutocomplete from '@material-ui/lab/useAutocomplete';
import styled from "styled-components";
import CheckIcon from "@material-ui/icons/Check";

const InputWrapper = styled('div')`
  width: 100%;
  border: 1px solid #d9d9d9;
  background-color: #fff;
  border-radius: 4px;
  padding: 1px;
  display: flex;
  flex-wrap: wrap;

  & input {
    font-family: 'Lato', sans-serif;
    font-size: 14px;
    height: 30px;
    box-sizing: border-box;
    padding: 4px 6px;
    width: 0;
    min-width: 30px;
    flex-grow: 1;
    border: 0;
    margin: 0;
    outline: 0;
  }
`;

const Listbox = styled('ul')`
  font-family: 'Lato', sans-serif;
  font-size: 14px;
  width: 95%;
  margin: 2px 0 0;
  padding: 0;
  position: absolute;
  list-style: none;
  background-color: #fff;
  overflow: auto;
  max-height: 250px;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  z-index: 1;

  & li {
    padding: 5px 12px;
    display: flex;

    & span {
      flex-grow: 1;
    }

    & svg {
      color: transparent;
    }
  }

  & li[aria-selected='true'] {
    background-color: #fafafa;
    font-weight: 600;

    & svg {
      color: #1890ff;
    }
  }

  & li[data-focus='true'] {
    background-color: #F5F5F5;
    cursor: pointer;

    & svg {
      color: #000;
    }
  }
`;

export default function ObligationAutocomplete({
    defaultValue = '',
    options = [],
    onChange = () => null,
    labelField = "label",
    multiple = false,
    ...restProps
}) {

    const onChangeHandler = (event, data) => {
        if (!data) {
            onChange({label: '', value: 0});
        } else {
            onChange(data);
        }
    };

    const {
        getRootProps,
        getInputProps,
        getListboxProps,
        getOptionProps,
        groupedOptions,
    } = useAutocomplete({
        id: 'obligation-autocomplete',
        defaultValue: defaultValue,
        value: restProps.data,
        multiple: multiple,
        options: options,
        onChange: onChangeHandler,
        getOptionSelected: (option,option2) => {return JSON.stringify(option) === JSON.stringify(option2)},
        getOptionLabel: (option) => option[labelField],
    });

    return (
        <div>
            <div {...getRootProps()}>
                <InputWrapper>
                    <input {...getInputProps()} />
                </InputWrapper>

            </div>
            {groupedOptions.length > 0 ? (
                <Listbox {...getListboxProps()}>
                    {groupedOptions.map((option, index) => (
                        <li {...getOptionProps({ option, index })}>
                            <span>{option[labelField]}</span>
                            <CheckIcon fontSize="small" />
                        </li>
                    ))}
                </Listbox>
            ) : null}

        </div>
    );
}
