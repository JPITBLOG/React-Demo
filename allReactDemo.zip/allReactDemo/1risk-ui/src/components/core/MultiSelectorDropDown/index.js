import React, {Component} from 'react';
import {Button} from "react-bootstrap";

import './MultiSelectorDropDown.css';
import CheckboxIcon, {CHECKBOX_PARTIAL_SELECTED, CHECKBOX_SELECTED, CHECKBOX_UNSELECTED} from "../CheckBoxIcon";
import {ClickAwayListener} from "@material-ui/core";

class MultiSelectorDropDown extends Component{

    static defaultProps={
        placeholder:"Select an option",
        manySelectedPlaceholder: "%s options selected",
        singularSelectedPlaceholder: "%s option selected",
        options:[],
        value:[],
        onChange:()=> null,
        onClose:()=> null
    }

    constructor(props) {
        super(props);
        this.state={
            isOpen:false,
            isSelectedAll: false,
            selectedOptions:[],
            placeholder:this.props.placeholder
        }
        this.onButtonClickHandler = this.onButtonClickHandler.bind(this);
        this.onChangeAllClickHandler = this.onChangeAllClickHandler.bind(this);
        this.getOptionType = this.getOptionType.bind(this);
        this.getSelectAllType = this.getSelectAllType.bind(this);
        this.onClickAwayHandler = this.onClickAwayHandler.bind(this);
        this.getPlaceholderMessage = this.getPlaceholderMessage.bind(this);
    }

    componentDidUpdate(prevProps, prevState, snapshot): void {
        if(prevProps.value !== this.props.value){
            this.setState({selectedOptions:this.props.value})
        }
    }

    onButtonClickHandler(event){
        this.setState({isOpen:!this.state.isOpen});
        event.preventDefault();
    }

    onChangeAllClickHandler(event){

        const state = this.state;

        if(state.selectedOptions.length === this.props.options.length){
            state.selectedOptions = [];
        }else{

            if(state.selectedOptions.length ===0){
                state.selectedOptions = this.props.options;
            }
            if(state.selectedOptions.length < this.props.options.length){
                state.selectedOptions = [];
            }
        }

        this.setState(state)
        this.props.onChange(state.selectedOptions);
        event.preventDefault();

    }

    getOptionType(option){
        return this.state.selectedOptions.includes(option) ? CHECKBOX_SELECTED : CHECKBOX_UNSELECTED;
    }

    getPlaceholderMessage(){

        const state = this.state;

        if(state.selectedOptions.length === 1){
            return this.props.singularSelectedPlaceholder.replace(/%s/g,state.selectedOptions.length);
        }

        if(state.selectedOptions.length > 0){
           return this.props.manySelectedPlaceholder.replace(/%s/g,state.selectedOptions.length);
        }

        return this.props.placeholder;

    }

    onChangeOptionClickHandler(option){
        const state = this.state;
        if(state.selectedOptions.includes(option)){
            state.selectedOptions = state.selectedOptions.filter(selectedOption => selectedOption.value !== option.value)
        }else{
            state.selectedOptions.push(option);
        }
        this.setState(state);
        this.props.onChange(state.selectedOptions);
    }

    getSelectAllType(){
        if(this.state.selectedOptions.length ===0){
            return CHECKBOX_UNSELECTED;
        }
        if(this.state.selectedOptions.length < this.props.options.length){
            return CHECKBOX_PARTIAL_SELECTED;
        }
        return CHECKBOX_SELECTED;
    }

    onClickAwayHandler(event){
        const state = this.state;
        state.isOpen = false;
        this.setState(state);
        this.props.onClose(state.selectedOptions);
        event.preventDefault();
    }

    render(){
        return(
            <ClickAwayListener onClickAway={this.onClickAwayHandler}>
                <div className="multi-selector-dropdown">
                    <Button variant="dropdown" onClick={this.onButtonClickHandler}>
                        <span className="placeholder">{this.getPlaceholderMessage()}</span>
                    </Button>
                    {this.state.isOpen && <div className="list-container">
                        <ul>
                            <li onClick={this.onChangeAllClickHandler} key={`option-100000`}>
                                <CheckboxIcon type={this.getSelectAllType()}/>
                                <span className="option-label">
                                    {this.state.selectedOptions.length ===0 ? "Select" : "Unselect"} All
                                </span>
                            </li>
                            {this.props.options.map((option,index)=>{
                                return(
                                    <li onClick={()=>this.onChangeOptionClickHandler(option)} key={`option-${index}`}>
                                        <CheckboxIcon type={this.getOptionType(option)}/><span className="option-label">{option.label}</span>
                                    </li>
                                )
                            })}
                        </ul>
                    </div>}
                </div>
            </ClickAwayListener>);
    }
}

export default React.memo(MultiSelectorDropDown);