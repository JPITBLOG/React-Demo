import withStyles from "@material-ui/core/styles/withStyles";
import {Chip} from "@material-ui/core";

const AvatarChip = withStyles({
    root: {
        fontFamily: "Lato, sans-serif",
        fontSize: "14px",
        lineHeight: "20px"
    },
})(Chip);

export default (AvatarChip)