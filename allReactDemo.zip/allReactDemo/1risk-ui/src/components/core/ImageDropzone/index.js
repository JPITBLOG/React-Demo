import React, { useCallback, useEffect, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import PropTypes from 'prop-types';

import './ImageDropzone.css';
import FileUtil from "../../../util/FileUtil";
import IconButton from "../button/IconButton";
import SpinnerContainer from "../SpinnerContainer";
import {faCloudUploadAlt} from "@fortawesome/free-solid-svg-icons";
import ImageThumbnailContainer from "../ImageThumbnailContainer";

const ImageDropzone = ({fileMaxSize, isMultiple, acceptExtensions, minWidth, minHeight, imageUrl, loading,onLoad, onClear, infoText="Drop image here or "}) => {

    const [imageSrc, setImageSrc] = useState(null);
    const [errorMessage, setErrorMessage] = useState("");

    const mainClassName = "image-dropzone";

    useEffect(() => {
        if (imageUrl) {
            setImageSrc(imageUrl);
        }
    }, [imageUrl])

    const onClearHandler = (event) => {
        setImageSrc(null);
        onClear();
        event.preventDefault();
    }

    const onDrop = useCallback((acceptedFiles) => {
        acceptedFiles.forEach((file) => {

            const reader = new FileReader();

            const fileInfo = {
                name: file.name,
                lastModified: file.lastModified,
                size: file.size,
                type: file.type,
                path: file.path,
            }

            reader.onabort = () => console.log('file reading was aborted')
            reader.onerror = () => console.log('file reading has failed')
            reader.onload = () => {

                let image = new Image();
                image.src = reader.result;
                image.alt = "preload file";

                image.onload = function () {
                    if (this.height >= minHeight && this.width >= minWidth) {
                        setImageSrc(reader.result);
                    } else {
                        const message = "Invalid image resolution";
                        if (errorMessage !== message) {
                            setErrorMessage(message);
                        }
                    }
                };

                fileInfo.data = reader.result.split(",")[1];
                onLoad(fileInfo);

            }
            reader.readAsDataURL(file)
        })

    }, [errorMessage, minWidth, minHeight, onLoad])

    const {
        getRootProps,
        getInputProps,
        isDragActive,
        isDragReject,
        rejectedFiles
    } = useDropzone({ onDrop, accept: acceptExtensions, maxSize: fileMaxSize, multiple: isMultiple })

    if (rejectedFiles.length > 0) {
        let message = "";
        if (rejectedFiles[0].size > fileMaxSize) {
            message = `File is too big (max: ${FileUtil.formatBytes(fileMaxSize)})`;
        } else {
            message = `Invalid file format (${rejectedFiles[0].type})`;
        }
        if (errorMessage !== message) {
            setErrorMessage(message);
        }
    }

    if (imageUrl) {
        return (<div className={mainClassName}>
            <ImageThumbnailContainer alt="logo" src={imageSrc} />
            <div className="action-buttons"><IconButton onClick={onClearHandler} variant="link" icon="trash">Remove</IconButton></div>
        </div>);
    } else {
        return (
            <div className={mainClassName}>
                <div className="uploader" {...getRootProps()}>

                    <SpinnerContainer visible={loading} />

                    <input {...getInputProps()} />

                    <div className="icon"><FontAwesomeIcon fixedWidth icon={faCloudUploadAlt}/></div>

                    {!isDragActive && <p>{infoText} <span className="link">Browse</span></p>}

                    {errorMessage.length > 0 && <div className="error-message">{errorMessage}</div>}

                    {isDragReject && (<div className="error-message">Invalid file</div>)}

                    <ul className="instructions">
                        <li>PNG, JPG or JPEG formats are supported</li>
                        <li>Required resolution is 130x30 pixels or larger</li>
                        <li>Maximum file size limit is 5 MB</li>
                    </ul>


                </div>
            </div>
        )
    }

}

ImageDropzone.propTypes = {
    fileMaxSize: PropTypes.number,
    multiple: PropTypes.bool,
    acceptExtensions: PropTypes.string,
    minWidth: PropTypes.number,
    minHeight: PropTypes.number,
    loading: PropTypes.bool,
    imageUrl: PropTypes.string,
    onClear: PropTypes.func,
    onLoad: PropTypes.func
}

ImageDropzone.defaultProps = {
    fileMaxSize: 5242880,
    multiple: false,
    acceptExtensions: 'image/jpeg, image/png',
    minWidth: 30,
    minHeight: 30,
    loading: false,
    onLoad: () => null,
    onClear: () => null,
    imageUrl: null,
    isAttachment: false
}

export default React.memo(ImageDropzone);
