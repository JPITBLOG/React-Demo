import React from 'react';
import styled from "styled-components";

const Container = styled("div")`
    background-color: #F5F5F5;
    border-radius: 5px;
    border: 1px solid #CDD1D2;
    padding: 5%;
    text-align: center;
    display: flex;
    height: 100%;
    width: 100%;
    max-height: 200px;
    justify-content: center;
    align-items: center;
    position: relative;
`;

const Image = styled("img")`
    max-width:98%;
    max-height:190px;
    display: block;
`;

const ImageThumbnailContainer = ({children,...restProps})=>{
    return(<Container className="image-thumbnail-container">
        <Image {...restProps}>{children}</Image>
    </Container>)
}

export default ImageThumbnailContainer