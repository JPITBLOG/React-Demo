import React from "react";
import Card from "react-bootstrap/Card";
import Avatar from '@material-ui/core/Avatar';

import "./EntityInfoWidget.css";
import StringUtil from "../../../util/StringUtil";
import AvatarChip from "../AvatarChip";
import DateUtil from "../../../util/DateUtil";
import CardSection from "../CardSection";

const EntityInfoWidget = ({status="",ownerName="",recordId,ownerAvatar,createdAt,updatedAt,...restProps}) =>{

    const avatar = <Avatar src={ownerAvatar} className="orange">{StringUtil.toAcronym(ownerName)}</Avatar>;

    return(<div className="entity-info-widget">
        <Card>
            <Card.Header>Activity</Card.Header>
            <Card.Body>
              {status && <CardSection>
                    <Card.Title>Status</Card.Title>
                    <Card.Text className={status.toLowerCase()}>{status}</Card.Text>
                </CardSection>}
                <CardSection>
                    <Card.Title>Owner</Card.Title>
                    <div className="avatar-chip">
                        <AvatarChip avatar={avatar} label={ownerName}/>
                    </div>
                </CardSection>
                <CardSection>
                    <Card.Title>Created Date</Card.Title>
                    <Card.Text>{DateUtil.format(createdAt)} by {ownerName}</Card.Text>
                </CardSection>
                <CardSection>
                    <Card.Title>Last Modified Date</Card.Title>
                    <Card.Text>{DateUtil.format(updatedAt)} by {ownerName}</Card.Text>
                </CardSection>
            </Card.Body>
        </Card>
    </div>)
}

export default (EntityInfoWidget);