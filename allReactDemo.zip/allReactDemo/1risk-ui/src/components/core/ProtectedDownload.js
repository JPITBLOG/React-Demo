import React from "react";
import {useDispatch} from 'react-redux';
import {getDownloadAttachment} from '../../actions/';
import styled from 'styled-components';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";

const DownloadIcon = styled((props)=>{
    return(<FontAwesomeIcon {...props} fixedWidth/>)
})`
    font-size: 14px;
    margin-right: 5px;
    cursor: pointer;
`

const LinkElement = styled('span')`
    text-decoration: ${prop => prop.hover ? 'none' : 'underline'};;
    cursor: pointer;
`

const ProtectedDownload = ({label,referenceId,icon,hover=false,tableMeta='',customIdx = 0})=>{

    if(tableMeta!==''){
        const {rowData}=tableMeta;
        referenceId=rowData[customIdx];
    }
    
    const dispatch = useDispatch();

    const onClick = ()=>{
        dispatch(getDownloadAttachment(referenceId,(attachmentRes,err)=>{
            if (!err) {
                window.open(attachmentRes,"_blank");
            }
        }));
    }

    return(
        <div onClick={onClick}>
            {icon && <DownloadIcon icon={icon}/>}
            <LinkElement hover={hover}>{label}</LinkElement>
        </div>

    )


}

export default (ProtectedDownload);