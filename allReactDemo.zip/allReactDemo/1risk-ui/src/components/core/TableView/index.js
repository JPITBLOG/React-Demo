import React, {Component} from "react";
import Table from "react-bootstrap/Table";
import CheckboxIcon, {CHECKBOX_PARTIAL_SELECTED, CHECKBOX_SELECTED, CHECKBOX_UNSELECTED} from "../CheckBoxIcon";
import RadioButtonIcon from "../RadioButtonIcon";
import OrderListIcon from "../OrderListIcon";
import Label from "../Label";

import './TableView.css';
import ListPagination from "../ListPagination";
import NavColumnLabel from "../NavColumnLabel";
import PaginationUtil from "../../../util/PaginationUtil";
import withEventBus from "../withEventBus";
import PropTypes from "prop-types";

export const RESET_SELECTED_ITEMS = 'reset-selected-items';

class TableView extends Component{

    static defaultProps={
        items:[],
        columns:[],
        keyField:"id",
        defaultOrder:{
            columnId:0,
            direction:"ASC"
        },
        multiSelect:true,
        onOrderChange:(e)=>console.log(e),
        onSelectItem:(e)=>console.log(e),
        onPageChange:(e)=>console.log(e)
    }

    constructor(props) {
        super(props);
        this.state={
            name: props.name,
            items:props.items,
            allSelected:false,
            selectedItems:[],
            orderColumn: props.defaultOrder ? this.props.columns[0] : null,
            orderDirection: props.defaultOrder ? props.defaultOrder.direction : "ASC",
            localData: props.localData === true,
            pageItems: [],
            pageSize: 15,
            actualPage: 1
        }
        this.onSelectAllHandler = this.onSelectAllHandler.bind(this);
        this.onItemSelectHandler = this.onItemSelectHandler.bind(this);
        this.sortByColumn = this.sortByColumn.bind(this);
        this.getItems = this.getItems.bind(this);
        this.onPageChangeHandler = this.onPageChangeHandler.bind(this);
        this.localDataSort = this.localDataSort.bind(this);
        this.resetSelected = this.resetSelected.bind(this);
        this.getSelectAllType = this.getSelectAllType.bind(this);
    }

    onSelectAllHandler(){

        const state = this.state;

        if(state.selectedItems.length === this.props.items.length){
            state.selectedItems = [];
        }else{

            if(state.selectedItems.length ===0){
                state.selectedItems = this.props.items;
            }
            if(state.selectedItems.length < this.props.items.length){
                state.selectedItems = [];
            }
        }

        this.props.onSelectItem(state.selectedItems);
        this.setState(state);

    }

    onItemSelectHandler(selectedItem){
        const {keyField} = this.props;
        const state = this.state;
        const selected=this.state.selectedItems.filter(item=>item[keyField]===selectedItem[keyField]);
        if(selected.length>0){
            state.selectedItems=state.selectedItems.filter(item=>item[keyField]!==selectedItem[keyField]);
        }else{
            state.selectedItems.push(selectedItem);
        }
        if(!this.props.multiSelect){
            state.selectedItems=[selectedItem];
        }
        this.props.onSelectItem(state.selectedItems);
        this.setState(state);
    }

    getSelected(selectedItem){
        const {keyField} = this.props;
        const selected=this.state.selectedItems.filter(item=>item[keyField]===selectedItem[keyField]);
        return selected.length>0;
    }

    sortByColumn(column){

        if(column.orderDisabled){
            return;
        }

        const state = this.state;
        if(state.orderColumn.fieldName===column.fieldName){
            state.orderDirection= state.orderDirection === "ASC" ? "DESC" : "ASC";
        }else{
            state.orderColumn=column;
            state.orderDirection="ASC";
        }

        if(!state.localData){
            this.setState(state);
            this.props.onOrderChange(PaginationUtil.generatePaginationRequest(
                state.actualPage-1,
                state.pageSize,
                column.fieldName,
                state.orderDirection
            ));
        }else{
            this.setState(state);
            this.localDataSort();
        }


    }

    localDataSort(){

        console.log(this.state);

        const state = this.state;
        const {orderColumn,orderDirection} = this.state;

        state.actualPage=1;

        const compare=(a, b) =>{
            if (a[orderColumn.fieldName] > b[orderColumn.fieldName]) return 1;
            if (b[orderColumn.fieldName] > a[orderColumn.fieldName]) return -1;
            return 0;
        }

        let sortedItems = state.items.sort(compare).slice();
        if(orderDirection==="DESC"){
            sortedItems = sortedItems.reverse();
        }
        state.pageItems = sortedItems.slice(0,state.pageSize);

        this.setState(state);
    }

    componentDidMount() {
        const state = this.state;
        this.props.eventBus.addEventListener(RESET_SELECTED_ITEMS, this.resetSelected);
        
        if(state.localData){
          state.pageItems = state.items.slice(0,state.pageSize);
        }
        
        this.setState(state);
    }

    resetSelected (context) {
      const state = this.state;
      
      if(context.name === state.name) {
        state.allSelected = false;
        state.selectedItems = [];
      }
      this.setState(state);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if(prevProps.items!==this.props.items){
            this.setState({items:this.props.items});
        }
        
        if(prevProps.name !== this.props.name) {
          this.setState({name: this.props.name})
        }
    }

    getItems(){
        const {localData,items,pageItems} = this.state;
        if(localData){
            return pageItems;
        }
        return items;
    }

    onPageChangeHandler(event){

        const state = this.state;
        const {actualPage,pageSize} = event;

        state.actualPage = actualPage;

        if(state.localData){
            let startIdx = 0;
            if(event.actualPage>1){
                startIdx= (actualPage-1)*pageSize;
            }
            const endIdx = actualPage*pageSize;
            state.pageItems = state.items.slice(startIdx,endIdx);
            this.setState(state);
        }else{
            this.props.onPageChange(
                PaginationUtil.generatePaginationRequest(
                    actualPage-1,
                    pageSize,
                    state.orderColumn.fieldName,
                    state.orderDirection
                )
            );
        }
    }

    getSelectAllType(){
        if(this.state.selectedItems.length === 0){
            return CHECKBOX_UNSELECTED;
        }
        if(this.state.selectedItems.length < this.props.items.length){
            return CHECKBOX_PARTIAL_SELECTED;
        }
        return CHECKBOX_SELECTED;
    }

    render() {
        const items = this.getItems()
        const {orderColumn,orderDirection,actualPage,selectedItems} = this.state;
        const {columns,multiSelect} = this.props;
        return(
            <div className={`table-view ${this.props.className ? this.props.className : ""}`}>
                {items.length === 0  && <div>No records found</div>}
                {items.length > 0 && <div className="card-section">
                    <Table responsive="lg">
                        <thead>
                            <tr>
                                {columns.map((column,index)=>{
                                    if(index===0 && multiSelect){
                                        return(
                                            <th key={`col-${index}`} className={`table-col-${index}`}>
                                                <CheckboxIcon onClick={this.onSelectAllHandler} type={this.getSelectAllType()}/>
                                                <Label onClick={()=>this.sortByColumn(column)}>{column.name}<span className="selected-counter">{selectedItems.length > 0 ? ` (${selectedItems.length})` : ""}</span></Label>
                                                {orderColumn.fieldName === column.fieldName && <OrderListIcon onClick={()=>this.sortByColumn(column)} direction={orderDirection}/>}
                                            </th>
                                        );
                                    }else{
                                        return(
                                            <th key={`col-${index}`} className={`table-col-${index}`}>
                                                <Label onClick={()=>this.sortByColumn(column)}>{column.name}</Label>
                                                {orderColumn.fieldName === column.fieldName && <OrderListIcon onClick={()=>this.sortByColumn(column)} direction={orderDirection}/>}
                                            </th>);
                                    }
                                })}
                            </tr>
                        </thead>
                        <tbody>
                        {items.map((item,index)=>{
                            return(<tr key={`table-line-${index}`}>
                                {columns.map((column,colIndex)=>{
                                    if(colIndex===0){
                                        if(multiSelect){
                                            return(
                                                <td key={`row-${colIndex}`} className={`table-col-${colIndex}`}><CheckboxIcon onClick={()=>this.onItemSelectHandler(item)} selected={this.getSelected(item)}/>
                                                    <NavColumnLabel column={column} item={item}/>
                                                </td>
                                            )
                                        }else{
                                            return(
                                                <td key={`row-${colIndex}`} className={`table-col-${colIndex}`}><RadioButtonIcon onClick={()=>this.onItemSelectHandler(item)} selected={this.getSelected(item)}/>
                                                    <NavColumnLabel column={column} item={item}/>
                                                </td>
                                            )
                                        }

                                    }else{
                                        return(<td key={`row-${colIndex}`} className={`table-col-${colIndex}`}><NavColumnLabel column={column} item={item}/></td>)
                                    }
                                })}
                            </tr>)
                        })}
                        </tbody>
                    </Table>
                    <ListPagination actualPage={actualPage} totalRecords={this.props.totalItems} onPageChange={this.onPageChangeHandler} position="end"/>
                </div>}
            </div>
        )
    }
}

TableView.propTypes={
    items:PropTypes.array,
    columns: PropTypes.arrayOf(
        PropTypes.shape({
            name: PropTypes.string.isRequired,
            fieldName: PropTypes.string.isRequired,
            url: PropTypes.string,
            contentType: PropTypes.string
        })
    ),
    keyField: PropTypes.string,
    defaultOrder: PropTypes.shape({
        columnId: PropTypes.number,
        direction: PropTypes.string
    }),
    multiSelect: PropTypes.bool,
    onOrderChange: PropTypes.func,
    onSelectItem: PropTypes.func,
    onPageChange: PropTypes.func,
    onPrint: PropTypes.func,

}

export default withEventBus(TableView);