import styled from "styled-components";

const FormValue = styled.p`
    font-family: 'Lato', sans-serif;
    font-size: 14px;
    line-height: 17px;
`

export default FormValue;
