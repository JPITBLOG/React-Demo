import React from 'react'
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faCheckSquare, faMinusSquare} from "@fortawesome/free-solid-svg-icons";
import {faSquare} from "@fortawesome/free-regular-svg-icons";

export const CHECKBOX_SELECTED = "selected";
export const CHECKBOX_PARTIAL_SELECTED = "partial-selected";
export const CHECKBOX_UNSELECTED = "unselected"

const stateMap = new Map();
stateMap.set(CHECKBOX_SELECTED,{color:"#FA7C00",iconClass:faCheckSquare});
stateMap.set(CHECKBOX_PARTIAL_SELECTED,{color:"#FA7C00",iconClass:faMinusSquare});
stateMap.set(CHECKBOX_UNSELECTED,{color:"#494A4C",iconClass:faSquare});

function CheckboxIcon(props){

    const stateSelected = stateMap.get(props.type) === undefined ?
        (props.selected ?
            stateMap.get(CHECKBOX_SELECTED) : stateMap.get(CHECKBOX_UNSELECTED)) : stateMap.get(props.type);

    return (<FontAwesomeIcon style={{cursor:"pointer"}} className="checkbox-icon" onClick={props.onClick} color={stateSelected.color} fixedWidth icon={stateSelected.iconClass}/>);

}

export default (CheckboxIcon)