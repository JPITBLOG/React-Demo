/* eslint-disable no-use-before-define */
import React from 'react';
import useAutocomplete from '@material-ui/lab/useAutocomplete';
import NoSsr from '@material-ui/core/NoSsr';
import CheckIcon from '@material-ui/icons/Check';
import styled from 'styled-components';
import {faTimes} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";

const InputWrapper = styled('div')`
  width: 100%;
  border: 1px solid #d9d9d9;
  background-color: #fff;
  border-radius: 4px;
  padding: 1px;
  display: flex;
  flex-wrap: wrap;

  & input {
    font-family: 'Lato', sans-serif;
    font-size: 14px;
    height: 30px;
    box-sizing: border-box;
    padding: 4px 6px;
    width: 0;
    min-width: 30px;
    flex-grow: 1;
    border: 0;
    margin: 0;
    outline: 0;
  }
`;

const Tag = styled(({ label, onDelete, ...props }) => (
    <div {...props}>
        <span>{label}</span>
        {props.crossIcon && <FontAwesomeIcon fixedWidth icon={faTimes} onClick={onDelete} />}
    </div>
))`
  font-family: 'Lato', sans-serif;
  font-size: 14px;
  display: flex;
  align-items: center;
  height: 24px;
  margin: 2px;
  line-height: 22px;
  background-color: #e0e0e0;
  border: 1px solid #e8e8e8;
  border-radius: 5px;
  box-sizing: content-box;
  padding: 0 4px 0 10px;
  outline: 0;
  overflow: hidden;

  &:focus {
    border-color: #40a9ff;
    background-color: #e6f7ff;
  }

  & span {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }

  & svg {
    font-size: 22px;
    cursor: pointer;
    padding: 4px;
  }
`;

const Listbox = styled('ul')`
  font-family: 'Lato', sans-serif;
  font-size: 14px;
  width: 90%;
  margin: 2px 0 0;
  padding: 0;
  position: absolute;
  list-style: none;
  background-color: #fff;
  overflow: auto;
  max-height: 250px;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  z-index: 1;

  & li {
    padding: 5px 12px;
    display: flex;

    & span {
      flex-grow: 1;
    }

    & svg {
      color: transparent;
    }
  }

  & li[aria-selected='true'] {
    background-color: #fafafa;
    font-weight: 600;

    & svg {
      color: #1890ff;
    }
  }

  & li[data-focus='true'] {
    background-color: #F5F5F5;
    cursor: pointer;

    & svg {
      color: #000;
    }
  }
`;

export default function TagAutocomplete({
            defaultValue=[],
            options=[],
            onChange=()=>null,
            onTagCreated=()=>null,
            labelField="label",
            multiple=true,
            crossIcon=true,
            ...restProps
}) {

    const onChangeHandler = (event,value) =>{
        onChange({id:restProps?.id,value:value});
    }

    const {
        getRootProps,
        getInputProps,
        getTagProps,
        getListboxProps,
        getOptionProps,
        groupedOptions,
        value,
        focused,
        setAnchorEl,
    } = useAutocomplete({
        id: 'tag-autocomplete',
        defaultValue: defaultValue,
        value: restProps.value,
        multiple: multiple,
        options: options,
        onChange: onChangeHandler,
        onTagCreated: onTagCreated,
        getOptionSelected: (option,option2) => {return JSON.stringify(option) === JSON.stringify(option2)},
        getOptionLabel: (option) => option[labelField],
    });

    const onKeypressHandler = (event)=>{
        if(event.key==="Enter"){
            const value = event.target.value;
            const selectedTag = options.filter((option)=> option[labelField].toUpperCase() === value.toUpperCase());
            if(selectedTag.length===0){
                onTagCreated({id:restProps?.id,value:value});
            }
            event.preventDefault();
        }
    }

    return (
        <NoSsr>
            <div>
                <div {...getRootProps()}>
                    <InputWrapper ref={setAnchorEl} className={focused ? 'focused' : ''}>
                        {value.map((option, index) => (
                            <Tag crossIcon={crossIcon} label={option[labelField]} {...getTagProps({ index })} />
                        ))}

                        <input {...getInputProps()} onKeyPress={onKeypressHandler}/>
                    </InputWrapper>
                </div>
                {groupedOptions.length > 0 ? (
                    <Listbox {...getListboxProps()}>
                        {groupedOptions.map((option, index) => (
                            <li {...getOptionProps({ option, index })}>
                                <span>{option[labelField]}</span>
                                <CheckIcon fontSize="small" />
                            </li>
                        ))}
                    </Listbox>
                ) : null}
            </div>
        </NoSsr>
    );
}
