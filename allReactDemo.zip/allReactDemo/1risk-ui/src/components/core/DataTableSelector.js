import React from 'react';
import {Checkbox, FormControl, InputLabel, ListItemText, MenuItem, Select} from "@material-ui/core";

const DataTableSelector = ({optionValues,filterList,onChange,index,column})=>{

    const labelGenerator = (selected) =>{
        const selectedOptions = []
        selected.forEach((item)=>{
            selectedOptions.push(optionValues.filter((option)=> option.value === item)[0]);
        });
        return selectedOptions.map((option)=> option.label).join(', ');
    }

    if(optionValues === undefined){
        console.error(column.name," - no filter data for this column");
        optionValues=[];
    }

    return (
        <FormControl>
            <InputLabel htmlFor='select-multiple-chip'>
                {column.label}
            </InputLabel>
            <Select
                multiple
                value={filterList[index]}
                renderValue={selected => labelGenerator(selected)}
                onChange={event => {
                    filterList[index] = event.target.value;
                    onChange(filterList[index], index, column);
                }}
            >
                {optionValues.map(item => (
                    <MenuItem key={item.label} value={item.value}>
                        <Checkbox
                            color='primary'
                            checked={filterList[index].indexOf(item.value) > -1}
                        />
                        <ListItemText primary={item.label} />
                    </MenuItem>
                ))}
            </Select>
        </FormControl>
    );
}

export default (DataTableSelector)

