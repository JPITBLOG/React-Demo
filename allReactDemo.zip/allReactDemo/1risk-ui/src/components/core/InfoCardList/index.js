import React from 'react';
import InfoCard from "./InfoCard";

const InfoCardList = ({
                          items=[],
                          baseUrl="/",
                          actionField="id",
                          urlImageKey="imageUrl",
                          labelKey="label",
                          descriptionKey="description",
                          cardStyle={},
                          ...restProps}) => {

    const cards = items.map((item,index) =>
            <InfoCard style={cardStyle}
                      key={`info-card-${index}`}
                      urlLink={`${baseUrl}${item[actionField]}`}
                      imageUrl={item[urlImageKey]}
                      label={item[labelKey]}
                      description={item[descriptionKey]}
            />
        );

    return(<div className="row filter-content" {...restProps}>
        {cards}
    </div>);
}

export default (InfoCardList)