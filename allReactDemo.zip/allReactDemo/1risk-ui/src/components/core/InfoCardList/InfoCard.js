import React from "react";
import {Col,Image} from "react-bootstrap";
import {NavLink} from "react-router-dom";
import {DEFAULT_THUMBNAIL} from "../../../bundle/ImageBundle";

const InfoCard = ({urlLink="/",imageUrl="",label="",description="",...restProps}) =>{

    if(imageUrl===""){
        imageUrl=DEFAULT_THUMBNAIL;
    }

    return(<Col lg={4}>
        <div className="info-box effect-two" {...restProps}>
            <NavLink to={urlLink}>
                <div className="info-box-icon">
                    <Image src={imageUrl} alt={label} thumbnail/>
                </div>
                <div className="info-box-content">
                    <div className="info-content-left">
                        <h4>{label}</h4>
                        <p>{description}</p>
                    </div>
                </div>
            </NavLink>
        </div>
    </Col>)
}

export default (InfoCard)