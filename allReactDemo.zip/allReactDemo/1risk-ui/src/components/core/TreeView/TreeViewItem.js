import React, {Component} from "react";
import CollapseIcon from "../CollapseIcon";
import {Collapse} from "react-bootstrap";
import {connect} from "react-redux";
import {default as UUID} from 'uuid';

class TreeViewItem extends Component{

    static defaultProps = {
        expanded:false,
        labelKey: "label",
        valueKey: "value",
        onItemClick: (e) => console.log(`Item ${e} clicked`),
        onClick: (e) => console.log(e),
        item: {
            label: "",
            children: []
        },
        mappedItems: 0
    }

    constructor(props) {
        super(props);
        this.state={
            name:UUID.v4()
        }
        this.onClickHandler = this.onClickHandler.bind(this);
    }

    onClickHandler(){
        const {valueKey,item} = this.props;
        this.props.onClick(item[valueKey]);
    }

    render() {
        const {labelKey,valueKey,item,onItemClick,expanded} = this.props;
        return(
            <li>
                <div onClick={this.onClickHandler}><CollapseIcon expanded={expanded}/>
                    <span className="title">{item[labelKey]} ({item.children.length})</span></div>
                <Collapse in={expanded}>
                    <ul className="child">
                        {item.children.map((child,index)=>{
                            return(<li onClick={()=> onItemClick(child[valueKey])} key={`tree-sub-item-${index}`}>{child[labelKey]}</li>);
                        })}
                    </ul>
                </Collapse>
            </li>
        )
    }
}

const mapStateToProps=(state)=>{
    return({data:state.treeView.data});
}

export default connect(mapStateToProps)(TreeViewItem)