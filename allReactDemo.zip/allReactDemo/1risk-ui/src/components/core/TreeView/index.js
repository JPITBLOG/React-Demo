import React, {Component} from "react";
import {default as UUID} from "uuid";

import './TreeView.css';
import TreeViewItem from "./TreeViewItem";
import * as actions from "../../../actions/TreeViewActions"
import {connect} from 'react-redux';

class TreeView extends Component{

    static defaultProps={
        name:UUID.v4(),
        items:[],
        labelKey:"label",
        valueKey:"value",
        displayExpandButton:true
    }

    constructor(props) {
        super(props);
        this.state={
            expandedItems:[],
            expandAll:false,
            name:props.name
        }
        this.toggleExpanded = this.toggleExpanded.bind(this);
    }

    toggleExpanded(idx){

        const state = this.state;

        const expanded = state.expandedItems.filter(value => value===idx)[0];
        if(expanded=== undefined || !expanded){
            state.expandedItems.push(idx);
            this.props.treeViewItemCollapse(true,idx);
        }else{
            state.expandedItems=state.expandedItems.filter(value => value!==idx);
            this.props.treeViewItemCollapse(false,idx);
        }

        this.setState(state);

    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if(prevProps.data!==this.props.data){
            const {parentId,expanded} = this.props.data;
            if(parentId && parentId.toString()===this.state.name.toString()){
                this.setExpandedAll(expanded);
            }
        }
    }

    setExpandedAll(flag){

        const state = this.state;

        if(flag){
            this.props.items.forEach((item)=>{
                state.expandedItems.push(item.value);
        });
        }else{
            state.expandedItems=[];
        }

        this.setState(state);
    }

    isExpanded(idx){
        const state = this.state;
        const selected = state.expandedItems.filter(value => value===idx)[0];
        if(selected){
            return true;
        }
        return false;
    }

    render(){
        const {items,labelKey,valueKey,onItemClick} = this.props;
        return(<div className="tree-view">
            <ul>
                {items.map((item,index)=>{
                     return(<TreeViewItem key={`tree-view-item-${index}`}
                         expanded={this.isExpanded(item.value)}
                         onClick={this.toggleExpanded}
                         item={item}
                         labelKey={labelKey}
                         valueKey={valueKey}
                         parentName={this.state.name}
                         onItemClick={onItemClick}
                     />)
                })}
            </ul>
        </div>);
    }

}

const mapStateToProps=(state)=>{
    return({data:state.treeView.data});
}

export default connect(mapStateToProps,actions)(TreeView)