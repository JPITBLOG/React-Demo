import React from 'react';
// import ExternalLink from "../ExternalLink"
import Label from "../Label";
import NavUnderlineLink from "../NavUnderlineLink";

const DataTableIDLink = ({value,uri="",tableMeta,newTab=false,valueIdx=0}) =>{
    const {rowData} = tableMeta;
    const link = `${uri}/${rowData[valueIdx]}`

    // CP2-274 - Do not open a new tab anymore
    // if(newTab){
    //     return(<ExternalLink tab to={link}><Label>{value}</Label></ExternalLink>)
    // }else{
        return(<NavUnderlineLink to={link}><Label>{value}</Label></NavUnderlineLink>)
    // }
}

export default (DataTableIDLink)