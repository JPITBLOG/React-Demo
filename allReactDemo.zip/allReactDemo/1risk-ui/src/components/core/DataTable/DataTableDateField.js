import React from "react";
import DateUtil from "../../../util/DateUtil";

const DataTableDateField = ({value,...restProps}) =>{
    return(<div {...restProps} className="data-table-date-field">{DateUtil.format(value)}</div>)
}

export default DataTableDateField;