import React, {useState} from "react";
import MUIDataTable from "mui-datatables";
import {createMuiTheme, MuiThemeProvider} from "@material-ui/core/styles";
import {CircularProgress} from "@material-ui/core";

import "./DataTablePrint.css";
import PaginationUtil from "../../../util/PaginationUtil";
import ObjectUtil from "../../../util/ObjectUtil";

const DataTable = ({
                       loading,
                       columns=[],
                       options,
                       onFilterChange=()=>null,
                       onPaginationChange=()=>null,
                       onSelected=()=>null,
                       page,
                       data,
                       totalRecords=0,
                       isPrinting=false,
                       title,
                       ...restProps}) =>{

    const columnSize = columns?.length;

    if(page){
        data=page?.items;
        totalRecords=page?.totalRecords;
    }

    const [displayColumn,setDisplayColumns] = useState(columns.map((col)=>col.options.display));
    const [pagination,setPagination] = useState(PaginationUtil.generatePaginationRequest(0,50));
    const [sortDirection,setSortDirection] = useState(PaginationUtil.initSortColumns(columnSize));
    const [filterList,setFilterList] = useState(PaginationUtil.initFilterLists(columnSize));
    const [rowsSelected,setRowsSelected] = useState([]);

    const getSortDirection=(col)=>{
        const {options} = col;
        switch (options.sortDirection) {
            case "none":
                return "desc";
            case "desc":
                return "asc";
            case "asc":
                return "desc";
            default:
                return "none";
        }
    }

    let _columns = []
    let colInit = sortDirection.includes("desc") || sortDirection.includes("asc");

    const populateColumns = ()=>{
        _columns = ObjectUtil.clone(columns);
        _columns.forEach((col,idx)=>{
            // Sort start
            if(!colInit && col.options.display!=="excluded"){
                sortDirection[idx]="desc";
                colInit=true;
            }
            col.options.sortDirection=sortDirection[idx];
            col.options.display=displayColumn[idx];
            if(col.options.filter){
                col.options.filterList=filterList[idx];
            }
            if(columns[idx].options.customBodyRender){
                col.options.customBodyRender = columns[idx].options.customBodyRender;
            }
            if(columns[idx].options.filterOptions){
                col.options.filterOptions = columns[idx].options.filterOptions;
                col.options.filterList=filterList[idx];
                col.options.filter=true;
            }
            // Sort end
        });
    }

    if(columns.length>0){
        populateColumns();
    }

    const getMuiTheme = () => createMuiTheme({
        overrides: {
            MUIDataTable:{
                responsiveStacked:{
                    overflowY: "scroll",
                    zIndex: 1
                },
                responsiveScrollFullHeight: {
                    height:"auto"
                }
            },
            MuiTypography: {
                root:{
                    fontFamily: "'Lato', sans-serif",
                },
                body1:{
                    fontFamily: "'Lato', sans-serif",
                    fontSize: "14px",
                    color: "#494A4C"
                }
            },
            MuiFormLabel:{
                root:{
                    fontFamily: "'Lato', sans-serif",
                    fontSize: "14px",
                    color: "#494A4C"
                }
            },
            MuiButton:{
                textPrimary:{
                    color:"#494A4C"
                }
            },
            MuiInputLabel:{
                root:{
                    "&$focused":{
                        color: "#494A4C"
                    }
                },
                formControl:{
                    fontFamily: "'Lato', sans-serif",
                    color: "#494A4C"
                }
            },
            MUIDataTableToolbar: {
                titleText:{
                    fontFamily: "'Lato', sans-serif",
                    color: "#494A4C",
                    fontWeight: "bold"
                },
                icon:{
                    '&:hover':{
                        color: "#494A4C"
                    },
                    '&:active':{
                        color: "#494A4C"
                    },
                    '&:focus':{
                        color: "#494A4C"
                    }
                }
            },
            MUIDataTableFilter: {
                root:{
                    minWidth: "500px !important",
                    fontFamily: "'Lato', sans-serif",
                    fontSize: "14px",
                    color: "#494A4C"
                },
                checkbox:{
                    '&$checked': {
                        color: '#FE9023',
                    }
                },
                checkboxIcon:{
                    '&$checked': {
                        color: '#FE9023',
                    },
                    '& svg':{
                        fontSize: "17px"
                    }
                }
            },
            MUIDataTableSelectCell: {
                root:{
                    width: "35px",
                    padding: "0 0 0 20px"
                },
                checkboxRoot: {
                    fontSize: "10px",
                    '&$checked': {
                        color: '#FE9023',
                    },
                    '& svg':{
                        fontSize: "17px"
                    }
                },
            },
            MUIDataTableBodyCell: {
                root: {
                    fontFamily: "'Lato', sans-serif",
                    fontSize: "14px",
                    color: "#494A4C",
                    padding: "10px",
                    whiteSpace: "nowrap"
                }
            },
            MUIDataTableHeadCell: {
                root: {
                    fontFamily: "'Lato', sans-serif",
                    fontSize: "12px",
                    fontWeight: "bold",
                    textTransform: "uppercase",
                    color: "#494A4C",
                    whiteSpace: "nowrap"
                }
            },
            MuiCheckbox: {
                root: {
                    fontSize: "17px"
                }
            }
        },
    });

    const onSortHandler = (tableState)=>{

        const columnToSort = _columns[tableState.activeColumn];
        const direction = getSortDirection(columnToSort);
        const _sortDirection = PaginationUtil.initSortColumns(columnSize);
        _sortDirection[tableState.activeColumn] = getSortDirection(columnToSort);

        pagination.columnName=columnToSort.name;
        pagination.columnDirection=direction;
        setPagination(pagination);
        setSortDirection(_sortDirection);
        onPaginationChange(pagination);

    }

    let selectTimeout;

    let _options = {
        rowHover: false,
        search: false,
        print: false,
        download: false,
        filterType: 'multiselect',
        filter: true,
        responsive: isPrinting ? 'scrollFullHeight':'stacked',
        serverSide: true,
        count: totalRecords,
        page: 0,
        rowsPerPage: 50,
        disableToolbarSelect: true,
        rowsSelected: rowsSelected,
        rowsPerPageOptions:[50,100,200,500,1000,2000],
        onTableChange: (action, tableState) => {
            switch (action) {
                case 'columnViewChange':
                    setDisplayColumns(tableState.columns.map((col)=>col.display));
                    break;
                case 'changePage':
                    pagination.page=tableState.page;
                    setPagination(pagination);
                    onPaginationChange(pagination);
                    break;
                case 'changeRowsPerPage':
                    pagination.pageSize=tableState.rowsPerPage;
                    setPagination(pagination);
                    onPaginationChange(pagination);
                    break;
                case 'sort':
                    onSortHandler(tableState);
                    break;
                case 'resetFilters':
                    setFilterList(PaginationUtil.initFilterLists(15));
                    break;
                case 'onFilterDialogClose':
                    const _filterList = tableState.filterList;
                    setFilterList(_filterList);
                    const activeFilters = PaginationUtil.parseDataTableFilters(_columns,_filterList);
                    onFilterChange(activeFilters);
                    break;
                case 'rowsSelect':
                    clearTimeout(selectTimeout);
                    const selectedIndexes = tableState.selectedRows.data.map((row)=> row.index);
                    const selectedData = data.filter((item,idx)=> selectedIndexes.includes(idx));
                    selectTimeout=setTimeout(()=>{
                        setRowsSelected(selectedIndexes);
                        onSelected(selectedData);
                    },150);
                    break;
                default:
                    // console.log(action,tableState);
                    break;
            }
        }
    };

    if(options){
        _options = Object.assign(_options,options);
    }

    const loadingComponent = (
        <div style={{position: 'absolute', zIndex: 110, top: 0, left: 0, width: '100%',display: "flex", justifyContent: "center", height: '100%', background: 'rgba(255,255,255,0.8)'}}>
            <CircularProgress size={50} style={{marginTop:"100px", color:"#FE9023"}}/>
        </div>
    );


    return(<MuiThemeProvider theme={getMuiTheme()}>
            {loading && loadingComponent}
            <MUIDataTable {...restProps}
                          data={data}
                          columns={_columns}
                          options={_options}
                          title={title}
            />
    </MuiThemeProvider>)


}

export default DataTable