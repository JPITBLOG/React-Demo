import React from "react";
import styled from "styled-components";

const DataTableDescriptionField = styled(({value,width,...restProps})=> <div {...restProps}>{value.replace(/(<([^>]+)>)/ig,"")}</div>)`
    white-space: nowrap;
    min-width: 50%;
    max-width: ${props => props.width ? props.width : "800px"};
    overflow: hidden;
    text-overflow: ellipsis;
`

export default DataTableDescriptionField;