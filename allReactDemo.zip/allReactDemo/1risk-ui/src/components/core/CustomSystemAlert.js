import React, {useEffect, useState} from 'react';
import {Alert} from "react-bootstrap";
import {useDispatch, useSelector} from "react-redux";
import styled from "styled-components";
import {resetSystemMessage} from "../../actions";

const CustomAlertContainer = styled(({children,...restProps})=><Alert {...restProps}>{children}</Alert>)`
    font-size:14px;
    font-family: 'Lato', sans-serif;
    font-weight: bold;
`

const CustomSystemAlert = (props)=>{

    const dispatch = useDispatch();
    const [visible,setVisible] = useState(false);
    const systemMessage = useSelector(state => state.systemMessage.data);
    const {type,message} = systemMessage;


    useEffect(()=>{
        if(systemMessage.message.length>0){
            setVisible(true);
        }
    },[systemMessage,setVisible])

    const onCloseHandler = (event)=>{
        setVisible(!visible);
        dispatch(resetSystemMessage());
    }

    if(visible){
        return(
            <div className="custom-system-alert">
                <CustomAlertContainer dismissible variant={type} {...props} onClose={onCloseHandler}>{message}</CustomAlertContainer>
            </div>
        )
    }

    return null;

}

export default (CustomSystemAlert);