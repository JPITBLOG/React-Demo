import React from "react";
import FileUtil from "../../util/FileUtil";
import ProtectedDownload from "./ProtectedDownload";
import {faDownload} from "@fortawesome/free-solid-svg-icons";

const FileLink = ({fileName,fileSize,referenceId,...restProps})=>{

    const label = `${fileName} (${FileUtil.formatBytes(fileSize)})`;

    return(<span {...restProps} className="file-link">
        <ProtectedDownload icon={faDownload} label={label} referenceId={referenceId} hover={true}/>
    </span>)
}

export default (FileLink);