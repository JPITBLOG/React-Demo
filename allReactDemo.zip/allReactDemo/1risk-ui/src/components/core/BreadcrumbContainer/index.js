import React, {Component} from "react";
import {Breadcrumb} from "react-bootstrap";
import {LinkContainer} from 'react-router-bootstrap'

import "./BreadcrumbContainer.css";
import {connect} from "react-redux";
import BreadcrumbUtil from "../../../util/BreadcrumbUtil";

class BreadcrumbContainer extends Component{

    constructor(props) {
        super(props);
        this.state={
            stack:[],
            title: "Apps"
        }
        this.mounted=false;
        this.initStack = this.initStack.bind(this);
        this.addToStack = this.addToStack.bind(this);
        this.onItemClickHandler = this.onItemClickHandler.bind(this);
        this.prepareStack = this.prepareStack.bind(this);
        this.updateEditStack = this.updateEditStack.bind(this);
    }

    addToStack(event){

        const state = this.state;

        if(event.title){
            state.title=event.title;
        }

        if(state.stack.length===0){
            this.prepareStack(event,state.stack);
        }

        state.stack = this.updateEditStack(event,state.stack);

        if(!event.uri.includes("edit")){
            state.stack = state.stack.filter((item)=> !item.uri.includes("edit"));
        }

        if(!event.uri.includes("new")){
            state.stack = state.stack.filter((item)=> !item.uri.includes("new"));
        }

        const exists = state.stack.filter((item)=>item.uri === event.uri);
        if(exists.length===0){
            state.stack.push(event);
        }else{

            // Validate if I got it back

            let urlIndex=0;
            for(let i=0; i < state.stack.length; i++){
                if(state.stack[i].uri===event.uri){
                    urlIndex=i;
                }
            }

            if(urlIndex<state.stack.length){
                state.stack = state.stack.slice(0,urlIndex+1);
            }

        }

        this.setState(state);
    }

    prepareStack(event,stack){

        const uriParts = event.uri.split("/");
        uriParts.pop();
        const preStack = [];
        uriParts.forEach(uri => {
            if(uri!==""){
                preStack.push(uri);
                const uriLink = "/"+preStack.join("/").toString();
                const label = BreadcrumbUtil.getLabelByUrl(uriLink,this.props.menuItems);
                if(label!==""){
                    const prevLink={
                        title:event.title,
                        label: label,
                        uri: uriLink
                    }
                    stack.push(prevLink);
                }
            }
        })

    }

    updateEditStack(event,stack){

        if(event.uri.includes("edit")){

            if(stack[stack.length-1].url===event.url){
                stack = stack.filter((item)=>
                    (item.uri && !item.uri.includes("edit")) ||
                    (item.label && !item.label.toLowerCase().includes("edit"))
                );
            }

            const uris = event.uri.split("/").filter((uri)=> uri!=="edit");
            const prevLink={
                title:event.title,
                label: event.label,
                uri: uris.join("/")
            }
            if(event.label===prevLink.label){
                event.label="Edit"
            }
            else{
                stack.push(prevLink);
                event.label="Edit";
            }
        }

        // Fix duplications for Edit
        stack = stack.filter((item,idx)=> {
            if(item.label.toLowerCase()==="edit" && idx < stack.length){
                return false;
            }
            return true;
        })

        return stack;

    }

    initStack(event){

        const state = this.state;

        state.title=event.title;
        state.stack=[];

        this.prepareStack(event,state.stack);

        state.stack = state.stack.filter((item,idx)=> {
            if(item.label.toLowerCase()==="new" && idx < state.stack.length){
                return false;
            }
            return true;
        })

        state.stack.push(event);

        this.setState(state);

    }

    onItemClickHandler(event,selectedIndex){
        if(this.mounted){
            const state = this.state;
            state.stack = state.stack.filter((value,index) => index <= selectedIndex);
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot): void {
        if(prevProps.breadcrumbData!==this.props.breadcrumbData){

            const {prev,init} = this.props.breadcrumbData;
            const {breadcrumbData} = this.props;

            if(init){
                this.initStack(breadcrumbData);
            }else{
                if(prev){
                    if(prev.init){
                        this.initStack(this.props.breadcrumbData.prev);
                    }else{
                        this.addToStack(this.props.breadcrumbData);
                    }
                }
                this.addToStack(this.props.breadcrumbData);
            }
        }
    }

    render(){
        const {stack} = this.state;
        return(
            <div className="breadcrumb-container">
                {stack.length > 0 &&
                    <Breadcrumb>
                        {stack.map((breadcrumb,index)=>{
                            if(index === (stack.length -1)){
                                return(<Breadcrumb.Item key={`breadcrumb-item-${index}`} active>{breadcrumb.label}</Breadcrumb.Item>)
                            }else{
                                return(<LinkContainer
                                            to={breadcrumb.uri} key={`breadcrumb-item-${index}`}
                                            onClick={(e)=>this.onItemClickHandler(e,index)}>
                                    <Breadcrumb.Item>{breadcrumb.label}</Breadcrumb.Item>
                                </LinkContainer>);
                            }
                        })}
                    </Breadcrumb>}
            </div>
        )
    }
}

const mapStageToProps = (state)=>{
    return({
        breadcrumbData:state.page.breadcrumbData,
        menuItems: state.menu.menuItems,
    });
}

export default connect(mapStageToProps,null)(BreadcrumbContainer);