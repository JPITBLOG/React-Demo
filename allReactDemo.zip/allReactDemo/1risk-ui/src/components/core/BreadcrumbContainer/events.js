export const BREADCRUMB_ADD_STACK = "breadcrumb-add-stack";
export const BREADCRUMB_INIT_STACK = "breadcrumb-init-stack";