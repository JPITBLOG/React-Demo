import React, {Component} from 'react';
import {faPlus, faSearch} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {Button, Col, Row} from "react-bootstrap";
import withEventBus from "../withEventBus";
import UUIDUtil from "../../../util/UUIDUtil";

import './SearchOnType.css';

export const SEARCH_ON_TYPE_RESET = "search-on-type-reset"

class SearchOnType extends Component{

    static defaultProps={
        onChange:()=>null,
        onAddClick:()=>null,
        name: UUIDUtil.v4(),
        showButton:true
    }

    constructor(props) {
        super(props);
        this.state={
            name:props.name,
            value:""
        }
        this.onChangeHandler=this.onChangeHandler.bind(this);
        this.onAddClickHandler = this.onAddClickHandler.bind(this);
    }

    componentDidMount() {

        const _self=this;

        this.props.eventBus.addEventListener(SEARCH_ON_TYPE_RESET,function(event){
            if(event===_self.state.name){
                const returnValue =  {name:"searchText",value:""};
                _self.setState({value:""});
                _self.props.onChange(returnValue);
            }
        })

    }

    onChangeHandler(event){

        const elementValue = event.target.value;

        if(elementValue === this.state.value){
            return
        }

        const returnValue =  {name:"searchText",value:elementValue};

        if(elementValue.length > 2){
            setTimeout(() => {
                this.props.onChange(returnValue);
            }, 300);
        }

        if(elementValue.length === 0){
            returnValue.value="";
            this.props.onChange(returnValue);
        }

        this.setState({value:elementValue});

    }

    onAddClickHandler(event){
        event.preventDefault();
        this.props.onAddClick();
    }

    render() {
        const {showButton} = this.props;
        return(<div className={`${showButton? "search-on-type":"search-no-button"}`}>
            <Row>
            <Col lg={12} className="form-group search-field">
                <FontAwesomeIcon fixedWidth icon={faSearch}/>
                <input onKeyDown={this.onChangeHandler} onChange={this.onChangeHandler} onBlur={this.onChangeHandler} type="text" className="form-control"
                       placeholder="Search by keywords…" value={this.state.value}/>
                {showButton && <Button onClick={this.onAddClickHandler} className="add-new-btn"><FontAwesomeIcon icon={faPlus}/> Add New</Button>}
            </Col>
        </Row>
        </div>)
    }
}

export default withEventBus(SearchOnType)