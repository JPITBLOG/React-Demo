import React from 'react';
import {faAngleLeft, faAngleRight} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";

const NavigationArrowIcon = (props) =>{

    const onClickHandler = (event) =>{
        if(!props.disabled){
            props.onClick(event,props.direction === "right");
        }
    }

    const icon = props.direction === "right" ? faAngleRight : faAngleLeft;
    return(<FontAwesomeIcon style={{cursor:"pointer"}}
                         onClick={onClickHandler}
                         color={ props.disabled ? "#d2d2d2": "#666666" }
                         icon={icon}/>);

}

export default (NavigationArrowIcon);