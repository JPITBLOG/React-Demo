import React, {Component} from 'react';
import {Row,Col} from 'react-bootstrap';
import _ from 'lodash';

import './ListPagination.css';
import NavigationArrowIcon from "./NavigationArrowIcon";
import NakedSelector from "../NakedSelector";
import ArrayUtil from "../../../util/ArrayUtil";

class ListPagination extends Component{

    static defaultProps={
        totalRecords:0,
        pageSize: 15,
        pageSizes:[15,25,50,100,200],
        onPageChange:(e)=>console.log(e),
        position:"center"
    }

    constructor(props) {
        super(props);
        this.state={
            actualPage:1,
            totalRecords:props.totalRecords,
            pageSize: props.pageSize,
            pageSizes:props.pageSizes,
            prevIconDisabled:true,
            nextIconDisabled:false,
            selectExpanded:false,
        }

        this.onNavigationClickHandler = this.onNavigationClickHandler.bind(this);
        this.onSelectHandler = this.onSelectHandler.bind(this);
        this.onPageChangeHandler = this.onPageChangeHandler.bind(this);
    }

    static getDerivedStateFromProps(props,state) {
        state.totalRecords=props.totalRecords;
        state.pageSizes=ArrayUtil.parseToDropdownCollection(props.pageSizes);
        state.onPageChange=props.onPageChange;
        return state;
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if(prevProps.actualPage!==this.props.actualPage){
            if(this.props.actualPage===1){
                this.onSelectHandler(this.state.pageSize);
            }
        }
    }

    onSelectHandler(value){

        const state = this.state;

        state.actualPage=1;
        state.pageSize=parseInt(value);
        state.prevIconDisabled=true;

        if(state.pageSize >= state.totalRecords){
            state.nextIconDisabled=true;
        }else{
            state.nextIconDisabled=false;
        }

        this.onPageChangeHandler();
        this.setState(state);

    }

    onNavigationClickHandler(event, next){

        const state = this.state;

        const totalPages = Math.ceil(state.totalRecords/state.pageSize);

        if(next){
            if(state.actualPage >= 1 && state.actualPage < totalPages){
                state.actualPage++
            }
        }else{
            if(state.actualPage > 1){
                state.actualPage--;
            }
        }

        if(state.actualPage === totalPages){
            state.nextIconDisabled = true;
        }else{
            state.nextIconDisabled = false;
        }

        if(state.actualPage===1){
            state.prevIconDisabled=true;
        }else{
            state.prevIconDisabled=false;
        }

        this.onPageChangeHandler();

        this.setState(state);

    }

    onPageChangeHandler(){
        const {actualPage,pageSize} = this.state
        this.props.onPageChange({
            actualPage: actualPage,
            pageSize: pageSize
        });
    }

    renderPaginationState(){

        const {actualPage,totalRecords,pageSize} = this.state;

        const paginationLabel = _.template('<%= actualRecord %>-<%= nextRecords %> of <%= totalRecords %>');

        const templateContext = {
            actualRecord:actualPage,
            nextRecords: pageSize,
            totalRecords: totalRecords
        }

        templateContext.actualRecord = (actualPage-1) * pageSize;
        templateContext.nextRecords = templateContext.actualRecord+pageSize;

        if(templateContext.actualRecord < 1){
            templateContext.actualRecord=1;
        }

        if(templateContext.nextRecords > totalRecords){
            templateContext.nextRecords = totalRecords;
        }

        return(paginationLabel(templateContext));

    };

    render() {
        const {prevIconDisabled,nextIconDisabled,pageSizes} = this.state;
        return(<div className="list-pagination">
            <Row className={`d-flex justify-content-${this.props.position}`}>
                <Col lg="auto" className="pagination-label">
                    Rows per page:
                </Col>
                <Col lg="auto" className="selector">
                    <NakedSelector onSelect={this.onSelectHandler} options={pageSizes}/>
                </Col>
                <Col lg="auto" className="page-state-label">
                    {this.renderPaginationState()}
                </Col>
                <Col lg={1} className="nav-actions">
                    <span className="prev-icon">
                        <NavigationArrowIcon onClick={this.onNavigationClickHandler} disabled={prevIconDisabled}/>
                    </span>
                    <span className="next-icon">
                        <NavigationArrowIcon onClick={this.onNavigationClickHandler} disabled={nextIconDisabled} direction="right"/>
                    </span>
                </Col>
            </Row>
        </div>);
    }
}

export default (ListPagination);