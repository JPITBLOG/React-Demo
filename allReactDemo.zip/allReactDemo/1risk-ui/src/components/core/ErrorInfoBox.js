import React,{Component} from 'react';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faExclamationCircle} from "@fortawesome/free-solid-svg-icons";

export default class ErrorInfoBox extends Component{

    constructor(props) {
        super(props);
        this.state={
            display: false ,
            errorMessage: "Error"
        }
    }

    static getDerivedStateFromProps(props,state){
        state.display = props.display;
        state.errorMessage = props.message;
        return state;
    }

    render() {
        if(this.state.display){
            return (
                <div className="error-message">
                    <FontAwesomeIcon color="#FF0000" icon={faExclamationCircle}/>
                    <span className="message">{this.state.errorMessage}</span>
                </div>
            );
        }else{
            return(null);
        }
    }
}