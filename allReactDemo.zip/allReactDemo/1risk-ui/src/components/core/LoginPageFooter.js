import React,{Component} from 'react';
import {connect} from "react-redux";
import * as actions from "../../actions";

class LoginPageFooter extends Component{

    renderCurrentYear(){
        const currentDate = new Date();
        return currentDate.getFullYear();
    }

    render() {
        return(
            <footer className="footer-section">
                <div className="container">
                    <div className={this.props.phoneFragment ? `row justify-content-center` : "row footer-copyright"}>
                        <div className="footer-bottom text-center">
                            <p>&copy;2015-{this.renderCurrentYear()} <a href="https://www.cb1security.com/">CyberOne Security Inc. <b>All Rights Reserved.</b></a></p>
                        </div>
                    </div>
                </div>
            </footer>
        )
    }
}

function mapStateToProps(state){
    return {
        authenticated: state.auth.authenticated,
        phoneFragment: state.auth.phoneFragment
    };
}

export default connect(mapStateToProps,actions)(LoginPageFooter)