import React from "react";
import styled from "styled-components";
import {NavLink} from "react-router-dom";

const NavUnderlineLink = styled(({children,...restProps})=><NavLink {...restProps}>{children}</NavLink>)`
    text-decoration: underline;
    color: #494A4C;
    
    &:hover{
        color: #494A4C;
    }
`;

export default NavUnderlineLink;