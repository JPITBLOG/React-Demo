import React, {useEffect, useRef, useState} from "react";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faSearch, faTimesCircle} from "@fortawesome/free-solid-svg-icons";
import styled from 'styled-components';

export const SEARCH_ON_TYPE_RESET = "search-on-type-reset"

const Container = styled('div')`
    width: 100%;
    position: relative;
    margin-bottom: 15px;
`

const SearchIcon = styled((props)=><FontAwesomeIcon {...props} fixedWidth icon={faSearch}/>)`
    position: absolute;
    left: 10px;
    top: 12px;
    background: transparent;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
`

const ResetIcon = styled((props)=><FontAwesomeIcon {...props} fixedWidth icon={faTimesCircle}/>)`
    position: absolute;
    right: 10px;
    top: 12px;
    background: transparent;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
`

const SearchInput = styled('input')`
    height: 38px;
    line-height: 36px;
    border: 1px solid #CDD1D2;
    background: #fff;
    padding: 10px 10px 10px 35px;
    border-radius: 5px;
    color: #494A4C;
    &:focus{
        border: 1px solid #ced4da;
        border-color: #ced4da;
        box-shadow: none;
    }
`

const SearchOnTypeV2 = ({defaultValue="",onChange=()=>null})=>{

    const [value,setValue] = useState("");

    let timeout;

    const inputRef = useRef();

    useEffect(() => {
        setValue(defaultValue);
    },[defaultValue]);

    const onChangeHandler = (event) =>{

        const elementValue = event.target.value;

        if(elementValue === value){
            return
        }

        const returnValue =  {name:"searchText",value:elementValue};

        clearTimeout(timeout);

        timeout=setTimeout(()=>{
            onChange(returnValue);
            setValue(elementValue);
        },300);

    }

    const resetOnClickHandler = (event) =>{
        inputRef.current.value="";
        const returnValue =  {name:"searchText",value:""};
        setValue("");
        onChange(returnValue);
        event.preventDefault();
    }

    return(
        <Container className="search-on-type-v2">
            <SearchIcon/>
            <SearchInput ref={inputRef} onKeyUp={onChangeHandler} onChange={onChangeHandler} type="text" className="form-control"
               placeholder="Search by keywords…" defaultValue={value}/>
            <ResetIcon onClick={resetOnClickHandler}/>
        </Container>
    )
}

export default (SearchOnTypeV2);