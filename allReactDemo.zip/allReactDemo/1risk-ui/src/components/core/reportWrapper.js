import React, {Component} from "react";
import styled from "styled-components";
import DateUtil from "../../util/DateUtil";
import UserUtil from "../../util/UserUtil";
import PropTypes from "prop-types";

const ReportContainer = styled.div`
    @page {
        size: Letter;
        margin: 11mm 17mm 17mm 17mm;
    }
    @media print {
        html, body {
            width: 216mm;
            height: 279mm;
        }
    }
`

const ReportHeader = styled.div`
    text-align: center;
    display:none;
    
    @media print{
        display: inline;    
    }
    
    p{
        margin-bottom: 0;
        line-height: 17px;
        font-size:14px;
    }
    
`

const ReportFooter = styled.div`
    display:none;
    @media print{
        display: inline;
    }
    p{
        margin-bottom: 0;
        line-height: 17px;
        font-size:14px;
    }
`

class ReportWrapper extends Component{

    constructor(props) {
        super(props);
        this.userInfo = UserUtil.info();
        this.emailSupport = UserUtil.getSupportEmail()
    }

    render() {
        const {entityName,...restProps} =this.props;
        return (
            <ReportContainer {...restProps}>
                <ReportHeader>
                    <h1>CyberOne Security</h1>
                    {entityName && <p>{entityName}</p>}
                    <p>{DateUtil.reportFormat(new Date())}</p>
                    <p>by {this.userInfo?.firstName+" "+this.userInfo?.lastName}</p>
                </ReportHeader>
                {this.props.children}
                <ReportFooter>
                    <br/><br/>
                    <p>For Internal Use Only - Confidential Information</p>
                    <p>Do not share or reproduce this data. If you are not the intended user of this data, contact the
                        CyberOne Platform Support at {this.emailSupport}.</p>
                </ReportFooter>
            </ReportContainer>);
    }
}

ReportWrapper.propTypes={
    entityName:PropTypes.string
}

export default ReportWrapper;