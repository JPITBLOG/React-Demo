import React, { useEffect, useState } from 'react';
import DatePicker from "react-datepicker";
import 'react-datepicker/dist/react-datepicker.css';
import styled from "styled-components";
import './datePicker.css'

const DatePickerComponent = styled((props) => <DatePicker {...props}>{props.children}</DatePicker>)`
    background-color: hsl(0,0%,100%);
    border-color: #ced4da;
    border-radius: 4px;
    border-style: solid;
    border-width: 1px;
    color: hsl(0,0%,20%);
    min-height: 38px;
    width: 100%;
    padding: 2px 8px;
    
    ${({ readOnly }) => readOnly && `
    color: #A0A0A0;
  `}
`;

const DatePickerForm = ({ readOnly = false, selectedDate = "", required = false, onChange = () => null, ...restProps }) => {
    const [startDate, setStartDate] = useState(new Date());

    const props = Object.assign(restProps, { required })

    useEffect(() => {
        if (selectedDate !== "" && !readOnly) {
            setStartDate(new Date(selectedDate))
        }
        else if (selectedDate !== "" && readOnly) {
            setStartDate(new Date(selectedDate))
        }
    }, [selectedDate,readOnly])


    const onChangeHandler = (event) => {
        const value = event;
        const target = Object.assign(props, { value });
        onChange({
            currentTarget: target,
            target: target,
            value: value
        });
        setStartDate(event)
    }

    return (
        <DatePickerComponent
            selected={startDate}
            onChange={onChangeHandler}
            peekNextMonth
            showMonthDropdown
            showYearDropdown
            dropdownMode="select"
            readOnly={readOnly}
        />
    );
}

export default (DatePickerForm);