import React from "react";

import './DetailPageHeader.css';
import Image from "react-bootstrap/Image";
import {DEFAULT_THUMBNAIL} from "../../../bundle/ImageBundle";

const DetailPageHeader=({logoUrl="",info="",name="",icon,logoEnabled=true,noHeader=true,...restProps})=>{

    if(logoUrl.length===0){
        logoUrl=DEFAULT_THUMBNAIL;
    }

    const renderIcon = () =>{
        if(icon){
            return icon;
        }else{
            return <Image width={40} height={40} src={logoUrl} thumbnail/>
        }
    }

    if(!logoEnabled){
        return(<div className={noHeader? "detail-page-header-section": "detail-page-header"}>
            <div className="no-logo">
                <div className="name-label">{name}</div>
                {info!=="" && <div className="id-label">{info}</div>}
            </div>
        </div>)
    }

    return(<div className={noHeader? "detail-page-header-section":"detail-page-header"}>
        <div className="left-container">
            {renderIcon()}
        </div>
        <div className="right-container">
            <div className="name-label">{name}</div>
            <div className="id-label">{info}</div>
        </div>
        <div className="clearfix"></div>
    </div>)
}

export default (DetailPageHeader)