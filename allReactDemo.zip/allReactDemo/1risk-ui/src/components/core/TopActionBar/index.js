import React from "react";

import './TopActionBar.css'
import {Image} from "react-bootstrap";
import {NavLink} from "react-router-dom";
import ProfileMenu from "../ProfileMenu";

const TopActionBar = (props)=>{
    return(<div className="top-action-bar">
        <div className="left-container">
            <NavLink to="/">&nbsp;&nbsp;&nbsp;<Image height={30} src="/assets/img/CyberOne-logo-white.png" alt="CyberOne"/></NavLink>
        </div>
        <div className="right-container">
            {/*<FontAwesomeIcon fixedWidth icon={faBell}/>&nbsp;&nbsp;*/}
            <ProfileMenu/>
        </div>
        <div className="clearfix"></div>
    </div>)
}

export default (TopActionBar);