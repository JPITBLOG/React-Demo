import React from "react";
import BreadcrumbContainer from "./BreadcrumbContainer/";

import './MainPageHeader.css'
import TopActionMenu from "./TopActionMenu";
import {Col, Row} from "react-bootstrap";
import {useSelector} from "react-redux";
import CustomSystemAlert from "./CustomSystemAlert";

const MainPageHeader = (props) =>{

    const menuActions = useSelector(state => state.page.menuActions);

    return(<header className="main-header">
        <Row>
            <Col lg={10}><BreadcrumbContainer/></Col>
            <Col lg={2}><TopActionMenu isVisible={menuActions.isVisible} menuActions={menuActions.actions} enableCancel={menuActions.enableCancel}/></Col>
        </Row>
        <Row>
            <Col lg={12}>
                <CustomSystemAlert/>
            </Col>
        </Row>
    </header>)
}

export default (MainPageHeader);