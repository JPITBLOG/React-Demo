import React from "react";

const Label = ({children,...restProps}) =>{
    return(<span className="label" {...restProps}>{children}</span>);
}

export default (Label);