import React from "react";
import styled from "styled-components";
import {CircularProgress, withStyles} from "@material-ui/core";

const LoaderContainer = styled("div")`
    position: absolute;
    z-index: 110;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    background: rgba(255,255,255,0.8);
`

const Spinning = withStyles({
    root:{
        marginTop: "100px",
        color:"#FE9023"
    }
})(CircularProgress)

const MainLoader = ({display=false}) =>{
    if(display){
        return(<LoaderContainer><Spinning size={50}/></LoaderContainer>)
    }
    return null;
}

export default MainLoader