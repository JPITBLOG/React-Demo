import React from "react";
import {Dropdown, Image} from "react-bootstrap";
import './ProfileMenu.css';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faBuilding, faFolderPlus, faSignOutAlt, faUser} from "@fortawesome/free-solid-svg-icons";

const ProfileMenu = ({userPhoto="/assets/img/user-avater.png"}) =>{
    return(
        <Dropdown alignRight className="profile-menu">
            <Dropdown.Toggle variant="avatar" id="dropdown-basic">
                <Image roundedCircle src={userPhoto}/>
            </Dropdown.Toggle>
            <Dropdown.Menu>
                <Dropdown.Header>
                    Account Name
                </Dropdown.Header>
                <Dropdown.Divider/>
                <Dropdown.Item href="#/action-1"><FontAwesomeIcon fixedWidth icon={faUser}/>&nbsp;&nbsp;Profile</Dropdown.Item>
                <Dropdown.Item href="/signout"><FontAwesomeIcon fixedWidth icon={faSignOutAlt}/>&nbsp;&nbsp;Logout</Dropdown.Item>
                <Dropdown.Divider/>
                <Dropdown.Header>
                    Other Accounts
                </Dropdown.Header>
                <Dropdown.Divider/>
                <Dropdown.Item href="#/action-1"><FontAwesomeIcon fixedWidth icon={faBuilding}/>&nbsp;&nbsp;Account 1</Dropdown.Item>
                <Dropdown.Item href="#/action-1"><FontAwesomeIcon fixedWidth icon={faBuilding}/>&nbsp;&nbsp;Account 2</Dropdown.Item>
                <Dropdown.Item href="#/action-1"><FontAwesomeIcon fixedWidth icon={faFolderPlus}/>&nbsp;&nbsp;Add account</Dropdown.Item>
            </Dropdown.Menu>
        </Dropdown>
    )
}

export default ProfileMenu;