import React, { Component } from "react";
import {NavLink} from "react-router-dom";
import {Collapse} from "react-bootstrap";
import {default as UUID} from 'uuid';
import {connect} from 'react-redux';

import './CheckBoxFilter.css';
import CollapseIcon from "../CollapseIcon";
import CheckboxIcon, {CHECKBOX_PARTIAL_SELECTED, CHECKBOX_SELECTED, CHECKBOX_UNSELECTED} from "../CheckBoxIcon";

class CheckBoxFilter extends Component{

    static defaultProps={
        name:UUID.v4(),
        checked: [],
        expanded: [],
        open:true,
        items:[],
        label:"Filter",
        valueKey:"value",
        labelKey:"label",
        onChange:function(selected){
            console.log(selected);
        }
    }

    constructor(props) {
        super(props);
        this.state = {
            checked: [],
            expanded: [],
            filterIsOpen:props.open,
            items:props.items,
            label:props.label,
            onChange:props.onChange,
            lastEventId:null,
        };

        this.onClickHandler = this.onClickHandler.bind(this);
        this.getCheckedByValue = this.getCheckedByValue.bind(this);
        this.getParentCheckedByValue = this.getParentCheckedByValue.bind(this);
        this.onClickClearHandler = this.onClickClearHandler.bind(this);
        this.toggleFilterCollapse = this.toggleFilterCollapse.bind(this);
        this.onClickExpand = this.onClickExpand.bind(this);

    }

    static getDerivedStateFromProps(props,state) {
        state.name=props.name;
        state.items=props.items;
        if(props.selectedData && props.selectedData.eventId !== state.lastEventId){
            if(props.selectedData.parentId === state.name){
                const checked = state.checked.filter((item)=>item===props.selectedData.value)[0];
                if(checked===undefined){
                    state.checked.push(props.selectedData.value);
                    state.onChange(state.checked);
                }
            }
            state.lastEventId = props.selectedData.eventId;
        }
        return state;
    }

    getCheckedByValue(item){
        if(this.state.checked.includes(item.value)){
            return(true);
        }

        return(false);

    }

    isExpandedByValue(item){
        if(this.state.expanded.includes(item.value)){
            return true;
        }
        return false;
    }

    onClickExpand(event,item){
        event.preventDefault();

        const state = this.state;

        if(!state.expanded.includes(item.value)){
            state.expanded.push(item.value);
        }else{
            state.expanded=state.expanded.filter(function(value){
                return value !== item.value;
            });
        }
        this.setState(state)
    }

    getParentCheckedByValue(item){
        const childSize = item.children.length;
        let selectedItems = 0;
        let checkBoxType = CHECKBOX_UNSELECTED;

        item.children.forEach((child)=>{
            if(this.state.checked.includes(child.value)){
                selectedItems++;
            }
        });

        if(selectedItems>0){
            checkBoxType = CHECKBOX_PARTIAL_SELECTED;
        }

        if(selectedItems===childSize){
            checkBoxType = CHECKBOX_SELECTED;
        }

        return checkBoxType;

    }

    onClickHandler(event,item){

        const state = this.state;
        event.preventDefault(event);

        if(item.children){

            const childSize = item.children.length;
            let selectedItems = 0;
            item.children.forEach((child)=>{
                if(this.state.checked.includes(child.value)){
                    selectedItems++;
                }
            });

            if(selectedItems===0 || selectedItems===childSize){
                item.children.forEach((child)=>{
                    this.toggleCheckItem(child);
                });
            }else{
                item.children.forEach((child)=>{
                    if(!state.checked.includes(child.value)){
                        state.checked.push(child.value);
                    }
                });
            }

        }else{
            this.toggleCheckItem(item);
        }

        this.setState(state);

        this.state.onChange(state.checked)

    }

    toggleCheckItem(item){
        const state = this.state;
        if(!state.checked.includes(item.value)){
            state.checked.push(item.value);
        }else{
            state.checked=state.checked.filter(function(value){
                return value !== item.value;
            });
        }
    }

    onClickClearHandler(event){
        event.preventDefault();
        this.setState({checked:[]});
        this.state.onChange([]);
    }

    toggleFilterCollapse(event){
        event.preventDefault();
        this.setState({filterIsOpen: !this.state.filterIsOpen})
    }

    render() {
        const {checked,filterIsOpen,items,label} = this.state;
        return(
            <div className="checkbox-filter">
                <div className="widget-filter">
                    <div className="header">
                        <h6 data-text-mobile={label} data-text-desktop={label}>
                            {label}
                            {checked.length > 0 && <span>&nbsp;&nbsp;({checked.length})</span>}
                        </h6>
                        <span>
                            <NavLink to="/" onClick={this.onClickClearHandler} className="input-reset">Clear</NavLink>
                            <CollapseIcon onClick={this.toggleFilterCollapse} expanded={filterIsOpen}/>
                        </span>
                    </div>
                    <Collapse in={filterIsOpen}>
                        <div className="widget-inputs">
                            <ul className="parent-list">
                                {items.map((item,index)=> {
                                    if(item.children){
                                        return(
                                            <li key={index}>
                                                <CollapseIcon onClick={(e)=>{ this.onClickExpand(e,item)}} expanded={this.isExpandedByValue(item)}/>
                                                <span onClick={(e) => this.onClickHandler(e,item)}>
                                                    <CheckboxIcon type={this.getParentCheckedByValue(item)}/>
                                                    <span className="label">{item.label}</span>
                                                </span>
                                                <Collapse in={this.isExpandedByValue(item)}>
                                                    <ul>
                                                        {item.children.map((child,index)=>{
                                                        return(
                                                            <li key={index}>
                                                                <span onClick={(e) => this.onClickHandler(e,child)}>
                                                                    <CheckboxIcon selected={this.getCheckedByValue(child)}/>
                                                                    <span className="label">{child.label}</span>
                                                                </span>
                                                            </li>
                                                        )
                                                        })}
                                                    </ul>
                                                </Collapse>
                                            </li>
                                        );
                                    }else{
                                        return(
                                            <li key={index}>
                                                <span onClick={(e) => this.onClickHandler(e,item)}>
                                                    <CheckboxIcon selected={this.getCheckedByValue(item)}/>
                                                    <span className="label">{item.label}</span>
                                                </span>
                                            </li>
                                        )
                                    }
                                })}
                            </ul>
                        </div>
                    </Collapse>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state)=>{
    return({selectedData:state.searchFilter.checkboxFilterData})
}

export default connect(mapStateToProps)(CheckBoxFilter);