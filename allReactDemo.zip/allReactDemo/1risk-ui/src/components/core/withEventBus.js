import React, {Component} from "react";
import {connect} from "react-redux";
import UUIDUtil from "../../util/UUIDUtil";

export const EVENT_BUS_DISPATCH='event-bus-dispatch';

export default (ChildComponent) =>{
    class EventBus extends Component{

        constructor(props) {
            super(props);
            this.state={
                listeners:[],
                lastEventId:""
            }
            this.busFunctions = this.busFunctions.bind(this);
            this.addEventListener = this.addEventListener.bind(this);
            this.dispatch = this.dispatch.bind(this);
        }

        addEventListener(eventName,callback){
            const state = this.state;
            state.listeners.push({
                eventName:eventName,
                callback:callback
            })
            this.setState(state);
        }

        dispatch(eventName,context){
            this.props.dispatchEvent(eventName,context);
        }

        busFunctions(){
            return({
                addEventListener:this.addEventListener,
                dispatch:this.dispatch
            })
        }

        static getDerivedStateFromProps(props,state){
            if(props.data && props.data.eventId !== state.lastEventId){
                const listeners = state.listeners.filter((listener)=>listener.eventName===props.data.eventName);
                if(listeners){
                    for(let i=0; i<listeners.length; i++){
                        listeners[i].callback(props.data.context);
                    }
                }
               state.lastEventId=props.data.eventId;
            }
            return state;
        }

        render() {
            return (
                <ChildComponent {...this.props} eventBus={this.busFunctions()}/>
            );
        }

    }

    function mapStateToProps(state){
        return {data: state.eventBus.data}
    }

    const mapDispatchToProps = dispatch => ({
        dispatchEvent: (eventName,context) => dispatch({
            type: EVENT_BUS_DISPATCH,
            payload: {
                eventId: UUIDUtil.v4(),
                eventName: eventName,
                context: context
            },
        })
    });

    return connect(mapStateToProps,mapDispatchToProps)(EventBus);
}
