import React from "react";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faDotCircle} from "@fortawesome/free-solid-svg-icons";
import {faCircle} from "@fortawesome/free-regular-svg-icons";
import styled from "styled-components";
import PropTypes from "prop-types";

const RadioButtonIcon = styled((props) => <FontAwesomeIcon {...props} icon={props.selected ? faDotCircle : faCircle} />)`
  color: ${props => props.selected ? "#FA7C00" : "#494A4C"};
  margin-right: 5px;
  cursor: pointer;
`;

RadioButtonIcon.propTypes={
    selected: PropTypes.bool
}

export default (RadioButtonIcon)