import React from "react";
import {Button} from "react-bootstrap";
import PropTypes from 'prop-types';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {library} from '@fortawesome/fontawesome-svg-core'
import {fas} from '@fortawesome/free-solid-svg-icons'
import {far} from '@fortawesome/free-regular-svg-icons';

const IconButton = ({children,icon,...restProps}) =>{
    library.add(fas,far);
    return(<Button {...restProps}><FontAwesomeIcon fixedWidth icon={icon}/>{children}</Button>)
}

IconButton.propTypes = {
    icon:PropTypes.string.isRequired
}

export default React.memo(IconButton)