import React from 'react';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {Button} from "react-bootstrap";
import {library} from '@fortawesome/fontawesome-svg-core'
import {fas} from '@fortawesome/free-solid-svg-icons'
import {far} from '@fortawesome/free-regular-svg-icons';

const SpinningButton = ({children,loading=false,icon,...restProps})=>{
    library.add(fas,far);
    if(loading){
        return(<button className="btn btn-primary" type="button" disabled>
            <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
             Loading...
        </button>)
    }else{
        return(
            <Button {...restProps}>
                {icon && <FontAwesomeIcon icon={icon}/>}
                {children}
            </Button>
        );
    }
}

export default (SpinningButton)