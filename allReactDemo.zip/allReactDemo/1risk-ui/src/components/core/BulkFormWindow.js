import React, {useCallback, useEffect, useState} from 'react';
import {Button, Modal} from "react-bootstrap";
import styled from "styled-components";
import Form from "react-bootstrap/Form";
import {useDispatch, useSelector} from "react-redux";
import FormTagSelector from "./FormTagSelector";
import ArrayUtil from "../../util/ArrayUtil";
import RadioGroup from "./RadioGroup";
import {getEntityTags,saveEntityTag, getUsersFilter} from "../../actions/index";
import FormSelector from "./FormSelector";

const BulkFormModal = styled((props)=><Modal {...props}>{props.children}</Modal>)`
    
    & .modal-content{
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 20px 75px rgba(0, 0, 0, 0.13);
        color: #666;
    }
    
    & .form-label{
        font-family: 'Lato', sans-serif;
        font-size: 14px;
        font-weight: bold;
    }
    
    & .radio-group{
        margin-top:15px;
        margin-left: 5px;
    }
    
`;

const BulkFormModalHeader = styled((props)=><Modal.Header {...props}>{props.children}</Modal.Header>)`
    color: #FA7C00;
    font-family: 'Lato', sans-serif;
    font-weight: bold;
    font-size: 14px;
    text-transform: uppercase;
    padding: 20px 20px 10px;
    border-bottom: 0px;
`;

const BulkFormModalFooter = styled((props)=><Modal.Footer {...props}>{props.children}</Modal.Footer>)`
    justify-content: center;
    border-top: 0px;
`;

const BulkFormModalButton = styled((props)=><Button {...props}>{props.children}</Button>)`
    min-width:100px;
`;

const BulkFormWindow = ({
    onClose,
    onAction,
    selectedItems=[],
    show=false,
    type,
    entityName,
    fieldName,
    fieldLabel,
    options=[]
}) =>{

    const dispatch = useDispatch();

    const [container,setContainer] = useState(<div>Set here</div>);
    const [formData,setFormData] = useState({});
    const [lastFieldName,setLastFieldName] = useState(fieldName);
    const [enableSave,setEnableSave] = useState(false);

    const [tagOption,setTagOption] = useState(false);
    const [boolOption,setBoolOption] = useState(null);

    const tags  = useSelector(state => state.searchFilter.entityTagsData);
    const users = useSelector(state => state.searchFilter.usersFilterData);

    const escFunction = useCallback((event) => {
        if(event.keyCode === 27) {
            onClose();
        }
    },[onClose]);

    const getTagContainer = useCallback(()=>{

        const tagOptions = [{label: "Add to existing", value: false}, {label: "Replace", value: true}];
        const selectOptions = ArrayUtil.parseToDropdownCollection(tags?.map((tag)=>tag.value));

        const formDataHandler = (event) =>{
            setEnableSave(false);
            const newTags = event.value?.filter((tag)=>tag["__isNew__"]);
            if(newTags.length>0){
                newTags.forEach((newTag)=>{
                    const tagRequest={
                        entityName:entityName,
                        fieldName:fieldName,
                        value:newTag.value
                    }
                    dispatch(saveEntityTag(tagRequest,()=>{
                        setLastFieldName("");
                        setEnableSave(event.value.length>0);
                    }));
                })
            }else{
                setEnableSave(event.value.length>0);
            }
            Object.assign(formData,event);
            setFormData(formData);

        }

        const tagOptionHandler = (event) => {
            setTagOption(event);
            formData.replace=event;
            setFormData(formData);
        }

        return(<Form>
            <Form.Group>
                <Form.Label>{fieldLabel}</Form.Label>
                <FormTagSelector name={fieldName} options={selectOptions} onChange={formDataHandler}/>
                <RadioGroup defaultValue={tagOption} inline options={tagOptions} onChange={tagOptionHandler}/>
            </Form.Group>
        </Form>);

    },[fieldLabel,tags,tagOption,fieldName,formData,entityName,dispatch]);

    const getUserSelector = useCallback(()=>{

        const formDataHandler=(event)=>{
            setEnableSave(true);
            Object.assign(formData,event);
            setFormData(formData);
        }

        return(<Form.Group>
            <Form.Label>{fieldLabel}</Form.Label>
            <FormSelector name={fieldName} isSearchable options={users} onChange={formDataHandler}/>
        </Form.Group>);

    },[fieldLabel,users,fieldName,formData])

    const getBoolContainer = useCallback(()=>{

        const customOptionHandler = (event) => {
            setEnableSave(true);
            setBoolOption(event);
            formData.target={
                name:fieldName
            }
            formData.value=event;
            setFormData(formData);
        }

        return(<Form>
            <Form.Group>
                <Form.Label>{fieldLabel}</Form.Label>
                <RadioGroup name={fieldName} defaultValue={boolOption} inline options={options} onChange={customOptionHandler}/>
            </Form.Group>
        </Form>);

    },[formData,options,fieldName,fieldLabel,boolOption])

    const prepareTag=()=>{
        formData.replace = tagOption;
        setFormData(formData);
        if(tags===undefined && show){
            dispatch(getEntityTags(entityName,fieldName));
        }
        if(tags!==undefined && lastFieldName!==fieldName){
            setLastFieldName(fieldName);
            dispatch(getEntityTags(entityName,fieldName));
        }
        setContainer(getTagContainer());
    }

    const prepareUserSelect=()=>{
        delete formData.replace;
        if(users.length === 0 && show){
            dispatch(getUsersFilter());
        }
        setContainer(getUserSelector());
    }

    useEffect(() => {

        document.addEventListener("keydown", escFunction, false);

        switch (type) {
            case "tag":
                prepareTag();
                break;
            case "userSelect":
                prepareUserSelect()
                break;
            case "bool":
                setContainer(getBoolContainer);
                break;
            default:
                setContainer(<div>Set here Default</div>);
        }

        return () => {
            document.removeEventListener("keydown", escFunction, false);
        };
    },[
        escFunction,type,tags,setContainer,show,
        getTagContainer,dispatch,entityName,fieldName,
        lastFieldName,formData,tagOption,boolOption,users,getUserSelector]);

    const onSaveHandler = (event) => {
        onAction(formData);
        onClose();
        event.preventDefault();
    }

    return(<BulkFormModal show={show} centered>
        <BulkFormModalHeader>Changing {selectedItems.length} {selectedItems.length > 0 ? 'records':'record'}</BulkFormModalHeader>
        <Modal.Body>{container}</Modal.Body>
        <BulkFormModalFooter>
            <BulkFormModalButton disabled={!enableSave} onClick={onSaveHandler}>Save</BulkFormModalButton>
            <BulkFormModalButton variant="secondary" onClick={onClose}>Cancel</BulkFormModalButton>
        </BulkFormModalFooter>
    </BulkFormModal>);

}

export default BulkFormWindow;