import React, {useEffect, useState} from "react";
import IconLink from "./IconLink";
import styled from "styled-components";
import FileUtil from "../../util/FileUtil";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faTimesCircle} from "@fortawesome/free-solid-svg-icons";

const TimesIcon = styled((props)=> <FontAwesomeIcon fixedWidth {...props} icon={faTimesCircle} />)`
    margin-left: 5px;
    cursor: pointer;
`;

const FileInput = styled("input")`
    display: none;
`

const FileList = styled("ul")`
    padding: 0;
    list-style: none;
    margin: 10px 5px;
`;

const FileListItem = styled("li")`
    color: #494A4C;
    font-size: 14px;
    font-family: 'Lato', sans-serif;
    margin-bottom: 5px !important;
`;

const FileUploadLink = ({children,onChange=()=>null,attachments=[],files=[]})=>{

    let uploadRef;

    const maxFileSize = 5242880;

    const [fileList,setFileList] = useState([]);

    const extensions=[
        "image/*",
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-powerpoint",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "application/rtf",
        "text/csv",
        "text/plain"
    ]

    const onClickAddHandler = (event)=>{
        uploadRef.click();
        event.preventDefault();
    }

    const readFile = (file)=>{

        if(file.size > maxFileSize){
            return;
        }

        const fileInfo = {
            name: file.name,
            lastModified: file.lastModified,
            size: file.size,
            type: file.type
        }

        const reader = new FileReader();

        reader.onabort = () => console.log('file reading was aborted')
        reader.onerror = () => console.log('file reading has failed')
        reader.onload = () => {
            fileInfo.data = reader.result.split(",")[1];
            onLoad(fileInfo);
        }
        reader.readAsDataURL(file);
    }

    const onLoad = (event)=>{
        fileList.push(event);
        setFileList([...fileList]);
        onChange(fileList);
    }

    const onFileChange = ()=>{
        for(let i=0; i<uploadRef.files.length; i++){
            readFile(uploadRef.files[i]);
        }
    }

    const onRemoveClick = (fileItem)=>{
        const filteredFiles = fileList.filter((file)=> fileItem.name !== file.name);
        setFileList(filteredFiles);
        onChange(filteredFiles);
    }

    useEffect(()=>{
        if(attachments.length>0){
            setFileList([...attachments]);
        }
    },[])

    return(<div>
        {fileList.length > 0 && <FileList>
            {fileList.map((file,index)=>{
                return(<FileListItem key={`file-item-${index}`}>
                        {file.name} ({FileUtil.formatBytes(file.size)})
                        <TimesIcon onClick={()=>onRemoveClick(file)}/>
                    </FileListItem>
                );
            })}
        </FileList>}
        <IconLink onClick={onClickAddHandler}>{children}</IconLink>
        <FileInput
            ref={el => (uploadRef = el)}
            type="file"
            multiple
            onChange={onFileChange} accept={extensions.join(",")}
        />
    </div>)
}

export default FileUploadLink;