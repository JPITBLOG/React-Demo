import React from "react";
import styled from "styled-components";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";

const LinkButton = styled("button")`
    border: 0;
    padding: 0;
    background-color: transparent;
    color: #494A4C;
    font-size: 14px;
    font-family: 'Lato', sans-serif;
    margin-top: 5px;
    outline: none !important;
    box-shadow: none;
    
    &:active{
        outline: none !important;
        box-shadow: none;
    }
    
    & svg{
        margin-right: 2px;
    }
    
`

const IconLink = ({children,icon="paperclip",...restProps}) =>{
    return(<LinkButton {...restProps}>
        <FontAwesomeIcon icon={icon} fixedWidth/>{children}
    </LinkButton>)
}

export default IconLink;