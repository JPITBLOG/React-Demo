/**
 *
 */

import React, {useEffect, useState} from "react";
import styled from "styled-components";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faEllipsisH, faEye, faShareAlt, faTimes} from "@fortawesome/free-solid-svg-icons";
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import copy from "copy-to-clipboard";
import {useHistory, useLocation} from 'react-router-dom'

const HIDE_TOP_ACTION_MENU_CONTAINER = "hide-top-action-menu-container";

const TopActionMenuContainer = styled('div')`
    font-family: 'Lato', sans-serif;
    display: flex;
    flex-direction: row;
    justify-content: flex-end;
`;

const TopActionMenuItem = styled('div')`
    position: relative;
    color: #494A4C;
    font-size: 14px;
`;

const TopActionButton = styled('button')`
    -webkit-box-align: baseline;
    color: ${prop => prop.disabled ? '#dadde3' : '#494A4C'};
    display: inline-flex;
    align-items: baseline;
    box-sizing: border-box;
    vertical-align: middle;
    text-align: center;
    background-color: transparent;
    border: 2px solid transparent;
    width: auto;
    max-width: 100%;
    background: none;
    border-radius: .25rem;
    outline: none !important;
    padding: 0px 8px;
    height: 2.28571em;
    line-height: 2.28571em;

    &:hover,:active,:focus{
        outline:0 !important;
        background-color: #FFFFFF;
        border: 2px solid #FFFFFF;
        box-shadow:0px;
    }
     
`

const ButtonMenuContainer = styled('div')`
    font-size: 14px;
    position: absolute;
    right: 0;
    top: 35px;
    float: left;
    min-width: 10rem;
    padding: .5rem 0;
    margin: .125rem 0 0;
    font-size: 1rem;
    color: #212529;
    text-align: left;
    list-style: none;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid rgba(0,0,0,.15);
    border-radius: .25rem;
    z-index:999999;    
`

const ButtonMenuContainerItems = styled('ul')`
    width: 100%;
    display: inline-block;
    font-size: 14px;
    padding:0px;
    margin: 0px;
    list-style-type: none;
`;

const ButtonMenuContainerItem = styled(({icon,label,onClick,isVisible=true,isTitle=false,...restProps})=>{
    if(!isVisible){
        return null;
    }

    const onClickHandler = (event)=>{
        window.dispatchEvent(new Event(HIDE_TOP_ACTION_MENU_CONTAINER));
        onClick(event);
    }

    if(isTitle){
        return(<li {...restProps}>
            {icon && <FontAwesomeIcon icon={icon}/>}
            <b>{label}</b>
        </li>);
    }else{
        return(<li {...restProps} onClick={onClickHandler}>
            {icon && <FontAwesomeIcon icon={icon}/>}
            {label}
        </li>);
    }

})`
    color: ${prop => prop.disabled ? '#dadde3' : '#494A4C'};
    font-size: 14px;
    padding: 5px 20px;
    white-space: nowrap;
    cursor: ${prop => prop.isTitle ? '' : 'pointer'};
    
    &:hover{
        background: ${prop => prop.isTitle ? '' : '#F5F5F5'};;
    }
    
    & svg{
        margin-right: 5px;
    }
`

const ButtonMenuContainerSeparator = styled('hr')``;

const EyeCounter = styled('span')`
    margin-left:5px;
`

const TopActionMenu = ({menuActions=[],enableCancel=true,isVisible=false})=>{

    const history = useHistory();
    const location = useLocation();
    const [displayMenu,setDisplayMenu] = useState(false);
    const [displayShare,setDisplayShare] = useState(false);
    const [copySuccess,setCopySuccess] = useState(false);

    useEffect(() => {

        const onHideHandler = (event)=>{
            setDisplayMenu(false);
            setDisplayShare(false);
        }

        window.addEventListener(HIDE_TOP_ACTION_MENU_CONTAINER,onHideHandler);
        return ()=> window.removeEventListener(HIDE_TOP_ACTION_MENU_CONTAINER,onHideHandler);

    })

    const onClick = (event) => {
        console.log(event);
        event.preventDefault();
    }

    const onMenuClick = (event) => {
        event.preventDefault();
        setDisplayMenu(true);
    }

    const onMenuClickAway = (event) => {
        event.preventDefault();
        setDisplayMenu(false);
    }

    const onShareClick = (event) => {
        event.preventDefault();
        setDisplayShare(true);
    }

    const onShareClickAway = (event) => {
        event.preventDefault();
        setDisplayShare(false);
    }

    const onCopyLinkClick = (event) => {
        event.preventDefault();
        copy(window.location.href);
        setCopySuccess(true);
        setDisplayShare(false);
        setTimeout(()=> setCopySuccess(false),1500);
    }

    const onCancelClick = (event) =>{
        event.preventDefault();
        const urlParts = location.pathname.split("/");
        urlParts.pop();
        history.push(urlParts.join("/"));
    }

    if(!isVisible){
        return false;
    }

    return(<div className="top-action-menu">
        <TopActionMenuContainer>

            <TopActionMenuItem>
                <TopActionButton onClick={onClick}>
                    <FontAwesomeIcon fixedWidth icon={faEye}/>
                    <EyeCounter>2</EyeCounter>
                </TopActionButton>
            </TopActionMenuItem>

            <TopActionMenuItem>
                <TopActionButton onClick={onShareClick}>
                    <FontAwesomeIcon color={copySuccess ? "#FA7C00" : ""} fixedWidth icon={faShareAlt}/>
                </TopActionButton>
                {displayShare && <ClickAwayListener onClickAway={onShareClickAway}>
                    <ButtonMenuContainer>
                        <ButtonMenuContainerItems>
                            <ButtonMenuContainerItem onClick={onCopyLinkClick} label="Copy Link" icon="paperclip"/>
                        </ButtonMenuContainerItems>
                    </ButtonMenuContainer>
                </ClickAwayListener>}
            </TopActionMenuItem>

            <TopActionMenuItem>
                <TopActionButton onClick={onMenuClick}>
                    <FontAwesomeIcon fixedWidth icon={faEllipsisH}/>
                </TopActionButton>
                {displayMenu && <ClickAwayListener onClickAway={onMenuClickAway}>
                    <ButtonMenuContainer>
                        <ButtonMenuContainerItems>
                            {menuActions.map((menuAction,index)=>{
                                const props={
                                    key:`menu-action-${index}`
                                }
                                return React.cloneElement(menuAction,props,null);
                            })}
                        </ButtonMenuContainerItems>
                    </ButtonMenuContainer>
                </ClickAwayListener>}
            </TopActionMenuItem>

            {enableCancel && <TopActionMenuItem>
                <TopActionButton onClick={onCancelClick}>
                    <FontAwesomeIcon fixedWidth icon={faTimes}/>
                </TopActionButton>
            </TopActionMenuItem>}

        </TopActionMenuContainer>
    </div>)
}

TopActionMenu.ButtonMenuItem = ButtonMenuContainerItem;
TopActionMenu.ButtonMenuSeparator = ButtonMenuContainerSeparator;

export default (TopActionMenu);