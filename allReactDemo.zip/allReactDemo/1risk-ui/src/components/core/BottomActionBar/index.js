import React from "react";

import './BottomActionBar.css';
import {NavLink} from "react-router-dom";
import {Col, Row} from "react-bootstrap";

const BottomActionBar = (props) => {
    return(<div className="bottom-action-bar">
        <Row>
            <Col className="left-container" lg={2} xs={4} sm={2}>
                <NavLink to="/">Terms of Service</NavLink>
            </Col>
            <Col className="right-container" lg={{span:3, offset:7}} xs={8}>
                <p>&copy; 2015-{(new Date()).getFullYear()} CyberOne Security Inc.</p>
            </Col>
        </Row>
    </div>)
}

export default (BottomActionBar);