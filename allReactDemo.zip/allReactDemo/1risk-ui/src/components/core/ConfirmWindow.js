import React from 'react'
import styled from "styled-components";
import {Button, Card} from "react-bootstrap";

const ConfirmationCard=styled((props)=><Card {...props}>{props.children}</Card>)`
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 20px 75px rgba(0, 0, 0, 0.13);
    color: #666;
`;

const ConfirmCardHeader=styled((props)=><Card.Header {...props}>{props.children}</Card.Header>)`
    padding: 20px 20px 10px;
`;

const ConfirmationCardTitle=styled((props)=><Card.Title {...props}>{props.children}</Card.Title>)`
    font-size: 14px;
    font-weight: bold;
    padding: 15px 50px;
`;

const ConfirmCardButtons=styled((props)=><Card.Text {...props}>{props.children}</Card.Text>)`
    display: flex;
    flex-direction: row;
    justify-content: center;
`;

const ConfirmButton = styled((props)=><Button {...props}>{props.children}</Button>)`
    min-width:100px;
`;

const ConfirmWindow = (
    {
        onClose,
        onAction,
        headerText="Delete Record",
        infoText="Do you want to delete this record?",
        selectedItems=0
    }
)=>{

    if(selectedItems>0){
        infoText=`Do you want to delete the ${selectedItems} selected records?`
    }

    return(<ConfirmationCard>
        <ConfirmCardHeader>{headerText}</ConfirmCardHeader>
        <Card.Body>
            <ConfirmationCardTitle>{infoText}</ConfirmationCardTitle>
            <ConfirmCardButtons>
                <ConfirmButton onClick={()=>{ onAction(); onClose();}}>Yes</ConfirmButton>&nbsp;&nbsp;&nbsp;&nbsp;
                <ConfirmButton onClick={()=>onClose()} variant="outline-dark">No</ConfirmButton>
            </ConfirmCardButtons>
        </Card.Body>
    </ConfirmationCard>)
}

export default (ConfirmWindow);