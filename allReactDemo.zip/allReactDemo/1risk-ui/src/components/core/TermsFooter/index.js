import React from "react";
import {NavLink} from "react-router-dom";

import './TermsFooter.css';

const TermsFooter = (props) =>{
    return(<div className="terms-footer">
        <hr/>
        <div className="left-container"><NavLink to="/">Terms of Service</NavLink></div>
        <div className="right-container"><p>&copy; 2015-{(new Date()).getFullYear()} CyberOne Security Inc.</p></div>
        <div className="clearfix">&nbsp;</div>
    </div>);
}

export default TermsFooter;