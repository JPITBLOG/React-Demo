import React from 'react';
import styled from "styled-components";

const Link = styled("a")`
    text-decoration: underline;
    color: #494A4C;
    
    &:hover{
        color: #494A4C;
    }
`

const ExternalLink = ({children,tab=false,to="/"}) =>{

    const onClickHandler = (event) => {
        if(tab){
            window.open(to,"_blank");
        }else{
            window.location = to;
        }
        event.preventDefault();
    }

    return(<Link href={to} onClick={onClickHandler}>{children}</Link>);

}

export default (ExternalLink);