import withStyles from "@material-ui/core/styles/withStyles";
import {Chip} from "@material-ui/core";

const DefaultItemChip = withStyles({
    root: {
        backgroundColor:"#e0e0e0",
        background: "#e0e0e0 0% 0% no-repeat padding-box",
        borderRadius: "5px",
        opacity: "1",
        padding: "5px",
        fontFamily: "Lato, sans-serif",
        marginRight: "10px"
    },
    deleteIcon:{
        color: "#494A4C"
    },
    label:{
        textAlign: "left",
        font: "14px/17px Lato",
        letterSpacing: "0",
        color: "#494A4C",
        opacity: "1"
    }
})(Chip);

export default (DefaultItemChip)