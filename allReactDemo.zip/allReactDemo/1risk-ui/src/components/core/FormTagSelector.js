import React from 'react';
import CreatableSelect from 'react-select/creatable';

const FormTagSelector = ({isValid=true,isInvalid=false,onBlur=()=>null,onChange=()=>null,required=false,...restProps})=>{

    const props = Object.assign(restProps,{required})

    let customStyles = {
        control:(provided,state)=>{
            return ({
                ...provided,
                borderColor: isValid && !isInvalid ? '#ced4da' : '#dc3545',
                boxShadow: state.isFocused && isValid ? '0 0 0 1px #ced4da' : '',
                fontSize:'14px',
                fontFamily: "'Lato', sans-serif",
                '&:hover': {
                    borderColor: '#ced4da'
                }
            })
        },
        container: (provided) =>({
            ...provided,
        }),
        option: (provided, state) => ({
            ...provided,
            color: state.isSelected ? '#FFFFFF' : '#494A4C',
            backgroundColor: state.isSelected ? '#FA7C00' : state.isFocused ? '#F5F5F5' : '#FFFFFF',
            fontSize:'14px',
            fontFamily: "'Lato', sans-serif"
        }),
        multiValueLabel:(provided, state) => ({
            ...provided,
            fontSize:'14px',
            fontFamily: "'Lato', sans-serif"
        }),
    }

    const className = isValid && !isInvalid ? 'form-tag-select' : 'form-tag-select is-invalid';

    const onChangeHandler = (event)=>{
        const target = Object.assign(props,{value:event});
        onChange({
            currentTarget:target,
            target:target,
            value:event
        });
    }

    return(
        <CreatableSelect isMulti onChange={onChangeHandler} className={className} styles={customStyles} {...restProps}/>
    );
}

export default (FormTagSelector);