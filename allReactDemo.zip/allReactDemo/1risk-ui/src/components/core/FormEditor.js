import React from "react";
import TinyMCEUtil from "../../util/TinyMCEUtil";
import {Editor} from "@tinymce/tinymce-react";

const FormEditor = ({initialValue,onEditorChange,isValid=true,isInvalid=false}) =>{

    const className = isValid && !isInvalid ? 'form-editor' : 'form-editor is-invalid'

    return(
        <div className={className}>
            <Editor
                apiKey={TinyMCEUtil.getApiKey()}
                initialValue={initialValue}
                init={{
                    height: 350,
                    menubar: false,
                    statusbar: false,
                    content_style:
                    "body {  font-size: 14px; font-family: 'Lato', sans-serif; color: #494A4C; }",
                    plugins: [
                        'advlist autolink lists link image charmap print preview anchor',
                        'searchreplace visualblocks code fullscreen',
                        'insertdatetime media table paste code table help print link'
                    ],
                    toolbar:
                        'undo redo | formatselect | bold italic underline strikethrough ' +
                        'forecolor backcolor | ' +
                        'alignleft aligncenter alignright alignjustify | table link | ' +
                        'bullist numlist outdent indent | removeformat | print | help'
                }}
                onEditorChange={onEditorChange}
            />
        </div>
    )
}

export default (FormEditor)
