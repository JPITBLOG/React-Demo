
import styled from "styled-components";

const CardSection = styled('section')`
    margin-bottom:25px;
`

export default (CardSection);