import React from "react";
import {NavLink} from "react-router-dom";
import Label from "./Label";
import DateUtil from "../../util/DateUtil";
import ExternalLink from "./ExternalLink";
import AttachTooltip from "./AttachItemTooltip";
import FileUtil from "../../util/FileUtil";

const NavColumnLabel = ({column,item})=>{

    let urlKeyFieldName = "id";
    let link="/";
    let attachItem=[];

    const getValue = (fieldName) => {
        if(fieldName.includes(".")){
            const fieldNames = fieldName.split(".");
            if(fieldNames.length===2){
                return item[fieldNames[0]][fieldNames[1]]
            }
            if(fieldNames.length===3){
                return item[fieldNames[0]][fieldNames[1]][fieldNames[2]]
            }
        }
        return item[fieldName]
    }

    let labelContent = getValue(column.fieldName);

    if(column.contentType==="datetime"){
        labelContent = DateUtil.format(labelContent)
    }

    if(column.contentType==="lastUpdated"){
        labelContent = DateUtil.format(labelContent)
        labelContent = labelContent + " by " + item[column.ownerField];
    }

    if(column.contentType==="iconLabel"){
        const {trueIcon,falseIcon,fieldName} = column.icon;
        const iconElm = getValue(fieldName) ? trueIcon : falseIcon;
        labelContent = <div>{iconElm}&nbsp;&nbsp;{labelContent}</div>
    }

    if(column.url){
        const selectedFieldName = column.url.split('{').pop().split('}')
        if(selectedFieldName.length>0){
            urlKeyFieldName=selectedFieldName[0];
            link = column.url.replace("{"+urlKeyFieldName+"}",item[urlKeyFieldName]);
        }
        if(column.contentType==="externalLink"){
            return(<ExternalLink tab to={link}><Label>{labelContent}</Label></ExternalLink>)
        }else{
            return(<NavLink to={link}><Label>{labelContent}</Label></NavLink>)
        }
    }

    if(column.contentType === "attachmentLabel"){
        const {icon} = column;
        labelContent.map((item) => attachItem.push(`${item.name} \n`));

        if (labelContent.length > 0) {
            labelContent = <AttachTooltip title={attachItem} placement="top">
                <div>{labelContent.length} {icon}</div>
            </AttachTooltip>
        }
        else {
            labelContent = <div>{labelContent.length} {icon}</div>
        }
    }

    if(column.contentType === "sizeLabel"){
        labelContent = FileUtil.formatBytes(labelContent);        
    }

    if (column.contentType === "component") {
        const component = column.component
        const props = {
            referenceId: labelContent
        }
        if(column.labelField){
            props.label=getValue(column.labelField);
        }
        return React.cloneElement(component,props,null);
    }

    return(<Label>{labelContent}</Label>)

}

NavColumnLabel.defaultProps = {
    column: {
        name:"Label 1",
        fieldName: "label1",
        url:"/grc-library/{id}"
    },
    item: {
        id:"c968e930-79b0-42f4-a08e-d532ed1f4914"
    }
};

export default (NavColumnLabel);
