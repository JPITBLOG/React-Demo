import React from "react";
import PropTypes from 'prop-types';
import StringUtil from "../../util/StringUtil";

const EnumLabel = ({children,...restProps}) => {
    if(children){
        return(<span {...restProps}>{StringUtil.capitalize(children.toLowerCase())}</span>)
    }
    return null;
}

EnumLabel.propTypes = {
    children: PropTypes.string
}

export default EnumLabel;