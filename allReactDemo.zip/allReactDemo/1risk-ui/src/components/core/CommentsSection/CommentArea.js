import React, {useEffect, useState} from "react";
import {Button} from "react-bootstrap";
import FileUploadLink from "../FileUploadLink";

const CommentArea = React.forwardRef(({
  comment=null,
  attachments=[],
  onChange=()=>{},
  onSave=(e)=>console.log(e),
  onCancel=(e)=>console.log(e),
  isReply=false
},ref)=>{

    const [commentText,setCommentText] = useState("");
    const [displayCommentArea,setDisplayCommentArea] = useState(false);
    const [attachmentItems,setAttachmentItems] = useState([]);

    const onChangeHandler = (event)=>{
        const editedText = event.target.value;
        onChange({
            comment: editedText,
            attachments: attachments
        });
        setCommentText(editedText);
    }

    const onSaveHandler = (event)=>{
        onSave(commentText,attachmentItems);
        setDisplayCommentArea(false);
        setCommentText("");
    }

    const onCancelHandler = (event)=>{
        onCancel(event);
        setCommentText("");
        setDisplayCommentArea(false);
    }

    useEffect(() => {
        // Update the document title using the browser API
        if(comment){
            setCommentText(comment);
        }
        if(attachments.length > 0){
            setAttachmentItems(attachments);
        }
    },[comment,attachments]);

    const onFileUploadChange = (event)=>{
        onChange({
            comment: commentText,
            attachments: [...event]
        });
        setAttachmentItems([...event]);
    }

    if(displayCommentArea || isReply){
        return(<div className="comment-form-warp">
            <form className="comment-form" id="comment-form">
                <div ref={ref} className="form-group comment-input-field">
                    <textarea value={commentText}
                          onChange={onChangeHandler}
                          className="form-control" rows="3"
                          placeholder="Write a comment..."></textarea>
                    <FileUploadLink attachments={attachments} onChange={onFileUploadChange}>Add file(s)</FileUploadLink>
                </div>
                <div className="action-bar">
                    <Button style={{marginRight:"15px"}} disabled={commentText.length===0} variant="primary" onClick={onSaveHandler}>Submit</Button>
                    <Button variant="secondary" onClick={onCancelHandler}>Cancel</Button>
                </div>
            </form>
        </div>)
    }else{
        return(<div className="comment-form-warp"><Button variant="primary" onClick={()=>setDisplayCommentArea(!displayCommentArea)}>Add Comment</Button></div>);
    }


})

export default (CommentArea);