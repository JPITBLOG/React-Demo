import React, {Component} from 'react';
import {connect} from 'react-redux';
import * as actions from "../../../actions/CommentSectionActions"

import "./CommentSection.css";

import CommentSectionItem from "./CommentSectionItem";
import BrowserUtil from "../../../util/BrowserUtil";
import CommentArea from "./CommentArea";
import withEventBus from "../withEventBus";
import {COMMENT_DELETE, COMMENT_REPLY, COMMENT_REPLY_CLOSE, COMMENT_REPLY_OPEN} from "./events";
import ObjectUtil from "../../../util/ObjectUtil";
import UUIDUtil from "../../../util/UUIDUtil";
import {confirmAlert} from "react-confirm-alert";
import ConfirmWindow from "../ConfirmWindow";
import {CircularProgress} from "@material-ui/core";
import MainLoader from "../MainLoader";

class CommentsSection extends Component{

    static defaultProps={
        commentsData:{
            comments:[],
            total: 0
        }
    }

    constructor(props) {
        super(props);
        this.state= {
            name:UUIDUtil.v4(),
            loading: false,
            mainComment: "",
            isReplyOn: [],
            objectHash: "",
            initialLoad: true,
            lastCommentSaved: null
        }

        this.writeCommentRef = React.createRef();
        this.onLoadMoreCommentsHandler = this.onLoadMoreCommentsHandler.bind(this);
        this.onClickWriteCommentHandler = this.onClickWriteCommentHandler.bind(this);
        this.onSaveCommentHandler = this.onSaveCommentHandler.bind(this);
    }

    onLoadMoreCommentsHandler(event){
        event.preventDefault();
    }

    onClickWriteCommentHandler(event){
        BrowserUtil.scrollToBottom();
        this.writeCommentRef.current.children[0].focus();
        event.preventDefault();
    }

    onSaveCommentHandler(event,attachmentRequests){

        console.log(event,attachmentRequests);

        this.setState({loading:true})

        const {objectHash} = this.state;

        const commentToSave= {
            "objectHash": objectHash
        }

        if(attachmentRequests){
            commentToSave.attachments = attachmentRequests;
        }

        if(typeof event === "string"){
            commentToSave.comment=event;
        }else{
            commentToSave.comment=event.comment;
            commentToSave.parentId=event.parentId;
            if(event.attachments){
                commentToSave.attachments=event.attachments;
            }
        }

        if(event.id){
            commentToSave.id=event.id;
        }

        this.props.saveComment(commentToSave,(event,err)=>{
            if(!err){
                this.props.getComments(this.state.objectHash,(comments,err)=>{
                    this.setState({loading:false});
                });
                if(!event.parentId){
                    BrowserUtil.scrollToBottom();
                }
            }
        });

    }

    static getDerivedStateFromProps(props,state){
        if(props.objectName && props.objectId && !state.objectHash){
            state.objectHash = ObjectUtil.hash(props.objectName,props.objectId);
        }
        return state;
    }
    componentDidMount() {
        this.addEventListeners();
    }
    componentDidUpdate(prevProps, prevState, snapshot) {
        if(this.state.initialLoad && this.state.objectHash){
            this.loadComments();
            this.setState({initialLoad:false})
        }
    }

    loadComments(){
        this.setState({loading:true});
        this.props.getComments(this.state.objectHash,((comments,err)=>{
            this.setState({loading:false});
        }));
    }

    addEventListeners(){

        const {eventBus} = this.props;

        if(eventBus){
            eventBus.addEventListener(COMMENT_REPLY,(event)=>{
                const state = this.state;
                if(state.isReplyOn.length>0){
                    if(window.confirm("Your comment will be lost")){
                        eventBus.dispatch(COMMENT_REPLY_OPEN,{name:event.name});
                    }
                }else{
                    eventBus.dispatch(COMMENT_REPLY_OPEN,{name:event.name});
                    state.isReplyOn.push(event);
                    this.setState(state);
                }
            })
            eventBus.addEventListener(COMMENT_REPLY_CLOSE,()=>{
                this.setState({isReplyOn:[]});
            })
            eventBus.addEventListener(COMMENT_DELETE,(event)=>{

                const deleteRecord = ()=>{
                    this.props.deleteComment(event.id,(message,err)=>{
                        if(!err){
                            this.loadComments()
                        }
                    })
                }

                confirmAlert({
                    customUI: ({ onClose }) => <ConfirmWindow
                        headerText="Delete Comment"
                        infoText="Do you want to delete this comment?" onClose={onClose} onAction={deleteRecord}/>
                });

            })
        }
    }

    render() {

        const {comments,total} = this.props.commentsData;
        return(<div className="comment-wrap">
            <MainLoader display={this.state.loading}/>
            <div className="card">
                <div className="card-header">
                    <h3>comments <span className="orange">({total})</span></h3>
                </div>
                <div className="card-body">
                    <div className="comment-list-wrap">
                        <ul className="comment-list">
                            {comments.map((commentItem,index)=>{
                                return(<CommentSectionItem key={`comment-item-${index}`} commentData={commentItem} onSave={this.onSaveCommentHandler}/>);
                            })}
                        </ul>
                    </div>
                    <CommentArea ref={this.writeCommentRef} onSave={this.onSaveCommentHandler}/>
                </div>
            </div>
        </div>);
    }
}

const mapStateToProps = (state)=>{
    return(
        {
            savedComment:state.comments.savedComment,
            commentsData:state.comments.data
        });
}

export default withEventBus(connect(mapStateToProps,actions)(CommentsSection));