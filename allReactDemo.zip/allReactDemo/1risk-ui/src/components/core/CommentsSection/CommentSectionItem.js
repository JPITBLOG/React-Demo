import React, {Component} from "react";
import CommentArea from "./CommentArea";
import {NavLink} from "react-router-dom";
import withEventBus from "../withEventBus";
import UUIDUtil from "../../../util/UUIDUtil";
import {COMMENT_DELETE, COMMENT_REPLY, COMMENT_REPLY_CLOSE, COMMENT_REPLY_OPEN, COMMENT_SAVE} from "./events";
import DateUtil from "../../../util/DateUtil";
import AttachedFileList from "../AttachedFileList";
import CommentAttachments from "./CommentAttachments";

const REPLY_EVENT_TYPE = "reply-event-type"
const EDIT_EVENT_TYPE = "edit-event-type"

class CommentSectionItem extends Component{

    constructor(props) {
        super(props);
        this.state={
            replyMode:false,
            editMode:false,
            name:UUIDUtil.v4(),
            isLoggedUser:false,
            parentName:""
        }
        this.renderUserName = this.renderUserName.bind(this);
        this.onReplyHandler = this.onReplyHandler.bind(this);
        this.onSaveHandler = this.onSaveHandler.bind(this);
        this.onSaveEditHandler = this.onSaveEditHandler.bind(this);
        this.onCancelHandler = this.onCancelHandler.bind(this);
        this.onDeleteHandler = this.onDeleteHandler.bind(this);
        this.onEditHandler = this.onEditHandler.bind(this);
        this.onEditChangeHandler = this.onEditChangeHandler.bind(this)
    }
    componentDidMount() {
        const {eventBus} = this.props;
        if(eventBus){
            eventBus.addEventListener(COMMENT_REPLY_OPEN,(event)=>{
                this.setState({replyMode:this.state.name.toString()===event.name.toString()});
            })
            eventBus.addEventListener(COMMENT_SAVE,(event)=>{
                if(event.parentName.toString()===this.state.name){
                    this.saveComment(event);
                }
            })
            eventBus.addEventListener(COMMENT_REPLY_CLOSE,()=>{
                this.resetStateMode();
            })
        }
    }

    saveComment(event){

        console.log(event);

        const {commentData} = this.props;
        const sendEvent = {
            comment:event.comment
        }
        if(event.type===REPLY_EVENT_TYPE){
            sendEvent.parentId=commentData.id;
        }
        if(event.type===EDIT_EVENT_TYPE){
            sendEvent.id=event.id;
        }
        if(event.attachments){
            sendEvent.attachments=event.attachments;
        }
        this.props.eventBus.dispatch(COMMENT_REPLY_CLOSE,{name:this.state.name});
        this.props.onSave(sendEvent);
    }

    renderUserName(userInfo){
        if(userInfo){
            if(userInfo.loggedUser){
                return (<h5 className="user-name orange">{userInfo.fullName} (me)</h5>)
            }else{
                return (<h5 className="user-name">{userInfo.fullName} ({userInfo.companyName})</h5>)
            }
        }
    }

    onEditChangeHandler(event){
        const state = this.state;
        state.editComment=event.comment;
        state.editAttachments=event.attachments;
        console.log(event);
        this.setState(state);
    }

    onReplyHandler(event){
        this.props.eventBus.dispatch(COMMENT_REPLY,{name:this.state.name})
        event.preventDefault();
    }

    onEditHandler(event){
        const {comment,attachments}=this.props.commentData;
        this.setState({
            editMode:true,
            editComment:comment,
            editAttachments: attachments
        });
        event.preventDefault();
    }

    onDeleteHandler(event){
        this.props.eventBus.dispatch(COMMENT_DELETE,this.props.commentData);
        event.preventDefault();
    }

    onSaveHandler(event,attachmentRequests){

        const {commentData} = this.props;

        const request = {
            id:commentData.id,
            parentName:(this.state.parentName ? this.state.parentName : this.state.name),
            comment:event,
            parentId:commentData.parentId,
            type:REPLY_EVENT_TYPE
        }

        if(attachmentRequests){
            request.attachments=attachmentRequests;
        }

        this.props.eventBus.dispatch(COMMENT_SAVE,request);
    }

    onSaveEditHandler(event){
        const {commentData} = this.props;
        this.props.eventBus.dispatch(COMMENT_SAVE,
            {
                id:commentData.id,
                parentName:(this.state.parentName ? this.state.parentName : this.state.name),
                comment:event,
                parentId:commentData.parentId,
                attachments: this.state.editAttachments,
                type:EDIT_EVENT_TYPE
            });
    }

    onCancelHandler(event){
        this.props.eventBus.dispatch(COMMENT_REPLY_CLOSE,{name:this.state.name})
        this.resetStateMode()
    }

    resetStateMode(){
        const state = this.state;
        state.replyMode=false;
        state.editMode=false;
        this.setState(state);
    }

    static getDerivedStateFromProps(props,state){
        state.parentName=props.parentName;
        return state;
    }

    render() {
        const {userInfo,comment,updatedAt,reply,attachments} = this.props.commentData;
        const {replyMode,editMode,editComment,name,editAttachments} = this.state;
        return(<li>
            {this.renderUserName(userInfo)}
            {!editMode && <p className="comment-text">{comment}</p>}
            {!editMode && <CommentAttachments attachments={attachments}/>}
            {editMode && <CommentArea isReply={true}
                                      onChange={this.onEditChangeHandler}
                                      onSave={this.onSaveEditHandler}
                                      onCancel={this.onCancelHandler}
                                      attachments={editAttachments}
                                      comment={editComment}/>}
            {!replyMode && !editMode && <div className="comment-bottom">
                <div className="left">
                    <NavLink className="comment-reply-btn" to="/" onClick={this.onReplyHandler}>Reply</NavLink>
                    {userInfo?.loggedUser && <NavLink to="/" onClick={this.onEditHandler} className="comment-reply-btn">Edit</NavLink>}
                    {userInfo?.loggedUser && <NavLink to="/" onClick={this.onDeleteHandler} className="comment-reply-btn">Delete</NavLink>}
                </div>
                <div className="right">
                    <span className="comment-date">{DateUtil.format(updatedAt)}</span>
                </div>
            </div>}
            <ul className="child-comment">
                {replyMode && <li><CommentArea isReply={true} onSave={this.onSaveHandler} onCancel={this.onCancelHandler}/></li>}
                {reply.map((replayComment,index)=>{
                    return(<CommentSectionItem
                        key={`replay-comment-${index}`}
                        commentData={replayComment}
                        parentName={name}
                        eventBus={this.props.eventBus}
                    />);
                })}
            </ul>
        </li>)
    }
}

export default withEventBus(CommentSectionItem);