export const COMMENT_REPLY = "comment-reply";
export const COMMENT_REPLY_CLOSE = "comment-reply-close";
export const COMMENT_REPLY_OPEN = "comment-reply-open";
export const COMMENT_SAVE = "comment-save";
export const COMMENT_DELETE = "comment-delete";