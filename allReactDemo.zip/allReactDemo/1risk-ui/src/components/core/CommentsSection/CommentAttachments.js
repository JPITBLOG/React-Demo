import React from "react";
import styled from "styled-components";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faDownload, faTimesCircle} from "@fortawesome/free-solid-svg-icons";
import FileUtil from "../../../util/FileUtil";
import {getDownloadAttachment} from "../../../actions";
import {useDispatch} from 'react-redux';

const AttListContainer = styled("ul")`
    margin: 0px;
    padding: 0px;
    list-style: none;
    font-size: 13px;
    color: #494A4C;
    margin-top: 10px;
`

const AttachmentLabel = styled(({name,size,onDownload,...restProps})=>{
    return(<li onClick={onDownload} {...restProps}>
        <FontAwesomeIcon fixedWidth icon={faDownload}/>
        <span>{name} ({FileUtil.formatBytes(size,0)})</span>
    </li>)
})`
    cursor: pointer;
    margin-bottom: 5px !important;
    & svg{
        margin-right: 5px;
    }
`;

const CommentAttachments = ({attachments,editMode=false,...restProps}) =>{

    const dispatch = useDispatch();

    const onDownloadHandler = (event) =>{
        const idx = event.currentTarget.dataset.idx;
        dispatch(getDownloadAttachment(attachments[idx].referenceId,(attachmentRes,err)=>{
            if (!err) {
                window.open(attachmentRes,"_blank");
            }
        }));
        event.preventDefault();
    }

    const onDeleteHandler = (event) =>{
        console.log(event);
        event.preventDefault();
    }

    if(attachments && attachments.length > 0){
        return(<AttListContainer>
            {attachments.map((attachment,index)=>
                <AttachmentLabel key={`AttListItem-${index}`}
                                 data-idx={index}
                                 name={attachment.name}
                                 size={attachment.size}
                                 onDownload={onDownloadHandler}
                />)}
        </AttListContainer>);
    }

    return null;
}

export default (CommentAttachments);
