import {
    withStyles
} from "@material-ui/core/styles";
import Tooltip from '@material-ui/core/Tooltip'

const AttachTooltip = withStyles({
    tooltip: {
        color: "white",
        backgroundColor: "#4d4646",
        padding:'6px 10px',
        fontSize:'12px',
        whiteSpace:"pre-line",
        width:'100%',
        lineHeight: '17px'
    }
})(Tooltip);

export default AttachTooltip