import React, { useState } from "react";
import * as Datetime from 'react-datetime';
import "./datePicker.css";
import { makeStyles } from '@material-ui/core/styles';
import TextField from "@material-ui/core/TextField";
import { MuiPickersUtilsProvider, KeyboardDatePicker } from "@material-ui/pickers";
import DateFnsUtils from '@date-io/date-fns';


const DatePickerSelector = ({ optionValues, filterList, onChange, index, column }) => {

    const [selectedDate, setSelectedDate] = useState(null);

    const onDateChange = (event) => {
        let date = event.currentTarget.value;
        debugger
            // "2020-06-25T19:50:30"
            // "2020-06-25T19:50:30"
            // let isoDateArray = new Date(date).toISOString().split('.');
            // let withoutTimeValue = isoDateArray[0].split('T');
            // let completeDateWithTime = withoutTimeValue[0] + "T19:50:30";
            // console.log('date with complete: ', completeDateWithTime);
            // debugger
            // filterList[index] = [completeDateWithTime];
            // setSelectedDate(date);

            setSelectedDate(date);
            // date =date + ':30';
            filterList[index] = [date];
            debugger
            // setSelectedDate(date);
    }


    return (
        <div>
            <Datetime onChange={onDateChange} />
        </div>
        // <MuiPickersUtilsProvider utils={DateFnsUtils}>
        //     <KeyboardDatePicker
        //         autoOk
        //         variant="inline"
        //         label={column.label}
        //         format="MM/dd/yyyy"
        //         value={selectedDate}
        //         InputAdornmentProps={{ position: "end" }}
        //         onChange={onDateChange}
        //     />
        // </MuiPickersUtilsProvider>
        // <form className={classes.container} noValidate>
        //     <TextField
        //         id="datetime-local"
        //         label="Next appointment"
        //         type="datetime-local"
        //         // defaultValue="2017-05-24T10:30"
        //         value={selectedDate}
        //         className={classes.textField}
        //         InputLabelProps={{
        //             shrink: true,
        //         }}
        //         onChange={onDateChange}
        //     />
        // </form>

                // <div className="container">
                //     <div className="row">
                //         <div className='col-sm-6'>
                //             <div className="form-group">
                //                 <div className='input-group date' id='datetimepicker1'>
                //                     <input type='text' className="form-control"/>
                //                     <span className="input-group-addon">
                //         <span className="glyphicon glyphicon-calendar"></span>
                //     </span>
                //                 </div>
                //             </div>
                //         </div>
                //     </div>
                // </div>
    )
}

export default DatePickerSelector;
