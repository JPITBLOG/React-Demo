import React, {useEffect, useState} from "react";

import './AttributesContainer.css';
import {Card} from "react-bootstrap";
import DefaultItemChip from "../DefaultItemChip";
import DateUtil from "../../../util/DateUtil";
import {NavLink} from "react-router-dom";

const AttributesContainer = ({attributes=[]}) =>{

    const [visible,setVisible] = useState(false);

    useEffect(() => {
        if(attributes!== undefined && attributes.length > 0){
            let totalAttributes = 0;
            attributes.forEach((attribute)=>{
                if(attribute.type==="link" && attribute.content.url.length>0){
                    totalAttributes++;
                }
                if(attributes!== undefined && attribute.content.length>0){
                    totalAttributes++;
                }
            })
            setVisible(totalAttributes>0);
        }
    },[attributes,setVisible])

    const renderSection = (attribute,index)=>{

        if(attribute.content.length===0){
            return null;
        }

        switch (attribute.type) {
            case "chip":
                return(<section key={`section-${attribute.title}-${index}`}>
                    <Card.Title>{attribute.title}</Card.Title>
                    {attribute.content.map((chipContent,index)=>{
                        return(<DefaultItemChip className="card-chip" key={`chip-${attribute.title}-${index}`} label={chipContent}/>)
                    })}
                </section>);
            case "date":
                return(<section key={`section-${attribute.title}-${index}`}>
                    <Card.Title>{attribute.title}</Card.Title>
                    <Card.Text>{DateUtil.format(attribute.content)}</Card.Text>
                </section>);
            case "link":
                const {label,url} = attribute.content;
                return(<section key={`section-${attribute.title}-${index}`}>
                    <Card.Title>{attribute.title}</Card.Title>
                    <Card.Text><NavLink to={url}>{label}</NavLink></Card.Text>
                </section>);
            default:
                return(<section key={`section-${attribute.title}-${index}`}>
                    <Card.Title>{attribute.title}</Card.Title>
                    <Card.Text>{attribute.content}</Card.Text>
                </section>)
        }

    }

    if(visible){
        return(<div className="attribute-container">
            <Card>
                <Card.Header>Attributes</Card.Header>
                <Card.Body>
                    {attributes.map((attribute,index) => {
                        return(renderSection(attribute,index));
                    })}
                </Card.Body>
            </Card>
        </div>);
    }else{
        return null;
    }

}

export default (AttributesContainer);