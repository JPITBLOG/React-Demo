import React, {Component} from 'react';
import {connect} from "react-redux";
import * as actions from '../../actions';

import ApplicationMainMenu from "./ApplicationMainMenu/";
// import LoginPageFooter from "./LoginPageFooter";

import './ApplicationContainer.css';
import './BootstrapReset.css';
import {Col, Row} from "react-bootstrap";
import MainPageHeader from "./MainPageHeader";
import withEventBus from "./withEventBus";
import {WINDOW_FULLSCREEN, WINDOW_RESIZED} from "../../events/types";
import UUIDUtil from "../../util/UUIDUtil";

import {withRouter} from "react-router";
import TopActionBar from "./TopActionBar";
import BottomActionBar from "./BottomActionBar";
import MenuToggleButton from "./MenuToggleButton";

class ApplicationContainer extends Component{

    constructor(props) {
        super(props);
        this.state={
            name:UUIDUtil.v4(),
            auth:false,
            fullScreen:false,
            isMobile:false,
            lastPathname:"",
            isToggle:false
        }
        this.onWindowFullscreenHandler = this.onWindowFullscreenHandler.bind(this);
        this.onWindowResized = this.onWindowResized.bind(this);
        this.onMenuToggleHandler = this.onMenuToggleHandler.bind(this);
    }

    componentDidMount() {
        this.props.loadMainMenu(true);
        this.props.loadAccounts();
        this.props.eventBus.addEventListener(WINDOW_FULLSCREEN,this.onWindowFullscreenHandler);
        this.props.eventBus.addEventListener(WINDOW_RESIZED,this.onWindowResized)
    }

    onWindowResized(event){
        const state = this.state;
        state.isToggle = event.mobile;
        state.fullScreen = event.mobile;
        this.setState(state)
    }

    onWindowFullscreenHandler(event){
        this.setState({fullScreen:event});
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if(prevProps.isMobile!==this.props.isMobile){
            this.setState({fullScreen:this.props.isMobile});
        }
        if(prevProps.history.location.pathname!==this.state.lastPathname){
            const state = this.state;
            state.lastPathname=prevProps.history.location.pathname;
            if(state.lastPathname==='/grc-library/obligation-sections'){
                this.props.resetObligation();
            }
            if(state.isMobile){
                state.fullScreen=true;
            }
            this.setState(state);
        }
    }

    onMenuToggleHandler(event){
        this.setState({isToggle:event});
    }

    render() {
        if(this.props.auth) {
            return (
                <div id="site-root">
                    <TopActionBar/>
                    <Row className={`top-container ${this.state.fullScreen ? "hide-menu" : "show-menu"}`}>
                        <Col className="menu-container" lg={2}>
                            <MenuToggleButton isToggle={this.state.isToggle} onToggle={this.onMenuToggleHandler}/>
                            <ApplicationMainMenu {...this.props}/>
                        </Col>
                        <Col className="root-container" lg={10}>
                            <MenuToggleButton isToggle={this.state.isToggle} onToggle={this.onMenuToggleHandler}/>
                            <MainPageHeader/>
                            {this.props.children}
                        </Col>
                    </Row>
                    <BottomActionBar/>
                </div>
            )
        } else{
            // Login Screens
            return (<div id="site-root">
                {this.props.children}
                <BottomActionBar/>
                {/* <LoginPageFooter/> */}
            </div>)
        }
    }

}

function mapStateToProps(state){
    return {
        auth: state.auth.authenticated,
        menuItems: state.menu.menuItems,
        accounts: state.menu.accounts
    }
}

export default withRouter(withEventBus(connect(mapStateToProps,actions)(ApplicationContainer)));
