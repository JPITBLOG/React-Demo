import React from "react";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faAngleDown, faAngleUp} from "@fortawesome/free-solid-svg-icons";

const OrderListIcon = ({direction="ASC",...restProps}) =>{
    return(<FontAwesomeIcon {...restProps} className="order-list-icon" style={{cursor:"pointer"}} icon={direction === "ASC" ? faAngleDown : faAngleUp}/>)
}

export default OrderListIcon;