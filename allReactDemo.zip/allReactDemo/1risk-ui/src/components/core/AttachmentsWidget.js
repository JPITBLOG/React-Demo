import React from 'react';
import styled from "styled-components";
import {Card} from "react-bootstrap";
import FileLink from "./FileLink";

const AttachmentsList = styled('ul')`
    font-size: 14px;
    font-family: inherit;
    list-style-type: none;
    padding: 0px;
`;

const AttachmentListItem = styled('li')`
    margin-bottom: 10px;
`;

const AttachmentsWidget = ({attachments=[],...restProps})=>{

    if(attachments.length===0){
        return null;
    }

    return(
        <Card {...restProps}>
            <Card.Header>Attachments</Card.Header>
            <Card.Body>
                <AttachmentsList>
                    {attachments.map((doc, index) =>
                        <AttachmentListItem>
                            <FileLink key={`attachment-list-item-${index}`} fileName={doc.name} fileSize={doc.size} referenceId={doc.referenceId}/>
                        </AttachmentListItem>)}
                </AttachmentsList>
            </Card.Body>
        </Card>)
}

export default (AttachmentsWidget);