import React, {Component} from 'react';
import {Collapse} from 'react-bootstrap';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {NavLink} from "react-router-dom";
import {library} from '@fortawesome/fontawesome-svg-core'
import {fas} from '@fortawesome/free-solid-svg-icons'
import {far} from '@fortawesome/free-regular-svg-icons';
import {withRouter} from 'react-router';

class ApplicationMenuItem extends Component{

    static defaultProps={
        childrenItems:[],
        enabled:true
    }

    constructor(props) {
        super(props);
        this.state={
            isOpen:false,
            icon:"",
            label:"",
            url:"/",
            childrenItems:[],
            eventListenerSet: false,
            disabled: false,
            lastPathname:null
        }

        library.add(fas,far)

        this.toggleMenu = this.toggleMenu.bind(this);
        this.noNavigationHandler = this.noNavigationHandler.bind(this);
        this.openParent = this.openParent.bind(this);

    }

    toggleMenu(event){
        this.setState({isOpen:!this.state.isOpen})
        event.preventDefault();
    }

    static getDerivedStateFromProps(props,state){
        if(props.open){
            state.isOpen = props.open;
        }
        state.icon=props.icon;
        state.label=props.label;
        state.url=props.url;
        state.childrenItems=props.childrenItems;
        state.disabled = props.disabled;
        return state;
    }

    renderChildren(){
        let items = [];
        let i = 1;
        this.state.childrenItems.forEach(menuItem => {
            items.push(<ApplicationMenuItem
                key={i} icon={menuItem.icon}
                label={menuItem.label}
                url={menuItem.url}
                onClick={(e)=>{ if(menuItem.disabled){e.preventDefault()} }}
                childrenItems={menuItem.childrenItems}
            />)
            i=i+1;
        })
        return items.length === 0 ? null : items;
    }

    noNavigationHandler(event){
        event.preventDefault()
    }

    getMenuItemClasses(){
        let classes = [];
        if(this.state.childrenItems.length > 0){
            classes.push("has-child");
        }
        if(this.state.disabled){
            classes.push("disabled");
        }
        return classes.length > 0 ? classes.join(" ") : null;
    }

    componentDidMount() {
        this.openParent();
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if(this.props.history){
            if(this.state.lastPathname !== this.props.history.location.pathname){
                this.setState({"lastPathname":this.props.history.location.pathname});
                this.openParent();
            }
        }
    }

    openParent(){
        if(this.props.childrenItems.length > 0){
            const activeLocation = this.props.history.location.pathname;
            const children = this.props.childrenItems.filter((item)=> activeLocation.includes(item.url));
            if(children.length>0){
                this.setState({isOpen:true});
            }
        }
    }

    isActiveHandler(match, location){
        if(match && match.url.length>0){
            return location.pathname.includes(match.url);
        }
        return false;
    }

    render(){

        const {icon,label,url,childrenItems,isOpen} = this.state

        if(!icon && !url){
            return (<li><NavLink exact to="/Admin" onClick={this.noNavigationHandler}><span>{label}</span></NavLink></li>)
        }

        return(<li className={this.getMenuItemClasses()}>

            {childrenItems.length === 0 && !url && <NavLink isActive={this.isActiveHandler} onClick={this.toggleMenu} to="/">
                {icon && <span><FontAwesomeIcon fixedWidth icon={icon}/>&nbsp;&nbsp;&nbsp;</span>}
                <span>{label}</span>
            </NavLink>}

            {childrenItems.length === 0 && url && <NavLink isActive={this.isActiveHandler} onClick={(e)=>{ if(this.state.disabled){e.preventDefault()} }} to={url}>
                {icon && <span><FontAwesomeIcon fixedWidth icon={icon}/>&nbsp;&nbsp;&nbsp;</span>}
                <span>{label}</span>
            </NavLink>}

            {childrenItems.length > 0 && <NavLink isActive={this.isActiveHandler} onClick={this.toggleMenu} to={url ? url : "/"}>
                {icon && <span><FontAwesomeIcon fixedWidth icon={icon}/>&nbsp;&nbsp;&nbsp;</span>}
                <span>{label}</span>
            </NavLink>}

            {childrenItems.length > 0 &&
            <Collapse in={isOpen}>
                <ul className="sub-menu">
                    {this.renderChildren()}
                </ul>
            </Collapse>}
        </li>);

    }
}

export default withRouter(ApplicationMenuItem)