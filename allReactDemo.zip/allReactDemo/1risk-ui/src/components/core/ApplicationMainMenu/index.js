import React, {Component} from 'react';
import ApplicationMenuItem from "./ApplicationMenuItem";

import PropTypes from "prop-types";
import {withRouter} from "react-router";

import './ApplicationMainMenu.css';
import withEventBus from "../withEventBus";

class ApplicationMainMenu extends Component{

    static defaultProps={
        menuItems:[],
        accounts:[],
        display:false
    }

    static propTypes = {
        match: PropTypes.object.isRequired,
        location: PropTypes.object.isRequired,
        history: PropTypes.object.isRequired
    };

    constructor(props) {
        super(props);
        this.state={
            menuItems:[],
            accounts:[],
        }

        this.toggleMenu = this.toggleMenu.bind(this);

    }

    toggleMenu(event){
        this.setState({isOpen:!this.state.isOpen})
        event.preventDefault();
    }

    static getDerivedStateFromProps(props,state) {
        state.menuItems=props.menuItems;
        state.accounts=props.accounts;
        return state;
    }

    render() {

        const {menuItems} = this.state;

        if(!this.props.display){
            return(<aside id="side-nav" className="side-nav-wrap">
                <nav className="nav-menu">
                    <ul className="main-menu">
                        {menuItems.map((menuItem,index) => {
                            return(<ApplicationMenuItem
                                key={index}
                                icon={menuItem.icon}
                                label={menuItem.label}
                                url={menuItem.url}
                                childrenItems={menuItem.childrenItems}
                                disabled={menuItem.disabled}
                                actualPath={this.props.location.pathname}
                            />);
                        })}
                    </ul>
                </nav>
            </aside>)
        }

        return null;
    }
}

export default withRouter(withEventBus(ApplicationMainMenu))