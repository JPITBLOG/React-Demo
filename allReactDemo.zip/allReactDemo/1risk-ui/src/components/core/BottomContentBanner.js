import React from "react";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faQuestionCircle} from "@fortawesome/free-regular-svg-icons";
import CustomAlert from "./CustomAlert";
import {Row} from "react-bootstrap";
import ExternalLink from "./ExternalLink";

import './BottomContentBanner.css';

export default () => {
    return(<div className="content-footer">
        <CustomAlert className="bottom-alert">
            <Row>
                <div className="icon">
                    <FontAwesomeIcon size={"3x"} icon={faQuestionCircle}/>
                </div>
                <div className="content">
                    Cant find what you are looking for? Have app suggestions? <br/>
                    Contact us at <ExternalLink to="mailto:support@cb1security.com">support@cb1security.com</ExternalLink>
                </div>
            </Row>
        </CustomAlert>
    </div>)
}