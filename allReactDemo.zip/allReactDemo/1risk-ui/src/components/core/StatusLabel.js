import React from 'react';
import styled from "styled-components";

export const ACCOUNT_ACTIVE_STATUS = "active";
export const ACCOUNT_INACTIVE_STATUS = "inactive";
export const ACCOUNT_PENDING_STATUS = "pending";

const StatusLabelComponent = styled((props) => <span {...props}>{props.children}</span>)`
    
    display: inline-block;
    color: ${props => {
        switch (props.status.toLowerCase()) {
            case 'active':
                return '#228B22';
            case 'pending':
                return '#FA7C00';
            case 'inactive':
                return '#DC143C';
            case 'deactivated':
                return '#DC143C';
            default:
                return '#494A4C';
        }
    }}
`;

const StatusLabel = ({ children,status = '' }) => {
    if(children){
        return (
            <StatusLabelComponent status={status}>
                {children}
            </StatusLabelComponent>
        )
    }

    return null;

}

export default (StatusLabel);
