import React, {useEffect, useState} from "react";

import './RadioGroup.css'
import RadioButtonIcon from "../RadioButtonIcon";

const RadioGroup = ({options=[],inline=false,onChange=()=>null,defaultValue=null}) => {

    const [selectedItem,setSelectedItem] = useState();

    useEffect(() => {
        if(selectedItem!==defaultValue){
            setSelectedItem(defaultValue);
        }
    },[selectedItem,defaultValue])

    const onClickHandler = (event) =>{
        setSelectedItem(event.value);
        onChange(event.value);
    }

    return(<div className="radio-group">
        <div className={`radio-group-container ${ inline ? "radio-group-inline" : ""}`}>
            {options.map((item,index)=>{
                return(<div
                    className="radio-group-option"
                    data-value={item.value}
                    key={`radio-group-option-${index}`}
                    onClick={()=>onClickHandler(item)}>
                        <RadioButtonIcon selected={item.value === selectedItem}/>{item.label}
                </div>)
            })}
        </div>
    </div>)

}

export default (RadioGroup)