import React, {useCallback, useState} from 'react'
import {useDropzone} from 'react-dropzone'
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome"
import PropTypes from 'prop-types';

import './FileUploadDropzone.css';
import FileUtil from "../../../util/FileUtil";
import SpinnerContainer from "../SpinnerContainer";

const FileUploadDropzone = ({ fileMaxSize, isMultiple, acceptExtensions, loading, onLoad, isAttachment }) => {

    const [errorMessage, setErrorMessage] = useState("");

    const mainClassName = "file-dropzone";

    const onDrop = useCallback((acceptedFiles) => {
        acceptedFiles.forEach((file) => {

            const reader = new FileReader();

            const fileInfo = {
                name: file.name,
                lastModified: file.lastModified,
                size: file.size,
                type: file.type,
                path: file.path,
            }

            reader.onabort = () => console.log('file reading was aborted')
            reader.onerror = () => console.log('file reading has failed')
            reader.onload = () => {
                fileInfo.data = reader.result.split(",")[1];
                onLoad(fileInfo);
            }
            reader.readAsDataURL(file)
        })

    }, [onLoad])

    const {
        getRootProps,
        getInputProps,
        isDragActive,
        isDragReject,
        rejectedFiles
    } = useDropzone({ onDrop, accept: acceptExtensions, maxSize: fileMaxSize, multiple: isMultiple })

    if (rejectedFiles.length > 0) {
        let message = "";
        if (rejectedFiles[0].size > fileMaxSize) {
            message = `File is too big (max: ${FileUtil.formatBytes(fileMaxSize)})`;
        } else {
            message = `Invalid file format (${rejectedFiles[0].type})`;
        }
        if (errorMessage !== message) {
            setErrorMessage(message);
        }
    }

    return (
        <div className={mainClassName}>
            <div className="uploader" {...getRootProps()}>

                <SpinnerContainer visible={loading} />

                <input {...getInputProps()} />

                <div className="icon"><FontAwesomeIcon fixedWidth icon={"cloud-upload-alt"} /></div>

                {!isDragActive && <p>Drop files here or <span className="link">Browse</span></p>}

                {errorMessage.length > 0 && <div className="error-message">{errorMessage}</div>}

                {isDragReject && (<div className="error-message">Invalid file</div>)}

                <ul className="instructions">
                    <li> File formats supported</li>
                    <li> .pdf, .doc, .docx, .ppt, .pptx, .xls, .xlsx, .gif, .jpg, .png, .csv, .txt, .rtf</li>
                    <li> Maximum file size limit is 25 MB</li>
                </ul>

            </div>
        </div>
    )
}



FileUploadDropzone.propTypes = {
    fileMaxSize: PropTypes.number,
    multiple: PropTypes.bool,
    acceptExtensions: PropTypes.string,
    loading: PropTypes.bool,
    onLoad: PropTypes.func
}

const extensions=[
    "image/*",
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-powerpoint",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/rtf",
    "text/csv",
    "text/plain"
]

FileUploadDropzone.defaultProps = {
    fileMaxSize: 25000000,
    multiple: false,
    acceptExtensions: extensions.join(","),
    loading: false,
    onLoad: () => null,
    isAttachment: false
}

export default React.memo(FileUploadDropzone);