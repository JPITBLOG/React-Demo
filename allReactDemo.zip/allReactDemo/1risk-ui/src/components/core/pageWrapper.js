import React, {Component} from 'react';
import {connect} from 'react-redux';
import {withRouter} from 'react-router';
import requireAuth from "./requireAuth";
import * as actions from '../../actions/'
import withEventBus from "./withEventBus";
import {WINDOW_RESIZED} from "../../events/types";
import UUIDUtil from "../../util/UUIDUtil";
import {compose} from "redux";

export const PAGE_TYPE_ADD = "Add";
export const PAGE_TYPE_EDIT = "Edit";
export const PAGE_TYPE_VIEW = "View";
export const PAGE_TYPE_LIST = "List";

export default (ChildComponent) =>{
    class PageWrapper extends Component{

        constructor(props) {
            super(props);
            this.state={
                pageId: UUIDUtil.v4(),
                windowSize:{
                    width: 0,
                    height: 0
                },
                isMobile:false,
                loadingStack:[],
                basePageTitle:"1Risk Portal"
            }
            this.onPageLoadHandler = this.onPageLoadHandler.bind(this);
            this.onWindowResize = this.onWindowResize.bind(this);
            this.onApiLoading = this.onApiLoading.bind(this);
            this.onApiLoaded = this.onApiLoaded.bind(this);
            this.onUpdateMenuActionsHandler = this.onUpdateMenuActionsHandler.bind(this);
        }

        componentDidUpdate(prevProps, prevState, snapshot) {
            this.shouldResetHeader()
        }

        componentDidMount() {
            window.addEventListener("resize",this.onWindowResize);
            // window.addEventListener(API_LOADING,this.onApiLoading);
            // window.addEventListener(API_LOADED,this.onApiLoaded);
            this.onWindowResize();
            this.shouldResetHeader()
        }

        componentWillUnmount() {
            window.removeEventListener("resize",this.onWindowResize);
            // window.removeEventListener(API_LOADING,this.onApiLoading);
            // window.removeEventListener(API_LOADED,this.onApiLoaded);
            this.props.loadTopMenuActions([],false,false);
        }

        shouldResetHeader(){
            const { id } = this.props.match.params;
            if(id === undefined){
                this.props.resetDetailHeader();
            }
        }

        onPageLoadHandler(event){

            const {breadcrumb,pageDescription} = event;
            const {basePageTitle} = this.state;

            if(breadcrumb){
                breadcrumb.uri=this.props.location.pathname;
                this.props.sendBreadcrumbData(breadcrumb);
            }

            if(pageDescription){
                let pageTitle = `${basePageTitle} - ${pageDescription.label} List`;
                if(pageDescription.type){
                    pageTitle = `${basePageTitle} - ${pageDescription.label} ${pageDescription.type}`;
                }
                document.title = pageTitle;
            }

        }

        onUpdateMenuActionsHandler(actions,enableCancel){
            this.props.loadTopMenuActions(actions,enableCancel,true);
        }

        onWindowResize(){
            const state = this.state;
            const windowSize={
                width: window.innerWidth,
                height: window.innerHeight,
                mobile: false
            }

            if(windowSize.width <= 1024 && windowSize.height <= 768){
                windowSize.mobile=true;
            }

            state.windowSize=windowSize;
            this.setState(state);
            this.props.eventBus.dispatch(WINDOW_RESIZED,windowSize);
        }

        onApiLoading(event){
            const {loadingStack} = this.state;
            loadingStack.push(event.detail);
            this.setState(loadingStack);
        }

        onApiLoaded(event){
            const loadingStack = this.state.loadingStack.filter((eventItem)=> {
                return eventItem.url !== event.detail.responseUrl
            });
            this.setState(loadingStack);
        }

        render() {
            return (
                <ChildComponent onMenuActionLoad={this.onUpdateMenuActionsHandler} onPageLoad={this.onPageLoadHandler} {...this.props}/>
            );
        }
    }

    return compose(requireAuth,withEventBus,withRouter,connect(null,actions))(PageWrapper);

}