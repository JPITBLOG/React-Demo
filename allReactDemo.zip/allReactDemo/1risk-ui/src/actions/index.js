import axios from 'axios';
import LocalStorageUtil from "../util/LocalStorageUtil";
import UUIDUtil from "../util/UUIDUtil";
// import moment from "moment";

axios.defaults.baseURL = process.env.REACT_APP_API_URL;

const notRequireAuthURLs = ['/signin','/signup'];

const isHandlerEnabled = (config={}) => {
    return !(config.hasOwnProperty('handlerEnabled') && !config.handlerEnabled);
};

// const willRefresh = (token)=>{
//     console.log(moment(token.lastLoginAt).fromNow().split(" "));
// }

const requestHandler = (request) => {
    // ApiUtil.loadingInProgress(request);
    if (isHandlerEnabled(request) && !notRequireAuthURLs.includes(request.url)) {
        const tokenObj = LocalStorageUtil.getObjectItem("token");
        if(tokenObj){
            request.headers['Authorization'] = "Bearer "+tokenObj['access_token'];
        }
        request.headers['Request-Id'] = UUIDUtil.v4();
    }
    return request;
};

const responseHandler = (response) =>{
    // ApiUtil.loadingComplete(response.request);
    return response;
}

axios.interceptors.request.use(
    request => requestHandler(request)
);

axios.interceptors.response.use(
    response => responseHandler(response)
)

export * from './AuthActions';
export * from './DashboardActions';
export * from './MenuActions';
export * from './GrcLibraryActions';
export * from './FilterActions';
export * from './ControlListViewActions';
export * from './PageActions';
export * from './TreeViewActions';
export * from './CommentSectionActions';
export * from './ErrorDispatchActions';
export * from './Attachments';
export * from './ObligationActions';
export * from './ObligationSectionActions';
export * from './CrosswalksActions';
export * from './NotesActions';
export * from './ControlLibraryActions';
export * from './TopMenuActions';
export * from './HistoryActions';
export * from './SystemMessageAction';
export * from './BulkUpdateActions';
export * from './AccountsAction';
export * from './UsersActions';