import {LOAD_ACCOUNTS, LOAD_MAIN_MENU} from "./types";

export const loadMainMenu = (admin) => async dispatch => {
    const data = [
        {
            icon: "th-large",
            label:"Dashboard",
            url:"/dashboard"
        },
        {
            icon: "book",
            label:"GRC Library",
            refUrl:"/grc-library",
            childrenItems:[
                {
                    label:"Obligations",
                    url:"/grc-library/obligations",
                },
                {
                    label:"Obligation Sections",
                    url:"/grc-library/obligation-sections",
                },
                {
                    label:"Control Libraries",
                    url:"/grc-library/control-libraries",
                },
                {
                    label:"Crosswalks",
                    url:"/grc-library/crosswalks",
                }
            ]

        },
        {
            icon: "globe",
            label:"Enterprise Risk",
            url:"/enterprise",
            disabled: true
        },
        {
            icon: "check-double",
            label:"Policies",
            url:"/policies",
            disabled: true
        },
        {
            icon: "clipboard-check",
            label:"Compliance",
            url:"/compliance",
            disabled: true
        },
        // {
        //     icon: "tasks",
        //     label:"Risk Registry",
        //     url:"/risk-registry",
        //     disabled: true
        // },
        {
            icon: "suitcase",
            label:"Vendors",
            url:"/vendors",
            disabled: true
        },
        {
            icon: "flag",
            label:"Issues",
            url:"/issues",
            disabled: true
        },
    ];

    const adminItems = {
        icon: "cog",
        label:"Administration",
        refUrl:"/admin",
        childrenItems:[
            {
                label:"Manage Accounts",
                url:"/admin/accounts",
            },
            {
                label:"Manage Users",
                url:"/admin/users",
            },
            {
                label:"Email Notifications",
                url:"/admin/notifications",
            },
            {
                label:"Logs",
                url:"/admin/logs",
            },
        ]
    }


    if(admin){
        data.push(adminItems);
    }

    data.push({
        label:"Support Center",
        icon: "question-circle",
    });

    dispatch({
        type: LOAD_MAIN_MENU,
        payload: data
    });

}

export const loadAccounts = () => async dispatch => {

    const data = [
        {
            label:"Account 1",
            value: 234900
        },
        {
            label:"Account 2",
            value: 234901
        }
    ];

    dispatch({
        type: LOAD_ACCOUNTS,
        payload: data
    });

}

export const toggleMenu = () => async dispatch => {

}