import axios from "axios";
import ApiUtil from "../util/ApiUtil";
import ObjectUtil from "../util/ObjectUtil";
import {
    ATTACHMENT_UPLOAD, LOGO_UPLOAD, LOAD_ATTACHMENTS_DATA, DOWNLOAD_ATTACHMENT, DELETE_ATTACHMENTS,
    LOAD_ATTACHMENTS_TABLE_FILTERS
} from "./types";

export const uploadLogo = (fileInfo, callback = (e, err) => null) => async dispatch => {
    try {
        const response = await axios.post('/api/attachment/logo', fileInfo);
        dispatch({
            type: LOGO_UPLOAD,
            payload: response.data
        });
        callback(response.data);

    } catch (e) {
        callback(null, e);
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const uploadAttachment = (fileInfo, callback = (e, err) => null) => async dispatch => {
    try {
        const response = await axios.post('/api/attachment', fileInfo);
        dispatch({
            type: ATTACHMENT_UPLOAD,
            payload: response.data
        });
        callback(response.data);

    } catch (e) {
        callback(null, e);
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const uploadAttachments = (fileInfos, callback = (e, err) => null) => async dispatch => {
    try {
        const response = await axios.post('/api/attachment/all', fileInfos);
        dispatch({
            type: ATTACHMENT_UPLOAD,
            payload: response.data
        });
        callback(response.data);

    } catch (e) {
        callback(null, e);
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const getAttachmentData = (filter, pagination, callback = () => null) => async dispatch => {
    try {

        const config = {};

        if (pagination) {
            config.params = ObjectUtil.clone(pagination);
        }

        if (filter) {
            if (!config.params) {
                config.params = {}
            }
            config.params.filters = btoa(JSON.stringify(filter))
        }

        const response = await axios.get(`/api/attachment/`, config);
        dispatch({
            type: LOAD_ATTACHMENTS_DATA,
            payload: response.data
        });
        callback();
    } catch (e) {
        callback();
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const getDownloadAttachment = (id, callback) => async dispatch => {
    try {
        const response = await axios.get(`/api/attachment/${id}/download`);
        dispatch({
            type: DOWNLOAD_ATTACHMENT,
            payload: response.data
        });
        callback(response.data, null);
    } catch (e) {
        console.log(e);
        ApiUtil.dispatchError(e, dispatch)
    }
}

export const deleteAttachments = (ids, callback) => async dispatch => {
    try {
        const response = await axios.delete(`/api/attachment/all/${btoa(ids)}`);
        dispatch({
            type: DELETE_ATTACHMENTS,
            payload: response.data
        });
        callback(response.data, null);
    } catch (e) {
        console.log(e);
        ApiUtil.dispatchError(e, dispatch)
    }
}

export const getAttachmentTableFilters = (objectHash) => async dispatch => {
    try {

        let url = "/api/attachment/filters";

        if(objectHash){
            url+="?objectHash="+objectHash;
        }

        const response = await axios.get(url);

        dispatch({
            type: LOAD_ATTACHMENTS_TABLE_FILTERS,
            payload: response.data
        });

    } catch (e) {
        ApiUtil.dispatchError(e, dispatch);
    }
}