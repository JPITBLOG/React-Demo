import {DASHBOARD_GET_DATA} from "./types";

export const getDashboardData = () => async dispatch => {

    const data = [
        {
            icon:'/assets/img/black/obligations-icon.png',
            title:'GRC Library',
            description:'Browse regulations, frameworks <br/>&amp; bookmark controls',
            url:'/grc-library',
            enabled: true,
        },
        {
            icon:'/assets/img/black/issues-icon.png',
            title:'Issues',
            description:'Master record to track, prioritize &amp; <br/> mitigate risk',
            url:'/',
            enabled: false,
        },
        {
            icon:'/assets/img/black/policies-icon.png',
            title:'Policies',
            description:'Publish, map &amp; manage policy <br/>exceptions',
            url:'/',
            enabled: false,
        },
        {
            icon:'/assets/img/black/vendors-icon.png',
            title:'Vendors',
            description:'Manage external risks in the supply <br/>chain',
            url:'/',
            enabled: false,
        },
        {
            icon:'/assets/img/black/compliance-icon.png',
            title:'Compliance',
            description:'Centralized controls for compliance review',
            url:'/',
            enabled: false,
        }
    ];

    dispatch({
        type: DASHBOARD_GET_DATA,
        payload: data
    });

};