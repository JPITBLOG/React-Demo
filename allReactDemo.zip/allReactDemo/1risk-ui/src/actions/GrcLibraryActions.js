import {
    LOAD_CONTROL_DETAIL,
    LOAD_CONTROLS_DATA,
    LOAD_CROSSWALK_DATA
} from "./types";
import axios from 'axios';
import ApiUtil from "../util/ApiUtil";
import ObjectUtil from "../util/ObjectUtil";

export const getControlsData = (filter,pagination, callback=()=>null) => async dispatch =>{

    try{

        const config = {};

        if(pagination){
            config.params=ObjectUtil.clone(pagination);
        }

        if(filter){
            if(!config.params){
                config.params={}
            }
            config.params.filters= btoa(JSON.stringify(filter))
        }

        const response = await axios.get(`/api/controlLibrary/`,config);
        dispatch({
            type: LOAD_CONTROLS_DATA,
            payload: response.data
        });
        callback();
    }catch (e) {
        callback();
        ApiUtil.dispatchError(e,dispatch);
    }

}

export const getControlById = (id,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.get(`/api/controlLibrary/${id}`);
        dispatch({
            type: LOAD_CONTROL_DETAIL,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        console.log(e);
        ApiUtil.dispatchError(e,dispatch)
    }
}

export const getCrosswalksData = (filter,pagination,callback=()=>null) => async dispatch =>{

    try{

        const config = {};

        if(pagination){
            config.params=ObjectUtil.clone(pagination);
        }

        if(filter){
            if(!config.params){
                config.params={}
            }
            config.params.filters= btoa(JSON.stringify(filter))
        }

        const response = await axios.get(`/api/crosswalk/`,config);
        dispatch({
            type: LOAD_CROSSWALK_DATA,
            payload: response.data
        });
        callback();
    }catch (e) {
        callback();
        ApiUtil.dispatchError(e,dispatch);
    }

}
