import axios from 'axios';
import ApiUtil from "../util/ApiUtil";
import ObjectUtil from "../util/ObjectUtil";
import {
    LOAD_ACCOUNT_DATA,
    LOAD_ACCOUNT_TABLE_FILTERS,
    LOAD_ACCOUNT_DETAIL,
    LOAD_SUBSCRIPTION_DETAIL,
    LOAD_ACCOUNT_OPTIONS,
    LOAD_SUBSCRIPTION_OPTIONS,
    LOAD_DELETED_ACCOUNTS,
    ACTIVATE_SUBSCRIPTION,
    LOAD_SAVED_ACCOUNT_DATA,
    LOAD_SAVED_ACCOUNT_SUBSCRIPTION_DATA
} from "./types";

export const getAccountsData = (filter, pagination, callback = () => null) => async dispatch => {

    try {

        const config = {};

        if (pagination) {
            config.params = ObjectUtil.clone(pagination);
        }

        if (filter) {
            if (!config.params) {
                config.params = {}
            }
            config.params.filters = btoa(JSON.stringify(filter))
        }

        const response = await axios.get(`/api/account/`, config);
        dispatch({
            type: LOAD_ACCOUNT_DATA,
            payload: response.data
        });
        callback();
    } catch (e) {
        callback();
        ApiUtil.dispatchError(e, dispatch);
    }

}

export const getAccountTableFilters = () => async dispatch => {
    try {

        const response = await axios.get("/api/account/filters");

        dispatch({
            type: LOAD_ACCOUNT_TABLE_FILTERS,
            payload: response.data
        });

    } catch (e) {
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const getAccountById = (id, callback = () => null) => async dispatch => {
    try {
        const response = await axios.get(`/api/account/${id}`);
        const selectedAccount = response.data;
        dispatch({
            type: LOAD_ACCOUNT_DETAIL,
            payload: selectedAccount
        });
        callback(selectedAccount, null);
    } catch (e) {
        ApiUtil.dispatchError(e, dispatch);
        callback(null, e);
    }
}

export const getSubscriptionByAccountId = (referenceId, callback = () => null) => async dispatch => {
    try {
        const response = await axios.get(`/api/subscription/account/${referenceId}`);
        const selectedSubscription = response.data;
        dispatch({
            type: LOAD_SUBSCRIPTION_DETAIL,
            payload: selectedSubscription
        });
        callback();
    } catch (e) {
        ApiUtil.dispatchError(e, dispatch);
        callback(null, e);
    }
}

export const getAccountOptions = (fieldName, callback = () => null) => async dispatch => {
    try {
        const response = await axios.get(`/api/account/options/${fieldName}`);
        const selectedAccountOptions = response.data;
        dispatch({
            type: LOAD_ACCOUNT_OPTIONS,
            payload: selectedAccountOptions
        });
        callback(selectedAccountOptions, null);
    } catch (e) {
        ApiUtil.dispatchError(e, dispatch);
        callback(null, e);
    }
}

export const deleteAccounts = (ids, callback) => async dispatch => {
    try {
        const response = await axios.delete(`/api/account/all/${btoa(ids)}`);
        dispatch({
            type: LOAD_DELETED_ACCOUNTS,
            payload: response.data
        });
        callback(response.data, null);
    } catch (e) {
        console.log(e);
        ApiUtil.dispatchError(e, dispatch)
    }
}

export const activateSubscription = (referenceId, callback = () => null) => async dispatch => {
    try {
        const response = await axios.put(`/api/account/status/${referenceId}`);
        dispatch({
            type: ACTIVATE_SUBSCRIPTION,
            payload: response.data
        });
        callback(response.data, null);
    } catch (e) {
        console.log(e);
        ApiUtil.dispatchError(e, dispatch)
    }
}

export const saveAccounts = (formData, callback = () => null) => async dispatch => {
    try {

        if (formData?.id === undefined) {
            return;
        }

        let response = await axios.put("/api/account/", formData);

        dispatch({
            type: LOAD_SAVED_ACCOUNT_DATA,
            payload: response.data
        });
        callback(response.data, null);
    } catch (e) {
        callback(null, e);
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const saveSubscriptions = (formData, callback = () => null) => async dispatch => {
    try {

        let response;
        if (formData.id !== 0) {
            response = await axios.put("/api/subscription/", formData);
        } else {
            response = await axios.post("/api/subscription/", formData);
        }
        dispatch({
            type: LOAD_SAVED_ACCOUNT_SUBSCRIPTION_DATA,
            payload: response.data
        });
        callback(response.data, null);
    } catch (e) {
        callback(null, e);
        ApiUtil.dispatchError(e, dispatch);
    }
}


export const getSubscriptionOptions = (fieldName, callback = () => null) => async dispatch => {
    try {
        const response = await axios.get(`/api/subscription/options/${fieldName}`);
        const selectedAccountOptions = response.data;
        dispatch({
            type: LOAD_SUBSCRIPTION_OPTIONS,
            payload: selectedAccountOptions
        });
        callback(selectedAccountOptions, null);
    } catch (e) {
        ApiUtil.dispatchError(e, dispatch);
        callback(null, e);
    }
}