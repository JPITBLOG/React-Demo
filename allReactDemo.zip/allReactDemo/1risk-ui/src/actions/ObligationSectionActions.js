import axios from "axios";
import {
    LOAD_OBLIGATION_SECTION_DETAIL,
    LOAD_SAVED_OBLIGATION_SECTION_DATA,
    LOAD_DELETED_OBLIGATION_SECTION, LOAD_OBLIGATION_SECTION_DATA,
    LOAD_OBLIGATION_SECTION_TABLE_FILTERS
} from "./types";
import ApiUtil from "../util/ApiUtil";
import ObjectUtil from "../util/ObjectUtil";

export const getObligationSectionsData = (filter,pagination,callback=()=>null) => async dispatch =>{

    try{

        const config = {};

        if(pagination){
            config.params=ObjectUtil.clone(pagination);
        }

        if(filter){
            if(!config.params){
                config.params={}
            }
            config.params.filters= btoa(JSON.stringify(filter))
        }

        const response = await axios.get(`/api/obligationSection/`,config);
        dispatch({
            type: LOAD_OBLIGATION_SECTION_DATA,
            payload: response.data
        });
        callback();
    }catch (e) {
        callback();
        ApiUtil.dispatchError(e,dispatch);
    }

}

export const saveObligationSection = (formData, callback=()=>null) => async dispatch =>{
    try{

        console.log(formData);

        let response;
        if(formData.id!==0){
            response = await axios.put("/api/obligationSection",formData);
        } else {
            response = await axios.post("/api/obligationSection", formData);
        }
        dispatch({
            type: LOAD_SAVED_OBLIGATION_SECTION_DATA,
            payload: response.data
        });
        callback(response.data,null);
    } catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const resetSaveObligationSection = () => async dispatch =>{
    try{
        dispatch({
            type: LOAD_SAVED_OBLIGATION_SECTION_DATA,
            payload: ""
        });
    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const getObligationSectionsById = (id, callback = () => null) => async dispatch =>{

    try{
        const response = await axios.get(`/api/obligationSection/${id}`);

        const selectedObligationSection = response.data;
        dispatch({
            type: LOAD_OBLIGATION_SECTION_DETAIL,
            payload: selectedObligationSection
        });
        callback(selectedObligationSection, null);
    }catch (e) {
        ApiUtil.dispatchError(e, dispatch);
        callback(null,e);
    }

}

export const deleteObligationSection = (id,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.delete(`/api/obligationSection/${id}`);
        dispatch({
            type: LOAD_DELETED_OBLIGATION_SECTION,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const deleteObligationSections = (ids,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.delete(`/api/obligationSection/all/${btoa(ids)}`);
        dispatch({
            type: LOAD_DELETED_OBLIGATION_SECTION,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const resetObligationSection = () => async dispatch =>{
    try{
        dispatch({
            type: LOAD_OBLIGATION_SECTION_DETAIL,
            payload: ""
        });
    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const getObligationSectionTableFilters = () => async dispatch =>{
    try{

        const response = await axios.get("/api/obligationSection/filters");

        dispatch({
            type: LOAD_OBLIGATION_SECTION_TABLE_FILTERS,
            payload: response.data
        });

    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}