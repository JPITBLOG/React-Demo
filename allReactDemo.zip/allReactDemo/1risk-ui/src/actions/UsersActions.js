import axios from 'axios';
import ApiUtil from "../util/ApiUtil";
import ObjectUtil from "../util/ObjectUtil";
import {
    LOAD_USER_DATA,
    LOAD_USER_TABLE_FILTERS
} from "./types";

export const getUserData = (filter, pagination, callback = () => null) => async dispatch => {

    try {

        const config = {};

        if (pagination) {
            config.params = ObjectUtil.clone(pagination);
        }

        if (filter) {
            if (!config.params) {
                config.params = {}
            }
            config.params.filters = btoa(JSON.stringify(filter))
        }

        const response = await axios.get(`/api/user/`, config);
        dispatch({
            type: LOAD_USER_DATA,
            payload: response.data
        });
        callback();
    } catch (e) {
        callback();
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const getUserTableFilters = () => async dispatch => {
    try {

        const response = await axios.get("/api/user/filters");

        dispatch({
            type: LOAD_USER_TABLE_FILTERS,
            payload: response.data
        });

    } catch (e) {
        ApiUtil.dispatchError(e, dispatch);
    }
}