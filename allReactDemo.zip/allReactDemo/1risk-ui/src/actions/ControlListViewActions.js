import {CONTROL_ITEM_VIEW_COLLAPSE} from "./types";

export const controlViewCollapse = (expanded) => async dispatch =>{
    dispatch({
        type: CONTROL_ITEM_VIEW_COLLAPSE,
        payload: {
            expanded: expanded
        }
    });
}

export const controlViewItemCollapse = (expanded,id) => async dispatch =>{
    dispatch({
        type: CONTROL_ITEM_VIEW_COLLAPSE,
        payload: {
            expanded: expanded,
            id:id
        }
    });
}