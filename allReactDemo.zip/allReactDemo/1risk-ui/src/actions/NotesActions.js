import {
    LOAD_NOTES_DATA,
    LOAD_SAVED_NOTES_DATA,
    LOAD_NOTES_DETAIL,
    LOAD_DELETED_NOTES,
    LOAD_NOTES_TABLE_FILTERS
} from "./types";
import axios from 'axios';
import ApiUtil from "../util/ApiUtil";
import ObjectUtil from "../util/ObjectUtil";

export const getNotesData = (filter, pagination, callback=()=>null) => async dispatch => {
    try {

        const config = {};

        if (pagination) {
            config.params = ObjectUtil.clone(pagination);
        }

        if (filter) {
            if (!config.params) {
                config.params = {}
            }
            config.params.filters = btoa(JSON.stringify(filter))
        }

        const response = await axios.get(`/api/note/`, config);
        dispatch({
            type: LOAD_NOTES_DATA,
            payload: response.data
        });
        callback();
    } catch (e) {
        callback();
        ApiUtil.dispatchError(e, dispatch);
    }

}

export const saveNotes = (formData,callback=()=>null) => async dispatch =>{
    try{
        if(formData?.id === undefined){
            return ;
        }

        let response;
        if(formData.id!==0){
            response = await axios.put("/api/note",formData);
        }else{
            response = await axios.post("/api/note",formData);
        }
        dispatch({
            type: LOAD_SAVED_NOTES_DATA,
            payload: response.data
        });
        callback(response.data,null);
    }catch(e){
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}


export const resetSaveNotes = () => async dispatch =>{
    try{
        dispatch({
            type: LOAD_SAVED_NOTES_DATA,
            payload: ""
        });
    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const getNotesById = (id,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.get(`/api/note/${id}`);
        dispatch({
            type: LOAD_NOTES_DETAIL,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        ApiUtil.dispatchError(e,dispatch);
        callback(null,e);
    }
}

export const deleteNote = (id,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.delete(`/api/note/${id}`);
        dispatch({
            type: LOAD_DELETED_NOTES,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const deleteNotes = (ids,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.delete(`/api/note/all/${btoa(ids)}`);
        dispatch({
            type: LOAD_DELETED_NOTES,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const getNoteTableFilters = (objectHash) => async dispatch => {
    try {

        let url = "/api/note/filters";

        if(objectHash){
            url+="?objectHash="+objectHash;
        }

        const response = await axios.get(url);

        dispatch({
            type: LOAD_NOTES_TABLE_FILTERS,
            payload: response.data
        });

    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}