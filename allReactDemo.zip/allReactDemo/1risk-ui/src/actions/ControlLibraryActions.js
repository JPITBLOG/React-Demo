import axios from "axios";
import {
    LOAD_SAVED_CONTROLS_DATA,
    LOAD_CONTROL_DETAIL,
    LOAD_DELETED_CONTROLS,
    LOAD_CONTROLS_TABLE_FILTERS
} from "./types";
import ApiUtil from "../util/ApiUtil";

export const saveControlLibrary = (formData, callback = () => null) => async dispatch => {
    try {
        let response;
        if (formData.id !== 0) {
            response = await axios.put("/api/controlLibrary", formData);
        } else {
            response = await axios.post("/api/controlLibrary", formData);
        }
        dispatch({
            type: LOAD_SAVED_CONTROLS_DATA,
            payload: response.data
        });
        callback(response.data, null);
    } catch (e) {
        callback(null, e);
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const resetSaveControlLibrary = () => async dispatch =>{
    try{
        dispatch({
            type: LOAD_SAVED_CONTROLS_DATA,
            payload: ""
        });
    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const resetSaveControlDetail = () => async dispatch =>{
    try{
        dispatch({
            type: LOAD_CONTROL_DETAIL,
            payload: ""
        });
    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const deleteControlLibrary = (id,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.delete(`/api/controlLibrary/${id}`);
        dispatch({
            type: LOAD_DELETED_CONTROLS,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const deleteControlLibraries = (ids,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.delete(`/api/controlLibrary/all/${btoa(ids)}`);
        dispatch({
            type: LOAD_DELETED_CONTROLS,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const getControlTableFilters = () => async dispatch =>{
    try{

        const response = await axios.get("/api/controlLibrary/filters");

        dispatch({
            type: LOAD_CONTROLS_TABLE_FILTERS,
            payload: response.data
        });

    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}