import axios from "axios";
import {
    LOAD_DELETED_OBLIGATION,
    LOAD_OBLIGATION_DETAIL, LOAD_OBLIGATION_TABLE_FILTERS,
    LOAD_OBLIGATIONS_DATA,
    LOAD_SAVED_OBLIGATION_DETAIL
} from "./types";
import ApiUtil from "../util/ApiUtil";
import ObjectUtil from "../util/ObjectUtil";

export const getObligationData = (filter,pagination,callback=()=>null) => async dispatch => {

    try{

        const config = {};

        if(pagination){
            config.params=ObjectUtil.clone(pagination);
        }

        if(filter?.length && filter?.length > 0){
            if(!config.params){
                config.params={}
            }
            config.params.filters= btoa(JSON.stringify(filter))
        }

        const response = await axios.get("/api/obligation/",config);

        dispatch({
            type: LOAD_OBLIGATIONS_DATA,
            payload: response.data
        });

        callback()

    }catch (e) {
        callback()
        ApiUtil.dispatchError(e,dispatch);
    }

}

export const getObligationById = (id,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.get(`/api/obligation/${id}`);
        const selectedObligation = response.data;
        dispatch({
            type: LOAD_OBLIGATION_DETAIL,
            payload: selectedObligation
        });
        callback(selectedObligation,null);
    }catch (e) {
        ApiUtil.dispatchError(e,dispatch);
        callback(null,e);
    }
}

export const saveObligation = (formData,callback=()=>null) => async dispatch =>{
    try{

        if(formData?.id === undefined){
            return ;
        }

        let response;
        if(formData.id!==0){
            response = await axios.put("/api/obligation",formData);
        }else{
            response = await axios.post("/api/obligation",formData);
        }
        dispatch({
            type: LOAD_SAVED_OBLIGATION_DETAIL,
            payload: response.data
        });
        callback(response.data,null);
    }catch(e){
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const deleteObligation = (id,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.delete(`/api/obligation/${id}`);
        dispatch({
            type: LOAD_DELETED_OBLIGATION,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const deleteObligations = (ids,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.delete(`/api/obligation/all/${btoa(ids)}`);
        dispatch({
            type: LOAD_DELETED_OBLIGATION,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const resetSaveObligation = () => async dispatch =>{
    try{
        dispatch({
            type: LOAD_SAVED_OBLIGATION_DETAIL,
            payload: ""
        });
    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const resetObligation = () => async dispatch =>{
    try{
        dispatch({
            type: LOAD_OBLIGATION_DETAIL,
            payload: ""
        });
    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const getObligationTableFilters = () => async dispatch =>{
    try{

        const response = await axios.get("/api/obligation/filters");

        dispatch({
            type: LOAD_OBLIGATION_TABLE_FILTERS,
            payload: response.data
        });

    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}
