import axios from "axios";
import {BULK_UPDATE_DONE} from "./types";
import ApiUtil from "../util/ApiUtil";

export const bulkUpdateRecords = (formData,callback) => async dispatch => {

    try{
        const response = await axios.post("/api/bulkUpdate/",formData);
        dispatch({
            type: BULK_UPDATE_DONE,
            payload: response.data
        });
        callback(response.data,null);
    }catch(e){
        callback(null,e);
        callback()
        ApiUtil.dispatchError(e,dispatch);
    }

}