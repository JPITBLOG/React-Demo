import {LOAD_SYSTEM_MESSAGE} from "./types";

export const setSystemMessage = (type,message)  => async dispatch => {
    dispatch({
        type: LOAD_SYSTEM_MESSAGE,
        payload: {
            message: message,
            type: type
        }
    });
}

export const resetSystemMessage = ()  => async dispatch => {
    dispatch({
        type: LOAD_SYSTEM_MESSAGE,
        payload: {
            message: "",
            type: ""
        }
    });
}