export const AUTH_USER = 'auth_user';
export const AUTH_ERROR = 'auth_error';
export const AUTH_SEND_MFA_CODE = 'auth_send_mfa_code';
export const AUTH_FORGOT_PASSWORD = 'auth_forgot_password';
export const AUTH_RESET_PASSWORD = 'auth_reset_password';

export const DASHBOARD_GET_DATA = 'dashboard-get-data';
export const LOAD_MAIN_MENU = 'load-main-menu';
export const LOAD_ACCOUNTS = 'load-accounts';

export const GENERAL_SERVER_ERROR = 'general-server-error';

// Header
export const LOAD_DETAIL_HEADER_DATA = 'load-detail-header-data';
export const RESET_DETAIL_HEADER_DATA = 'reset-detail-header';

export const SEND_BREADCRUMB_DATA = 'send-breadcrumb-data';

//GRC Library tabs
export const LOAD_OBLIGATIONS_DATA = 'load-obligations-data';
export const LOAD_OBLIGATION_DETAIL = 'load-obligation-detail';
export const LOAD_SAVED_OBLIGATION_DETAIL = 'load-saved-obligation-detail';
export const LOAD_DELETED_OBLIGATION = 'load-deleted-obligation';
export const LOAD_OBLIGATION_TABLE_FILTERS = 'load-obligation-table-filters';

export const LOAD_OBLIGATION_SECTIONS_TREE_DATA = 'load-obligations-tree-data';
export const LOAD_OBLIGATION_SECTION_DATA = 'load-obligation-sections-data';
export const LOAD_OBLIGATION_SECTION_DETAIL = 'load-obligation-sections-detail';
export const LOAD_SAVED_OBLIGATION_SECTION_DATA = 'load-saved-obligation-section-data';
export const LOAD_DELETED_OBLIGATION_SECTION = 'load-deleted-obligation-section';
export const LOAD_OBLIGATION_SECTION_TABLE_FILTERS = 'load-obligation-section-table-filters';

export const LOAD_CONTROLS_DATA = 'load-controls-data';
export const LOAD_CONTROL_DETAIL = 'load-control-detail';
export const LOAD_SAVED_CONTROLS_DATA = 'load-saved-controls-data';
export const LOAD_DELETED_CONTROLS = 'load-deleted-controls';
export const LOAD_CONTROLS_TABLE_FILTERS = 'load-controls-table-filters';

export const LOAD_CROSSWALK_DATA = 'load-crosswalk-data';
export const LOAD_CROSSWALK_DETAIL = 'load-crosswalk-detail';
export const LOAD_SAVED_CROSSWALK_DATA = 'load-saved-crosswalk-data';
export const LOAD_DELETED_CROSSWALK = 'load-deleted-crosswalk';
export const LOAD_CROSSWALK_TABLE_FILTERS = 'load-crosswalk-table-filters';

export const LOAD_NOTES_DATA = 'load-notes-data';
export const LOAD_NOTES_DETAIL = 'load-notes-detail';
export const LOAD_SAVED_NOTES_DATA = 'load-saved-notes-data';
export const LOAD_DELETED_NOTES = 'load-deleted-notes';
export const LOAD_NOTES_TABLE_FILTERS = 'load-notes-table-filters';

export const LOAD_ATTACHMENTS_DATA = "load-attachments-data";
export const DOWNLOAD_ATTACHMENT = 'download-attachment';
export const DELETE_ATTACHMENTS = 'delete-attachments';
export const LOAD_ATTACHMENTS_TABLE_FILTERS = 'load-attachments-table-filters';

export const LOAD_HISTORY_DATA = "load-history-data";
export const LOAD_HISTORY_TABLE_FILTERS = 'load-history-table-filters';

// Filters
export const LOAD_INDUSTRY_FILTER_DATA = 'load-industry-filter-data';
export const LOAD_REGION_FILTER_DATA = 'load-region-filter-data';
export const LOAD_TYPE_FILTER_DATA = 'load-type-filter-data';
export const LOAD_OBLIGATIONS_FILTER_DATA = 'load-obligations-filter-data';
export const LOAD_OBLIGATION_SECTIONS_FILTER_DATA = 'load-obligation-sections-filter-data';
export const LOAD_TAGS_FILTER_DATA = 'load-tags-filter-data';
export const LOAD_MAPPED_CONTROLS_FILTER_DATA = 'load-mapped-controls-filter-data';
export const SELECT_CHECKBOX_FILTER_ITEM = 'select-checkbox-filter-item';
export const LOAD_CONTROL_LIBRARY_TYPE_FILTER_DATA = 'load-control-library-type-filter-data';
export const LOAD_CONTROL_LIBRARY_STATUS_FILTER_DATA = 'load-control-library-status-filter-data';
export const LOAD_USERS_FILTER_DATA = 'load-users-filter-data';
export const LOAD_ENTITY_TAGS = 'load-entity-tags';
export const SAVED_ENTITY_TAGS = 'saved-entity-tags';

//Admin tabs
export const LOAD_ACCOUNT_DATA = 'load-account-data';
export const LOAD_SAVED_ACCOUNT_DATA = 'load-saved-account-data';
export const LOAD_ACCOUNT_TABLE_FILTERS = 'load-account-table-filters';
export const LOAD_ACCOUNT_DETAIL = 'load-account-detail';
export const LOAD_SUBSCRIPTION_DETAIL = 'load-subscription-detail';
export const LOAD_SUBSCRIPTION_OPTIONS = 'load-subscription-options';
export const LOAD_ACCOUNT_OPTIONS = 'load-account-options';
export const LOAD_DELETED_ACCOUNTS = 'load-delete-accounts';
export const ACTIVATE_SUBSCRIPTION = 'activate-subscription';
export const LOAD_SAVED_ACCOUNT_SUBSCRIPTION_DATA = 'load_saved_account_subscription_data'

export const LOAD_USER_DATA = 'load-user-data';
export const LOAD_USER_TABLE_FILTERS = 'load-user-table-filters';
// ControlView Component
export const CONTROL_ITEM_VIEW_COLLAPSE = "control-view-collapse";

// TreeView Component
export const TREE_ITEM_VIEW_COLLAPSE = "tree-view-collapse";

// Comment Section Component
export const LOAD_COMMENTS = "load-comments";
export const COMMENT_SAVED = "comment-saved";
export const COMMENT_DELETED = "comment-saved";

// Attachment
export const LOGO_UPLOAD = 'logo-upload';
export const ATTACHMENT_UPLOAD = 'attachment-upload';

// Top Menu Actions
export const LOAD_TOP_MENU_ACTIONS = 'load-top-menu-actions';

// System Message
export const LOAD_SYSTEM_MESSAGE = 'load-system-message';

// Bulk Update
export const BULK_UPDATE_DONE = 'bulk-update-done';

