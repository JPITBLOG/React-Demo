import {LOAD_DETAIL_HEADER_DATA, RESET_DETAIL_HEADER_DATA, SEND_BREADCRUMB_DATA} from "./types";

export const populateDetailHeader = (detail) => async dispatch => {
    dispatch({
        type: LOAD_DETAIL_HEADER_DATA,
        payload: detail
    })
}

export const resetDetailHeader = () => async dispatch => {
    dispatch({
        type: RESET_DETAIL_HEADER_DATA
    })
}

export const sendBreadcrumbData = (breadcrumbDetail,callback=()=>null) => async dispatch => {
    dispatch({
        type: SEND_BREADCRUMB_DATA,
        payload: breadcrumbDetail
    });
    callback(breadcrumbDetail);

}

export const resetBreadcrumbData = () => async dispatch => {
    dispatch({
        type: SEND_BREADCRUMB_DATA,
        payload: {}
    });

}
