import {GENERAL_SERVER_ERROR} from "./types";

export const sendErrorMsg = (errorMessage) => async dispatch =>{
    dispatch({
        type: GENERAL_SERVER_ERROR,
        payload: errorMessage
    });
}