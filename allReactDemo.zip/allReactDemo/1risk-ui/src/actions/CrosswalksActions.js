import axios from "axios";
import {
    LOAD_CROSSWALK_DETAIL,
    LOAD_SAVED_CROSSWALK_DATA,
    LOAD_DELETED_CROSSWALK,
    LOAD_CROSSWALK_TABLE_FILTERS
} from "./types";
import ApiUtil from "../util/ApiUtil";

export const getCrosswalkById = (id, callback) => async dispatch => {
    try {
        const response = await axios.get(`/api/crosswalk/${id}`);
        dispatch({
            type: LOAD_CROSSWALK_DETAIL,
            payload: response.data
        });
        callback(response.data, null);
    } catch (e) {
        callback(null, e);
        console.log(e);
        ApiUtil.dispatchError(e, dispatch)
    }
}


export const saveCrosswalk = (crosswalkData, callback = () => null) => async dispatch => {
    try {
        let response, responseData = [];
        response = await axios.post("/api/crosswalk", crosswalkData);
        response.data.map(async res => {
            let crosswalkData = await axios.get(`/api/crosswalk/${res}`);
            responseData.push(crosswalkData.data);
        })
        dispatch({
            type: LOAD_SAVED_CROSSWALK_DATA,
            payload: responseData
        });
        callback(response.data, null);
    } catch (e) {
        callback(null, e);
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const resetSaveCrosswalk = () => async dispatch => {
    try {
        dispatch({
            type: LOAD_SAVED_CROSSWALK_DATA,
            payload: ""
        });
    } catch (e) {
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const deleteCrosswalk = (id, callback = () => null) => async dispatch => {
    try {
        const response = await axios.delete(`/api/crosswalk/${id}`);
        dispatch({
            type: LOAD_DELETED_CROSSWALK,
            payload: response.data
        });
        callback(response.data, null);
    } catch (e) {
        callback(null, e);
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const deleteCrosswalks = (ids,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.delete(`/api/crosswalk/all/${btoa(ids)}`);
        dispatch({
            type: LOAD_DELETED_CROSSWALK,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const getCrosswalkTableFilters = () => async dispatch =>{
    try{

        const response = await axios.get("/api/crosswalk/filters");

        dispatch({
            type: LOAD_CROSSWALK_TABLE_FILTERS,
            payload: response.data
        });

    }catch(e){
        ApiUtil.dispatchError(e,dispatch);
    }
}