import {
    LOAD_INDUSTRY_FILTER_DATA,
    LOAD_REGION_FILTER_DATA,
    LOAD_TYPE_FILTER_DATA,
    LOAD_OBLIGATIONS_FILTER_DATA,
    LOAD_OBLIGATION_SECTIONS_FILTER_DATA,
    LOAD_TAGS_FILTER_DATA,
    LOAD_MAPPED_CONTROLS_FILTER_DATA,
    SELECT_CHECKBOX_FILTER_ITEM,
    LOAD_CONTROL_LIBRARY_TYPE_FILTER_DATA,
    LOAD_CONTROL_LIBRARY_STATUS_FILTER_DATA, LOAD_USERS_FILTER_DATA, LOAD_ENTITY_TAGS, SAVED_ENTITY_TAGS
} from "./types";

import tagsData from './data/tagsFilter';
import mappedControlsData from './data/mappedControlsFilter';

import axios from 'axios';
import UUIDUtil from "../util/UUIDUtil";
import ApiUtil from "../util/ApiUtil";

export const getControlLibraryType = () => async dispatch => {

    const items = [];
    items.push({value:false,label:"Regular"});
    items.push({value:true,label:"Custom"});
    dispatch({
        type: LOAD_CONTROL_LIBRARY_TYPE_FILTER_DATA,
        payload: items
    });
}

export const getIndustryFilterData = () => async dispatch => {

    const items = [];

    for (let i = 1; i <= 200; i++) {
        items.push({ value: `${i}`, label: `Industry really long name ${i}` });
    }

    dispatch({
        type: LOAD_INDUSTRY_FILTER_DATA,
        payload: items
    });

}

export const getRegionFilterData = () => async dispatch => {

    const items = [];

    for (let i = 1; i <= 200; i++) {
        items.push({ value: `${i}`, label: `Region ${i}` });
    }

    dispatch({
        type: LOAD_REGION_FILTER_DATA,
        payload: items
    });

}

export const getTypeFilterData = () => async dispatch => {

    const items = [];

    for (let i = 1; i <= 200; i++) {
        items.push({ value: `${i}`, label: `Type ${i}` });
    }

    dispatch({
        type: LOAD_TYPE_FILTER_DATA,
        payload: items
    });

}

export const getTagFilterData = () => async dispatch =>{
    dispatch({
        type: LOAD_TAGS_FILTER_DATA,
        payload: tagsData
    });
}

export const getMappedControlFilterData = () => async dispatch =>{
    dispatch({
        type: LOAD_MAPPED_CONTROLS_FILTER_DATA,
        payload: mappedControlsData
    });
}

export const getSectionControlFilterData = () => async dispatch =>{
    // dispatch({
    //     type: LOAD_OBLIGATION_SECTIONS_FILTER_DATA,
    //     payload: obligationSectionFilter
    // });
}

export const setCheckboxItem = (parentId,value) => async dispatch =>{
    dispatch({
        type: SELECT_CHECKBOX_FILTER_ITEM,
        payload: {
            eventId: UUIDUtil.v4(),
            parentId: parentId,
            value: value
        }
    });
}

export const getControlLibraryStatus = () => async dispatch =>{
    try{
        const response = await axios.get("/api/controlLibrary/status");
        dispatch({
            type: LOAD_CONTROL_LIBRARY_STATUS_FILTER_DATA,
            payload: response.data
        })
    }catch (e) {
        ApiUtil.dispatchError(e,dispatch);
    }

}

export const getObligationFilter = () => async dispatch =>{
    try{
        const response = await axios.get("/api/obligation/filter");
        dispatch({
            type: LOAD_OBLIGATIONS_FILTER_DATA,
            payload: response.data
        })
    }catch (e) {
        ApiUtil.dispatchError(e,dispatch);
    }

}

export const getUsersFilter = () => async dispatch =>{
    try{
        const response = await axios.get("/api/user/account");
        dispatch({
            type: LOAD_USERS_FILTER_DATA,
            payload: response.data
        })
    }catch (e) {
        ApiUtil.dispatchError(e,dispatch);
    }

}

export const getEntityTags = (entityName,fieldName) => async dispatch =>{
    try{
        const response = await axios.get(`/api/tag/${entityName}/${fieldName}`);
        dispatch({
            type: LOAD_ENTITY_TAGS,
            payload: response.data
        })
    }catch (e) {
        ApiUtil.dispatchError(e,dispatch);
    }

}

export const saveEntityTag = (tag,callback=()=>null) => async dispatch =>{
    try{
        const response = await axios.post(`/api/tag`,tag);
        dispatch({
            type: SAVED_ENTITY_TAGS,
            payload: response.data
        })
        callback();
    }catch (e) {
        console.log(e);
        ApiUtil.dispatchError(e,dispatch);
    }
}

export const getObligationSectionFilter = (obligationId) => async dispatch =>{
    try{
        const response = await axios.get(`/api/obligationSection/filter/${obligationId}`);
        dispatch({
            type: LOAD_OBLIGATION_SECTIONS_FILTER_DATA,
            payload: response.data
        })
    }catch (e) {
        console.log(e);
        ApiUtil.dispatchError(e,dispatch);
    }
}