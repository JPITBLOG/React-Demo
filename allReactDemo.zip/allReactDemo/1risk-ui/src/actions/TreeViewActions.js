import {TREE_ITEM_VIEW_COLLAPSE} from "./types";

export const treeViewCollapse = (expanded,parentId) => async dispatch =>{
    dispatch({
        type: TREE_ITEM_VIEW_COLLAPSE,
        payload: {
            expanded: expanded,
            parentId: parentId
        }
    });
}

export const treeViewItemCollapse = (expanded,id) => async dispatch =>{
    dispatch({
        type: TREE_ITEM_VIEW_COLLAPSE,
        payload: {
            expanded: expanded,
            id:id
        }
    });
}