import {
    AUTH_USER,
    AUTH_ERROR,
    AUTH_FORGOT_PASSWORD,
    AUTH_RESET_PASSWORD,
    AUTH_SEND_MFA_CODE
} from './types';

import axios from 'axios';
import * as MessageBundle from '../bundle/MessageBundle';
import LocalStorageUtil from "../util/LocalStorageUtil";

function getFormDataAuth(){
    let formData = new FormData();
    formData.append("grant_type","password");
    return formData;
}

function getAuthRequest(){
    return axios.create({
        baseURL: process.env.REACT_APP_API_URL,
        auth: {
            username: process.env.REACT_APP_CLIENT_ID,
            password: process.env.REACT_APP_CLIENT_SECRET
        },
        headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
        }
    });
}

const storeToken = (token)=>{
    LocalStorageUtil.setObjectItem("token",token);
}

export const signup = (formProps,callback) => async dispatch => {
    try{
        const response = await axios.post('/signup',formProps);
        dispatch({
            type: AUTH_USER,
            payload: response.data
        });
        storeToken(response.data);
        callback();
    }catch(e){
        dispatch({
            type: AUTH_ERROR,
            payload: 'Email in use!'
        })
    }

};

export const sso = (token,callback) => async dispatch => {
    try{

        let formData = getFormDataAuth();
        formData.append("ssoToken",token);

        const axiosRequest = getAuthRequest();

        const response = await axiosRequest.post('/oauth/token',formData);

        dispatch({
            type: AUTH_USER,
            payload: response.data
        });
        storeToken(response.data);

        callback();

    }catch (e) {
        console.log(e);
        callback(e);
        dispatch({
            type: AUTH_ERROR,
            payload: MessageBundle.ERROR_LOGIN_MESSAGE
        })
    }
};

export const signin = (formProps,callback) => async dispatch => {
    try{

        let formData = new FormData();
        formData.append("username",(formProps.username));
        formData.append("password",formProps.password);
        formData.append("mfaCode",formProps.mfaCode);
        formData.append("grant_type","password");

        const axiosRequest = getAuthRequest();

        const response = await axiosRequest.post('/oauth/token',formData);

        dispatch({
            type: AUTH_USER,
            payload: response.data
        });
        storeToken(response.data);

        callback();

    }catch(e){

        const callbackResponse={
            isExpired:false,
            resetToken: "",
            isLocked:false,
            message:MessageBundle.ERROR_LOGIN_MESSAGE
        };

        if(e.response){
            if(e.response.data["error_description"].includes("expired")){
                callbackResponse.isExpired=true;
                const msg = e.response.data["error_description"].split("|");
                callbackResponse.resetToken=msg[1].trim()
            }
            if(e.response.data["error_description"].includes("locked")){
                callbackResponse.isLocked=true;
                callbackResponse.message = e.response.data["error_description"];
            }
        }

        callback(callbackResponse);
        dispatch({
            type: AUTH_ERROR,
            payload: MessageBundle.ERROR_LOGIN_MESSAGE
        })
    }

};

export const forgotPassword = (formProps,callback) => async dispatch => {
    try{

        const request = {
            username:formProps.username
        };

        await axios.post('/api/user/forgotPassword',request);

        dispatch({
            type: AUTH_FORGOT_PASSWORD,
            payload: request.username
        });
        localStorage.setItem('username',request.username);
        callback();
    }catch(e){
        dispatch({
            type: AUTH_FORGOT_PASSWORD,
            payload: MessageBundle.ERROR_USERNAME_NOT_EXISTS
        })
    }

};

export const signout = (callback) => async dispatch => {

    try{
        if(localStorage.getItem('token')){
            await axios.delete('/api/user/logout');
        }
    }catch (e) {
        console.log(e);
    }finally {
        dispatch({
            type: AUTH_USER,
            payload: ''
        });

        dispatch({
            type: AUTH_ERROR,
            payload: ''
        })
        localStorage.removeItem('token');
        callback();
    }

};

export const getResetUsername = () =>{
    let username = localStorage.getItem("username");
    localStorage.clear();
    return {
        type: AUTH_FORGOT_PASSWORD,
        payload: username
    }
};

export const resetPassword = (request,callback) => async dispatch => {

    try{
        const response = await axios.post("/api/user/resetPassword",request);

        dispatch({
            type: AUTH_RESET_PASSWORD,
            payload: response.data
        });

        callback(response.data,null);

    }catch (e) {
        callback(null,e);
        dispatch({
            type: AUTH_ERROR,
            payload: MessageBundle.ERROR_RESET_PASSWORD
        });
    }


};

export const sendMfaCode = (formProps,callback) => async dispatch =>{
    try{

        let geoResponseData = null

        try{
            const geoResponse = await axios.get("https://freegeoip.app/json/");
            geoResponseData=geoResponse.data
        }catch (e) {
            console.log(e);
        }

        const request = {
            username:formProps.username,
            geoInfo:geoResponseData
        };

        const response = await axios.post('/api/mfa/',request);

        dispatch({
            type: AUTH_SEND_MFA_CODE,
            payload: response.data
        });

        dispatch({
            type: AUTH_ERROR,
            payload: ''
        })

        callback(null)

    }catch(e){
        callback(e);
        dispatch({
            type: AUTH_ERROR,
            payload: MessageBundle.ERROR_LOGIN_MESSAGE
        });
    }
};

export const validateMfaCode = (formProps,callback) => async dispatch =>{
    try{

        let geoResponseData = null

        try{
            const geoResponse = await axios.get("https://freegeoip.app/json/");
            geoResponseData=geoResponse.data
        }catch (e) {
            console.log(e);
        }

        const request = {
            username:formProps.username,
            code:formProps.mfaCode,
            geoInfo:geoResponseData
        };

        const response = await axios.post('/api/mfa/validate',request);

        dispatch({
            type: AUTH_SEND_MFA_CODE,
            payload: response.data
        });

        callback(null);

    }catch(e){
        callback(e);
        dispatch({
            type: AUTH_ERROR,
            payload: MessageBundle.ERROR_LOGIN_MESSAGE
        });
    }
};