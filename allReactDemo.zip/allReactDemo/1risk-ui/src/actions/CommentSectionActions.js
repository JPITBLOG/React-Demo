import {COMMENT_DELETED, COMMENT_SAVED, LOAD_COMMENTS} from "./types";

import axios from 'axios';
import ApiUtil from "../util/ApiUtil";

export const getComments = (objectHash,callback) => async dispatch => {

    try{
        const response = await axios.get("/api/comment/hash/"+objectHash);
        dispatch({
            type: LOAD_COMMENTS,
            payload: response.data
        });
        callback(response.data,null);
    }catch(e){
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }

}

export const saveComment = (commentData,callback) => async dispatch => {

    try{

        let response;

        console.log(commentData);

        if(commentData.id){
            response = await axios.put("/api/comment/",commentData);
        }else{
            response = await axios.post("/api/comment/",commentData);
        }

        dispatch({
            type: COMMENT_SAVED,
            payload: response.data
        });

        callback(response.data);

    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }

}

export const deleteComment = (id,callback) => async dispatch => {
    try{
        const response = await axios.delete("/api/comment/"+id)
        dispatch({
            type: COMMENT_DELETED,
            payload: response.data
        });
        callback(response.data,null);
    }catch (e) {
        callback(null,e);
        ApiUtil.dispatchError(e,dispatch);
    }
}