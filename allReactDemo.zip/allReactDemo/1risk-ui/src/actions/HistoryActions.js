import {
    LOAD_HISTORY_DATA, LOAD_HISTORY_TABLE_FILTERS
} from "./types";
import axios from 'axios';
import ApiUtil from "../util/ApiUtil";
import ObjectUtil from "../util/ObjectUtil";

export const getHistoryData = (filter, pagination, callback = () => null) => async dispatch => {
    try {

        const config = {};

        if (pagination) {
            config.params = ObjectUtil.clone(pagination);
        }

        if (filter) {
            if (!config.params) {
                config.params = {}
            }
            config.params.filters = btoa(JSON.stringify(filter))
        }

        const response = await axios.get(`/api/history/`, config);
        dispatch({
            type: LOAD_HISTORY_DATA,
            payload: response.data
        });
        callback();
    } catch (e) {
        callback();
        ApiUtil.dispatchError(e, dispatch);
    }
}

export const getHistoryTableFilters = (objectHash) => async dispatch => {
    try {

        let url = "/api/history/filters";

        if(objectHash){
            url+="?objectHash="+objectHash;
        }

        const response = await axios.get(url);

        dispatch({
            type: LOAD_HISTORY_TABLE_FILTERS,
            payload: response.data
        });

    } catch (e) {
        ApiUtil.dispatchError(e, dispatch);
    }
}