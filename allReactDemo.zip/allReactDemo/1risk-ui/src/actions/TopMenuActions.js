import {LOAD_TOP_MENU_ACTIONS} from "./types";

export const loadTopMenuActions = (menuActions,enableCancel=false,isVisible=false) => async dispatch => {

    const event={
        actions: menuActions,
        enableCancel: enableCancel,
        isVisible: isVisible
    }


    dispatch({
        type: LOAD_TOP_MENU_ACTIONS,
        payload: event
    })

}