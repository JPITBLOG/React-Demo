import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter, Redirect, Route, Switch} from 'react-router-dom';
import {Provider} from 'react-redux';
import {applyMiddleware, createStore} from 'redux';
import reduxThunk from 'redux-thunk';

import reducers from './reducers';
import Signin from './components/page/auth/SigninPage';
import Signout from './components/page/auth/SignoutPage';
import ForgotPassword from './components/page/auth/ForgotPasswordPage';
import ForgotPasswordSuccesss from './components/page/auth/ForgotPasswordSuccessPage';
import Dashboard from './components/page/dashboard/DashboardPage';
import ResetPassword from "./components/page/auth/ResetPasswordPage";
import GrcLibrary from "./components/page/grclibrary/GrcLibraryPage";
import AdministrationPage from "./components/page/administration/AdministrationPage";
import AccountDetailPage from "./components/page/administration/accounts/AccountsDetailPage";
import UserDetailPage from "./components/page/administration/users/UsersDetailPage";
import './index.css';
import './responsive.css';

import './components/core/ContentWidget.css';

import 'bootstrap/dist/css/bootstrap.min.css';
import VersionPage from "./components/page/VersionPage";
import ControlLibraryDetailsPage from "./components/page/grclibrary/controlLibrary/ControlLibraryDetailsPage";
import ObligationDetailPage from "./components/page/grclibrary/obligation/ObligationDetailPage";
import ObligationSectionDetailPage from "./components/page/grclibrary/obligationSection/ObligationSectionDetailPage";
import ApplicationContainer from "./components/core/ApplicationContainer";
import ObligationSavePage from "./components/page/grclibrary/obligation/ObligationSavePage";
import ControlLibrarySavePage from "./components/page/grclibrary/controlLibrary/ControlLibrarySavePage";
import ObligationSectionSavePage from "./components/page/grclibrary/obligationSection/ObligationSectionSavePage";
import CrosswalkDetailPage from "./components/page/grclibrary/crosswalk/CrosswalkDetailPage";
import CrosswalkSavePage from "./components/page/grclibrary/crosswalk/CrosswalkSavePage";
import AttachmentSavePage from './components/page/attachments/AttachmentSavePage'
import NotesSavePage from "./components/page/grclibrary/notes/NotesSavePage";
import NotesDetailPage from "./components/page/grclibrary/notes/NotesDetailPage";

import AccountSavePage from "./components/page/administration/accounts/AccountSavePage"
const store = createStore(
    reducers,
    {
        auth: { authenticated: localStorage.getItem('token') }
    },
    applyMiddleware(reduxThunk)
);

const Page404 = () => (
    <div className="row justify-content-center page404">
        <h1>Page not found - 404</h1>
    </div>
)

ReactDOM.render(
    <Provider store={store}>
        <BrowserRouter>
            <ApplicationContainer>
                <Switch>

                    <Route path="/" exact>
                        <Redirect to="/dashboard" />
                    </Route>

                    <Route path="/dashboard" exact component={Dashboard}/>
                    <Route path="/reset-password" exact component={ResetPassword}/>
                    <Route path="/forgot-password" exact component={ForgotPassword}/>
                    <Route path="/forgot-password-success" exact component={ForgotPasswordSuccesss}/>
                    <Route path="/signout" exact component={Signout}/>
                    <Route path="/signin" exact component={Signin}/>

                    <Route path="/grc-library" exact>
                        <Redirect to="/grc-library/obligations" />
                    </Route>
                    <Route path="/grc-library/:tab" exact component={GrcLibrary}/>

                    <Route path="/admin" exact>
                        <Redirect to="/admin/accounts" />
                    </Route>
                    <Route path="/admin/:tab" exact component={AdministrationPage}/>
                    <Route path="/admin/accounts/edit/:id" exact component={AccountSavePage} />
                    <Route path="/admin/accounts/new" exact component={AccountSavePage}/>
                    <Route path="/admin/accounts/:id" exact component={AccountDetailPage} />
                    <Route path="/admin/accounts/:id/:tab" exact component={AccountDetailPage} />

                    <Route path="/admin/users/:id" exact component={UserDetailPage} />
                    <Route path="/admin/users/:id/:tab" exact component={UserDetailPage} />

                    <Route path="/grc-library/obligations/new" exact component={ObligationSavePage}/>
                    <Route path="/grc-library/obligations/edit/:id" exact component={ObligationSavePage}/>
                    <Route path="/grc-library/obligations/:id" exact component={ObligationDetailPage}/>
                    <Route path="/grc-library/obligations/:id/:tab" exact component={ObligationDetailPage}/>

                    <Route path="/grc-library/obligation-sections/new/:objectHash" exact component={ObligationSectionSavePage}/>
                    <Route path="/grc-library/obligation-sections/new" exact component={ObligationSectionSavePage}/>
                    <Route path="/grc-library/obligation-sections/edit/:id" exact component={ObligationSectionSavePage}/>
                    <Route path="/grc-library/obligation-sections/:id" exact component={ObligationSectionDetailPage}/>
                    <Route path="/grc-library/obligation-sections/:id/:tab" exact component={ObligationSectionDetailPage}/>

                    <Route path="/grc-library/control-libraries/new/:objectHash" exact component={ControlLibrarySavePage}/>
                    <Route path="/grc-library/control-libraries/new" exact component={ControlLibrarySavePage}/>
                    <Route path="/grc-library/control-libraries/edit/:id" exact component={ControlLibrarySavePage}/>
                    <Route path="/grc-library/control-libraries/:id" exact component={ControlLibraryDetailsPage}/>
                    <Route path="/grc-library/control-libraries/:id/:tab" exact component={ControlLibraryDetailsPage}/>


                    <Route path="/grc-library/crosswalks/new/:objectHash" exact component={CrosswalkSavePage}/>
                    <Route path="/grc-library/crosswalks/new" exact component={CrosswalkSavePage}/>
                    <Route path="/grc-library/crosswalks/new/:tab" exact component={CrosswalkSavePage}/>
                    <Route path="/grc-library/crosswalks/:id" exact component={CrosswalkDetailPage}/>
                    <Route path="/grc-library/crosswalks/:id/:tab" exact component={CrosswalkDetailPage}/>                    

                    <Route path="/grc-library/attachments/new/:objectHash" exact component={AttachmentSavePage}/>

                    <Route path="/grc-library/notes/new/:objectHash" exact component={NotesSavePage}/>
                    <Route path="/grc-library/notes/edit/:id" exact component={NotesSavePage}/>
                    <Route path="/grc-library/notes/:id" exact component={NotesDetailPage}/>

                    <Route path="/version" exact component={VersionPage}/>

                    <Route path="*">
                        <Page404/>
                    </Route>

                </Switch>
            </ApplicationContainer>
        </BrowserRouter>
    </Provider>,
    document.querySelector("#root")
);
