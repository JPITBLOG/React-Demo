export const ERROR_LOGIN_MESSAGE="Login failed, review your credentials";
export const VALIDATION_ERROR_MSG = "Required field(s) are missing.";
export const ERROR_RESET_PASSWORD='Fail on reset password';
export const ERROR_USERNAME_NOT_EXISTS='Username not exists';
export const ERROR_VALIDATION_REQUIREMENTS='Please check all the requirements';
export const ERROR_VALIDATION_MFA='Validation failed, check your code';

export const DEFAULT_SERVER_ERROR_MESSAGE="Error on access the server, if the error persist, please contact support";
