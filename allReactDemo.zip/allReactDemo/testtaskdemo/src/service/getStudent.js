import baseService from './baseService';

export function getStudent(pageIndex) {
    return baseService.get(`api/student/getAllStudent?currentPage=${pageIndex}`);
}

export function findStudent( pageIndex, search, dobFrom, dobTo, gender) {
    return baseService.get(`api/student/getStudent?currentPage=${pageIndex}
                            &Search=${search}&DateFrom=${dobFrom}&DateTo=${dobTo}&Gender=${gender}`);
}
