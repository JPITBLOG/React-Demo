import React from 'react';
import StudentGrid from '../student/studentGrid';

import './App.css';

function App() {
  return (
    <div className="App">
      <div>
        <StudentGrid/>
      </div>
    </div>
  );
}

export default App;
