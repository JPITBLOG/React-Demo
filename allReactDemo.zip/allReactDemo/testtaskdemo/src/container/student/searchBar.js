import React from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Col, Row, Button, Form, FormGroup, Label, Input } from 'reactstrap';

const Search = (props) => {
    const {onSetState , setDateChangeStart, setDateChangeEnd, dobFrom, dobTo, onSearch, search, gender} = props;
    debugger
    return (
        <div>
            <Form>
                <Row form>
                    <Col md={2}>
                        <FormGroup>
                            <Label for="dob">Search</Label>
                            <Input
                                type="text"
                                name="search"
                                id="search"
                                placeholder="search"
                                onChange = {(event) => onSetState(event, 'search')}
                                value = {search || ''}
                            />
                        </FormGroup>
                    </Col>
                    <Col md={2}>
                        <FormGroup>
                            <Label for="dob">From</Label>
                            <Input
                                type="date"
                                name="date"
                                id="dobFrom"
                                placeholder="date placeholder"
                                onChange = {(event) => onSetState(event, 'dobFrom')}
                                value = {dobFrom || ''}
                            />
                        </FormGroup>
                    </Col>
                    <Col md={2}>
                        <FormGroup>
                            <Label for="dob">TO</Label>
                            <Input
                                type="date"
                                name="date"
                                id="dobTo"
                                placeholder="date placeholder"
                                onChange = {(event) => onSetState(event, 'dobTo')}
                                value = {dobTo || ''}
                            />
                        </FormGroup>
                    </Col>
                    <Col md={2}>
                        <FormGroup>
                            <Label for="gender">Gender</Label>
                            <Input
                                type="select"
                                name="select"
                                id="exampleSelect"
                                onChange = {(event) => onSetState(event, 'gender')}
                                value = {gender}
                            >
                                <option value={'SELECT'}>SELECT</option>
                                <option value={'male'}>MALE</option>
                                <option value={'female'}>FEMALE</option>
                            </Input>
                        </FormGroup>
                    </Col>
                    <Col md={2}>
                        <FormGroup>
                         <Button onClick={() => onSearch()}>Search</Button>
                        </FormGroup>
                    </Col>
                </Row>

            </Form>
        </div>
    )
}

export default Search;