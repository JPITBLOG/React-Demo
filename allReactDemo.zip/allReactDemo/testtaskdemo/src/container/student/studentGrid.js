import React, {Component} from "react";
import * as studentService from '../../service/getStudent';
import * as paginationService from '../../service/pageInfo';
import StudentTable from './studentTable';
import Page from './pagination';
import Search from './searchBar';
class StudentGrid extends Component {
    constructor(props){
        super(props);
        this.state = {
            paginationRecord: {
                firstPage: 0,
                lastPage: 0,
                currentPage: 0,
                nextPage: 0,
                prevPage: 0,
                totalPages: 0,
                studentLength: 0
            },
            search: '',
            dobFrom: '',
            dobTo: '',
            gender: '',
            studentData : [],
            isLoading: true,
            error: ''
        }
        this.clickOnChangePage = this.clickOnChangePage.bind(this);
        this.onSetState = this.onSetState.bind(this);
    }

    onSearch = () => {
        let {
            search,
            dobFrom,
            dobTo,
            gender,
        } = this.state;
        debugger
        /*searching data*/
        studentService.findStudent(1 , search, dobFrom, dobTo, gender)
            .then((response) => {
                debugger
                if (response.status === 200) {
                    let {paginationRecord} = response.data;
                    debugger
                    if (paginationRecord.studentLength) {
                        this.setState({paginationRecord: response.data.paginationRecord});
                        this.getStudentData(paginationRecord.currentPage);
                    }
                    else this.setState({isLoading: false});
                }
            }).catch((error) => {
                this.setState({error: 'there is an error while fetching data'});
        });
    }

    onSetState = (event, stateName) => {
        this.setState({[stateName]: event.target.value})
        debugger
    }

    clickOnChangePage = (pageIndex) => {
        this.getStudentData(pageIndex);
    }

    getPagination = () => {

        paginationService.getPageInfo()
            .then((response) => {

                if (response.status === 200) {
                    let {paginationRecord} = response.data;
                    if (paginationRecord.studentLength) {
                        this.setState({paginationRecord: response.data.paginationRecord});
                        this.getStudentData(paginationRecord.currentPage);
                    }
                    else this.setState({isLoading: false});
                }
            });
    }

    getStudentData = (currentPage) => {
        debugger
        studentService.getStudent(currentPage)
            .then((response) => {
                debugger
                if (response.status === 200) {

                        let paginationRecord = response.data.paginationRecord;
                        paginationRecord = {...this.state.paginationRecord,...paginationRecord}

                        this.setState({
                            studentData: response.data.student ,
                            isLoading: false,
                            paginationRecord: paginationRecord
                        });
                }
            }).catch((error)=> {
                this.setState({error: 'there is an error while fetching data'});
        });
    }

    componentDidMount() {
        this.getPagination();
    }


    render() {

        const {studentData, isLoading, error, paginationRecord, search, dobFrom, dobTo, gender} = this.state;
        debugger
        return isLoading ? (
            <div>
                {'Data is Loading'}
            </div>
        ) :
            error ? (
                <div>{error}</div>
            ) :
            (
                <div>
                    <Search
                        onSearch = {this.onSearch}
                        onSetState = {(event, name) => this.onSetState(event, name)}
                        setDateChangeStart = {date => this.setDateChangeStart(date)}
                        setDateChangeEnd = {date => this.setDateChangeEnd(date)}
                        search = {search}
                        dobFrom = {dobFrom}
                        dobTo = {dobTo}
                        gender = {gender}
                    />
                    <StudentTable
                        studentData = {studentData}
                    />
                    <Page
                        paginationRecord = {paginationRecord}
                        clickOnChangePage = {this.clickOnChangePage}
                    />
                </div>
            )
    }
}

export default StudentGrid;