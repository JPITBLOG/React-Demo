import React from "react";

const BComponent = () => {
    return (
        <div>
            B component
        </div>
    );
}

export default BComponent;