import React from "react";
import {Link, BrowserRouter as Router, Route, Switch} from "react-router-dom";
import A1Component from "./a1Component";
import A2Component from "./A2Component";

const AComponent = ({match}) => {
    return (
        <div>
            A component
            <ul>
                <li><Link to='/a/1'>A1</Link></li>
                <li><Link to='/a/2'>A2</Link></li>
            </ul>

            <hr/>
            <Router>
                    <Route path='/a/1' component={A1Component}/>
                    <Route path='/a/2' component={A2Component}/>
            </Router>
        </div>
    );
}

export default AComponent;