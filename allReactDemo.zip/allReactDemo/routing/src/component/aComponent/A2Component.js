import React from "react";

const A2Component = () => {
    debugger
    return (
        <div>
            {`A2 component`}
        </div>
    );
}

export default A2Component;