import React from "react";

const AWithParams = () => {
    return (
        <div>
            A with params component
        </div>
    );
}

export default AWithParams;