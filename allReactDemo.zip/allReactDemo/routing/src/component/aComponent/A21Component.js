import React from "react";

const A21Component = () => {
    return (
        <div>
            A21 component
        </div>
    );
}

export default A21Component;