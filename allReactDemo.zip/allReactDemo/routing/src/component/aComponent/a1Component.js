import React from "react";

const A1Component = () => {
    debugger
    return (
        <div>
            {`A1 component`}
        </div>
    );
}

export default A1Component;