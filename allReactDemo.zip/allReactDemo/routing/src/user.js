import React from 'react'
import {Redirect, Link} from 'react-router-dom';

class Users extends React.Component {
    render() {
        return (<>
                    <h1>User page</h1>
                    <Link to="/">Admin</Link>
                </>);
    }
}
export default Users;