import React from 'react'
import {
    BrowserRouter as Router,
    Route,
    Link,
} from 'react-router-dom'

const CommonComponent = ({ componentData, routes }) => {
    const { name, resources, id } = componentData;
    debugger
    return (
        <div>
            {name}
            <ul>
                {resources && resources.map(({ id, name }) => (
                    <li><Link to={id}>{name}</Link></li>
                ))}
            </ul>
            <hr />
            {resources && resources.map((singleObj) => (
                <RouteWithSubRoutes key = {singleObj.id} {...singleObj} />
            ))}
        </div>
    );
}

const nestedComponent = [{
    name: 'A',
    id: '/a',
    description: 'A 1 Component',
    component: CommonComponent,
    resources:[{
        name: 'A 1',
        id: '/a/1',
        description: 'A 1 Component',
        component: CommonComponent,
        resources: [
            {
                name: 'URL Parameters',
                id: 'url-parameters',
                description: "URL parameters are parameters whose values are set dynamically in a page's URL. This allows a route to render the same component while passing that component the dynamic portion of the URL so it can change based off of it.",
                url: 'https://ui.dev/react-router-v4-url-parameters/'
            },
            {
                name: 'Programmatically navigate',
                id: 'programmatically-navigate',
                description: "When building an app with React Router, eventually you'll run into the question of navigating programmatically. The goal of this post is to break down the correct approaches to programmatically navigating with React Router.",
                url: 'https://ui.dev/react-router-v4-programmatically-navigate/'
            }
        ]
    },
        {
        name: 'A 2',
        id: '/a/2',
        description: 'A 2 Component',
            component: CommonComponent,
        resources: [
            {
                name: 'A 2 1 Component',
                id: '/a/2/1',
                description: "A 2 1 Component Description",
                component: CommonComponent
            }
        ]
    },
        {
        name: 'A C 1',
        id: '/a/C',
        description: 'A C 1 Component',
            component: CommonComponent,
    }]

    },{
    name: 'C',
    id: '/C',
    description: 'C Component',
    component: CommonComponent,
}]

const RouteWithSubRoutes = (route) => (
    <Route path={route.id} render={(props) => (
        < route.component {...props} routes={route.resources} componentData = {route} />
    )}/>
);

class App extends React.Component {
    render() {
        return (
            <Router>
                <div style={{width: 1000, margin: '0 auto'}}>
                    <ul>
                        <li><Link to='/a'>A</Link></li>
                        <li><Link to='/C'>C</Link></li>
                    </ul>

                    <hr />

                    {nestedComponent.map((componentObj) => (
                        <RouteWithSubRoutes key = {componentObj.id} {...componentObj} />
                    ))}
                </div>
            </Router>
        )
    }
}

export default App