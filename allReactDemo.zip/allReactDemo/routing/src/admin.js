import React from 'react';
import {Link, Redirect} from 'react-router-dom';
import {createBrowserHistory} from "history";

const history = createBrowserHistory();

class Admin extends React.Component {
    OnUser = () => {
        this.props.history.push({pathname: '/user'});
    }
    render() {
        return (
            <div>
                <h1>Admin page</h1>
                <a  onClick={this.OnUser}>User</a>
            </div>
        )
    }
}
export default Admin;