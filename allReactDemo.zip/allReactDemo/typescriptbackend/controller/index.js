`use strict`;

const studentDetail = require(`./studentDetail`);

module.exports = {
    studentDetail
}