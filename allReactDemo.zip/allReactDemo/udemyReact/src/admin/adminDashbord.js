import React,{Component} from 'react';
import AdminavBar from './adminNavbar';
import TabSlider from './tab_Slider';

class Adminpenal extends Component{
    render() {
        return (<div>
                <AdminavBar/>
                <TabSlider/>
            </div>
        )
    }

}
export default Adminpenal;
