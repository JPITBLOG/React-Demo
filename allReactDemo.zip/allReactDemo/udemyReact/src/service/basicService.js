import axios from 'axios';
export const baseUrl = 'http://192.168.16.1:3004';
const baseService = axios.create({
    baseURL:baseUrl
});
export default baseService;
