import React,{Component} from 'react';
import './anauthorize.css';

class Unauthorize extends Component{
    render(){
        return(
            <div className="main-content-wrap"><h4>You are unauthorize to access the page</h4></div>
        );
    }
}
export default Unauthorize;
