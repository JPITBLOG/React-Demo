export const stateValue = () => {
    return {Allstudent:[{
        "_id": "5db15d02a234701cd4500d45",
        "fname": "Biren",
        "lname": "Pithavala",
        "dob": "2017-09-23",
        "studentImage": "http://localhost:8001\\uploads\\student\\2019-10-24T08-12-50.250Zacer1.jpeg",
        "address_one": "SultanaBad,Bhimpor,Surat",
        "address_two": "SultanaBad,Bhimpor,Surat",
        "state": "Gujarat",
        "city": "Surat",
        "zipcod": "343432",
        "isdelete": "0",
        "marks": [
            {
                "_id": "5db15d02a234701cd4500d46",
                "subjectId": "5dada92127bf5f0124f5aac0",
                "marks": "34",
                "isdelete": "0"
            },
            {
                "_id": "5db15d02a234701cd4500d47",
                "subjectId": "5dada8f927bf5f0124f5aabf",
                "marks": "36",
                "isdelete": "0"
            }
        ]
    }]}
}

export const editValue = () => {
    return [{
        "_id": "5db15d02a234701cd4500d45",
        "fname": "Hiren",
        "lname": "Pithavala",
        "dob": "2017-09-21",
        "studentImage": "http://localhost:8001\\uploads\\student\\2019-10-24T08-12-50.250Zacer1.jpeg",
        "address_one": "SultanaBad,Bhimpor,Surat..",
        "address_two": "SultanaBad,Bhimpor,Surat..",
        "state": "Gujarat",
        "city": "Surat",
        "zipcod": "343432",
        "isdelete": "0",
        "marks": [
            {
                "_id": "5db15d02a234701cd4500d46",
                "subjectId": "5dada92127bf5f0124f5aac0",
                "marks": "34",
                "isdelete": "0"
            },
            {
                "_id": "5db15d02a234701cd4500d47",
                "subjectId": "5dada8f927bf5f0124f5aabf",
                "marks": "36",
                "isdelete": "0"
            }
        ]
    }]
}