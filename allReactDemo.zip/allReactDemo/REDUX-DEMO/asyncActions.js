const redux = require('redux');
const thunkMiddleware = require('redux-thunk').default;
const axios = require('axios');
const createStore = redux.createStore;
const applyMiddleware = redux.applyMiddleware;

// initial state
const initialState = {
    loading: false,
    users: [],
    error: ''
};

// action names
const FETCH_USER_REQUEST = 'FETCH_USER_REQUEST';
const FETCH_USER_SUCCESS = 'FETCH_USER_SUCCESS';
const FETCH_USER_ERROR = 'FETCH_USER_ERROR';

// action creators
function fetchUsersRequest() {
    return {
        type: FETCH_USER_REQUEST
    }
}

function fetchUsersSuccess(users) {
    return {
        type: FETCH_USER_SUCCESS,
        payload: users
    }
}

function userError(error) {
    return {
        type: FETCH_USER_ERROR,
        payload: error
    }
}

function fetchUsers() {
    return function (dispatch) {
        dispatch(fetchUsersRequest());
        axios.get('https://jsonplaceholder.typicode.com/users')
            .then((response) => {
                let users = response.data.map(user => user.id);
                dispatch(fetchUsersSuccess(users));
            })
            .catch((error) => {
                dispatch(userError(error.message));
            });
    }
}

// create reducer
let reducer = (state = initialState, action) => {
    switch (action.type) {
        case FETCH_USER_REQUEST:
            return {
                ...state,
                loading: true
            };
        case FETCH_USER_SUCCESS: return {
            loading: false,
            users: action.payload,
            error: ''
        };
        case FETCH_USER_ERROR: return {
            loading: false,
            users: [],
            error: action.payload
        };
    }
};

// create store
const store = createStore(reducer, applyMiddleware(thunkMiddleware));
console.log('Initial state ', store.getState());

const unsubscribe = store.subscribe(() => console.log('new state', store.getState()));
store.dispatch(fetchUsers());



